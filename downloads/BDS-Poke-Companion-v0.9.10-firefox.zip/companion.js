import { setupNotifications } from './notifications-view.js';
import { renderHTML } from './render-html.js';
import { requireAccess } from './access-gate.js';
import { setupGymLeaders } from './gym-leaders-view.js';
import { setupHunt } from './hunt-view.js';
import { loadItemSprites, itemSprite } from './item-sprites.js';
import { loadSprites, sprite } from './sprites.js';
import { setupGym } from './gym-view.js';
import { setupMeta } from './meta-view.js';
import { normalize, parseTooltip } from './core.js';
import { TYPES, REGIONS, pokemonTypes } from './battle.js';
import { speciesLocations, filterDex } from './dex.js';
const api = globalThis.browser?.runtime?.id
  ? browser
  : globalThis.chrome?.runtime?.id
    ? chrome
    : null;
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c],
    );
const fmt = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
let renderMeta, renderGym, renderHunt, renderLeaders, renderNotifications;
let catalog,
  items,
  locations,
  progress = { rows: {} },
  context = {},
  limit = 40,
  view = 'dex',
  moves = [],
  toastTimer,
  refreshTask,
  dexSignature,
  leadersSignature;
let panelVisible = window === window.parent;
const canRefresh = () => panelVisible && !document.hidden;
window.addEventListener('message', (e) => {
  if (
    e.source !== window.parent ||
    typeof e.data?.bdsPanelVisible !== 'boolean'
  )
    return;
  panelVisible = e.data.bdsPanelVisible;
  if (canRefresh() && catalog && renderHunt) refresh().catch(() => {});
});
const loaded = new Set();
async function send(m) {
  if (!api) throw Error('Instale a extensão para ler sua conta.');
  const r = await api.runtime.sendMessage(m);
  if (!r?.ok) throw Error(r?.error || 'Não foi possível concluir.');
  return r.data;
}
function toast(s) {
  $('toast').textContent = s;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($('toast').hidden = true), 4500);
}
function go(name) {
  view = name;
  $('analysis').hidden = true;
  $('library').hidden = false;
  document
    .querySelectorAll('.view')
    .forEach((el) => el.classList.toggle('active', el.id === name));
  document
    .querySelectorAll('[data-view]')
    .forEach((el) => el.classList.toggle('active', el.dataset.view === name));
  if (name === 'dex') renderDex();
  if (name === 'hunt') renderHunt?.();
  if (name === 'leaders') renderLeaders?.();
  if (name === 'notifications') renderNotifications?.();
  if (!loaded.has(name)) {
    if (name === 'items') renderItems();
    if (name === 'moves') renderMoves();
    if (name === 'meta') renderMeta();
    if (name === 'gym') renderGym();
    loaded.add(name);
  }
}
function analyze(id, selection, tab = 'quality', level) {
  const c = catalog.creatures.find((c) => c.pokeId === Number(id));
  $('analysis-title').textContent = c ? c.name : 'Exemplar selecionado';
  $('analyzer-frame').src =
    'analyzer.html?embedded=1&' +
    (selection
      ? 'selection=' + encodeURIComponent(selection)
      : 'species=' + Number(id)) +
    '&tab=' +
    tab +
    (Number.isInteger(Number(level)) && Number(level) > 0
      ? '&level=' + Number(level)
      : '');
  $('library').hidden = true;
  $('analysis').hidden = false;
}
async function refresh() {
  // One read in flight. A slow background never creates a self-sustaining loop.
  if (refreshTask) return refreshTask;
  refreshTask = (async () => {
    context = api ? await send({ type: 'companion-context' }) : context;
    progress = context.progress || { rows: {} };
    if (!canRefresh() || $('library').hidden) return;
    const live =
      context.live?.connected &&
      context.live?.online &&
      Date.now() - context.live.lastSeen < 15000;
    if (view === 'dex') {
      const sig = JSON.stringify([
        context.profileId,
        progress.updatedAt,
        progress.revision,
        progress.gap,
        live,
        context.live?.lastEventAt,
        context.live?.error,
      ]);
      if (sig !== dexSignature) {
        dexSignature = sig;
        renderDex();
      }
    }
    if (view === 'hunt') renderHunt?.();
    if (view === 'leaders') {
      const sig = JSON.stringify([
        context.gymLeaders,
        context.team,
        context.profileId,
        live,
      ]);
      if (sig !== leadersSignature) {
        leadersSignature = sig;
        renderLeaders?.();
      }
    }
    if (view === 'notifications') renderNotifications?.();
  })();
  try {
    await refreshTask;
  } finally {
    refreshTask = null;
  }
}
function watchContext() {
  // Read only our background snapshot, never the game's API. Keep the fast event
  // path as well; polling also recovers missing container notifications/restarts.
  const update = () => {
    if (canRefresh()) refresh().catch(() => {});
  };
  let timer;
  const start = () => {
    clearInterval(timer);
    timer = setInterval(update, 1000);
    update();
  };
  window.addEventListener('pagehide', () => clearInterval(timer));
  window.addEventListener('pageshow', start);
  window.addEventListener('focus', update);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) update();
  });
  start();
}
function renderDex() {
  const filters = {
    query: $('dex-search').value,
    type: $('type').value,
    region: $('region').value,
    caught: $('caught').value,
    log: $('log').value,
    minLevel: Number($('min-level').value) || 0,
    maxLevel: Number($('max-level').value) || 0,
    sort: $('sort').value,
  };
  const { list, totals } = filterDex(
    catalog.creatures,
    locations,
    progress.rows,
    filters,
  );
  $('sync-state').textContent = totals.known
    ? `${totals.known} registros lidos da Pokédex nesta sessão · atualizado às ${new Date(progress.updatedAt).toLocaleTimeString('pt-BR')}. Sem leitura: ${catalog.creatures.length - totals.known} espécies. Os totais abaixo não mudam com os filtros.`
    : 'Abra a Pokédex dentro do jogo e aguarde carregar. A busca de espécies já está disponível; capturas e Pokelog aparecerão após a leitura.';
  if (totals.known) {
    const live =
      context.live?.connected &&
      context.live?.online &&
      Date.now() - context.live.lastSeen < 15000;
    $('sync-state').textContent += progress.gap
      ? ' Houve uma interrupção: reabra a Pokédex uma vez para conferir o progresso perdido.'
      : live
        ? ' Ao vivo: pode fechar a Pokédex; abates e capturas continuam atualizando.'
        : ' Leitura ao vivo indisponível; aguardando conexão com o jogo.';
  }
  if (context.live?.lastEventAt)
    $('sync-state').textContent +=
      ` Último ${context.live.lastEventKind === 'capture' ? 'evento de captura' : 'abate'} recebido às ${new Date(context.live.lastEventAt).toLocaleTimeString('pt-BR')}.`;
  if (context.live?.error)
    $('sync-state').textContent +=
      ' ' +
      context.live.error +
      ' Use “Ativar nas contas abertas” para reconectar.';
  renderHTML(
    $('totals'),
    [
      [totals.caught, 'Capturados'],
      [totals.complete, 'Pokelog completo'],
      [totals.incomplete, 'Pokelog incompleto'],
      [totals.known, 'Registros lidos'],
    ]
      .map(
        ([n, t]) =>
          `<div class="total"><b>${totals.known ? fmt(n) : '—'}</b><small>${t}</small></div>`,
      )
      .join(''),
  );
  $('count').textContent =
    `${fmt(list.length)} Pokémon · mostrando ${Math.min(limit, list.length)}`;
  renderHTML(
    $('dex-list'),
    list
      .slice(0, limit)
      .map((c) => {
        const p = progress.rows[c.pokeId],
          loc = locations.get(c.pokeId) || [],
          shown = filters.region
            ? loc.filter((h) => h.region === filters.region)
            : loc;
        const threshold = p?.threshold || 100;
        const kills =
          p?.kills != null
            ? (p.atLeast ? '≥ ' : '') + fmt(p.kills)
            : p?.complete && p.threshold
              ? '≥ ' + fmt(p.threshold)
              : '—';
        return `<article class="dex-row" data-species="${c.pokeId}" tabindex="0" role="button" aria-label="Analisar ${esc(c.name)}"><span class="dex-no">${sprite(c)}<span>#${c.pokeId}</span></span><div><h3>${esc(c.name)}</h3><small>${pokemonTypes(
          c,
        )
          .map((t) => TYPES[t])
          .join(' · ')}</small><small>${
          shown
            .slice(0, 3)
            .map((h) => `${REGIONS[h.region]} · Nv. ${fmt(h.level)}`)
            .join(' / ') || 'Local não confirmado'
        }</small></div><div class="entry-state"><span class="badge ${p ? (p.caught ? 'good' : 'pending') : ''}">${p ? (p.caught ? 'Capturado' : 'Não capturado') : 'Sem leitura'}</span><span>${p ? (p.complete ? '✓ Pokelog completo' : 'Pokelog incompleto') : 'Pokelog: sem leitura'}</span><b>${kills} kills</b>${p ? `<div class="mini-meter"><i style="width:${p.complete ? 100 : Math.min(100, ((p.kills || 0) / threshold) * 100)}%"></i></div>` : ''}</div></article>`;
      })
      .join('') || '<div class="empty">Nenhum Pokémon com estes filtros.</div>',
  );
  $('more').hidden = list.length <= limit;
}
function renderItems() {
  const q = normalize($('item-search').value),
    list = items.filter((i) => normalize(i.name).includes(q));
  renderHTML(
    $('item-list'),
    `<p class="hint">${list.length} itens · abra um resultado para ver as fontes de drop. Fontes ordenadas da maior para a menor chance de drop. Valores NPC e chances base do catálogo.</p>` +
      list
        .map((i) => {
          const sources = catalog.creatures
            .filter((c) =>
              c.loot?.some(
                (l) => normalize(l.name) === normalize(i.name) && l.chance > 0,
              ),
            )
            .sort(
              (a, b) =>
                b.loot.find(
                  (l) =>
                    normalize(l.name) === normalize(i.name) && l.chance > 0,
                ).chance -
                  a.loot.find(
                    (l) =>
                      normalize(l.name) === normalize(i.name) && l.chance > 0,
                  ).chance || a.name.localeCompare(b.name),
            );
          return `<details class="result"><summary><div class="item-label">${itemSprite(i)}<span><strong>${esc(i.name)}</strong><small>${esc(i.category)} · ${sources.length} fontes</small></span></div><span class="item-price">${fmt(i.npcPrice)} gold</span></summary>${
            sources.length
              ? sources
                  .map((c) => {
                    const l = c.loot.find(
                      (l) =>
                        normalize(l.name) === normalize(i.name) && l.chance > 0,
                    );
                    return `<div class="learner"><button data-species="${c.pokeId}" data-tab="drops">${esc(c.name)}</button><span>${fmt(l.chance / 1000, 5)}% · ${l.minCount}–${l.maxCount} un.</span></div>`;
                  })
                  .join('')
              : '<p>Sem fonte de drop registrada neste catálogo.</p>'
          }</details>`;
        })
        .join(''),
  );
}
function renderMoves() {
  const q = normalize($('move-search').value),
    type = $('move-type').value,
    list = moves.filter(
      (m) => normalize(m.name).includes(q) && (!type || m.type === type),
    );
  renderHTML(
    $('move-list'),
    `<p class="hint">${list.length} golpes · naturais e TMs identificados separadamente.</p>` +
      list
        .map(
          (m) =>
            `<details class="result"><summary><div><strong>${esc(m.name)}</strong><small>${TYPES[m.type]} · ${m.category === 'SPECIAL' ? 'Especial' : m.category === 'STATUS' ? 'Status' : 'Físico'} · poder ${fmt(m.power)}${m.tm ? ' · TM' : ''}</small></div><span>${m.learners.length} espécies</span></summary>${m.learners.map(({ c, a }) => `<div class="learner"><button data-species="${c.pokeId}" data-tab="battle">${esc(c.name)}</button><span>${a.tm ? 'TM · confirmar requisitos' : 'Natural · nível ' + a.learnLevel}</span></div>`).join('')}</details>`,
        )
        .join(''),
  );
}
async function init() {
  await Promise.all([loadSprites(), loadItemSprites()]);
  const [data, itemData, typeData, statusData, gymData, spawnData] =
    await Promise.all(
      [
        'hunts',
        'items',
        'type-chart',
        'status-evidence',
        'gym-evidence',
        'spawns',
      ].map((n) => fetch(`data/${n}.json`).then((r) => r.json())),
    );
  catalog = data;
  items = itemData.items;
  locations = speciesLocations(catalog.hunts);
  renderMeta = setupMeta(catalog, typeData.chart, statusData);
  renderGym = setupGym(catalog, typeData.chart, gymData);
  renderNotifications = setupNotifications(() => context, send, toast);
  renderLeaders = setupGymLeaders(catalog, () => context, typeData.chart);
  renderHunt = setupHunt(
    catalog,
    typeData.chart,
    spawnData,
    () => context,
    send,
    toast,
    refresh,
  );
  renderHTML(
    $('region'),
    Object.entries(REGIONS)
      .map(([v, t]) => `<option value="${v}">${t}</option>`)
      .join(''),
    true,
  );
  for (const id of ['type', 'move-type'])
    renderHTML(
      $(id),
      Object.entries(TYPES)
        .map(([v, t]) => `<option value="${v}">${t}</option>`)
        .join(''),
      true,
    );
  const map = new Map();
  for (const c of catalog.creatures)
    for (const a of c.attacks || []) {
      const key = [a.name, a.type, a.power, a.category, !!a.tm].join('|');
      if (!map.has(key)) map.set(key, { ...a, learners: [] });
      map.get(key).learners.push({ c, a });
    }
  moves = [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
  await refresh();
  for (const id of [
    'dex-search',
    'type',
    'region',
    'caught',
    'log',
    'min-level',
    'max-level',
    'sort',
  ])
    $(id).addEventListener('input', () => {
      limit = 40;
      renderDex();
    });
  $('item-search').addEventListener('input', renderItems);
  for (const id of ['move-search', 'move-type'])
    $(id).addEventListener('input', renderMoves);
  document.addEventListener('click', (e) => {
    const target = e.target.closest('[data-species]');
    if (target) {
      if (e.ctrlKey || target.tagName === 'BUTTON') {
        e.preventDefault();
        analyze(
          target.dataset.species,
          null,
          target.dataset.tab || 'quality',
          target.dataset.level,
        );
      } else toast('Ctrl + clique para abrir o analisador desta espécie.');
      return;
    }
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.view) go(b.dataset.view);
  });
  document.addEventListener('keydown', (e) => {
    const row = e.target.closest('.dex-row');
    if (row && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      analyze(row.dataset.species);
    }
  });
  $('more').onclick = () => {
    limit += 40;
    renderDex();
  };
  $('clear').onclick = () => {
    for (const id of [
      'dex-search',
      'type',
      'region',
      'caught',
      'log',
      'min-level',
      'max-level',
    ])
      $(id).value = '';
    $('sort').value = 'id';
    limit = 40;
    renderDex();
  };
  $('back').onclick = () => go(view);
  $('sync').onclick = async () => {
    try {
      const data = await send({ type: 'dex-scan' });
      await refresh();
      toast(data?.message || 'Leitura atualizada.');
    } catch (e) {
      toast(e.message);
    }
  };
  $('clear-progress').onclick = async () => {
    try {
      await send({ type: 'dex-clear' });
      await refresh();
      toast('Leitura desta aba limpa. Reabra a Pokédex para ler novamente.');
    } catch (e) {
      toast(e.message);
    }
  };
  $('parse').onclick = async () => {
    try {
      const record = parseTooltip($('tooltip-text').value);
      if (!record)
        throw Error('Cole nome, nível, qualidade e atributos do tooltip.');
      const { key } = await send({
        type: 'selection-create',
        record,
        profileId: context.profileId,
      });
      analyze(null, key);
    } catch (e) {
      toast(e.message);
    }
  };
  // Visible polling also works across Firefox containers. Storage fan-out from
  // another account no longer repaints every open or minimized panel.
  if (api) watchContext();
  const params = new URLSearchParams(location.search);
  if (params.get('selection')) analyze(null, params.get('selection'));
  else if (params.get('species')) analyze(params.get('species'));
  else if (
    [
      'items',
      'moves',
      'meta',
      'gym',
      'leaders',
      'hunt',
      'notifications',
      'ivs',
      'help',
    ].includes(params.get('view'))
  )
    go(params.get('view'));
}
requireAccess()
  .then((allowed) => (allowed ? init() : undefined))
  .catch((e) => {
    $('library').textContent = e.message;
  });
