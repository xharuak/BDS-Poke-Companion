import { renderHTML } from './render-html.js';
import { GYMS } from './gym-leaders.js';
import { simulationMember, validateBattle } from './gym-simulation.js';
import { sprite } from './sprites.js';
import { TYPES } from './battle.js';

const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
const fmt = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const date = (n) => (n ? new Date(n).toLocaleString('pt-BR') : 'sem leitura');
const fields = [
  ['level', 'Nível'],
  ['maxHp', 'HP máximo'],
  ['atk', 'ATK'],
  ['def', 'DEF'],
  ['spa', 'SP.ATK'],
  ['spd', 'SP.DEF'],
  ['vel', 'VEL'],
];

export function setupGymSimulation(container, catalog, chart, getContext) {
  container.className = 'gym-simulator';
  renderHTML(
    container,
    `<h2>Minha equipe × ginásio</h2><p>Simule a equipe principal equipada nesta conta contra o líder registrado. Abra o inventário e Ginásios no jogo uma vez para ler os dois times.</p>
    <div class="filters"><label>Ginásio<select data-sim="gym" aria-label="Ginásio da simulação"></select></label><label>Regras<select data-sim="mode"><option value="leadership">Disputa de liderança</option><option value="free">Comparação livre</option></select></label></div>
    <p data-sim="opponent" class="hunt-note"></p><p data-sim="sync" class="hunt-note" role="status"></p>
    <button data-sim="load" type="button">Usar equipe atual</button><div data-sim="team" class="sim-team"></div>
    <div class="sim-actions"><button data-sim="run" type="button">Simular batalha</button><span>2.000 simulações · cálculo local</span></div>
    <div data-sim="feedback" class="hint" role="status" aria-live="polite"></div><div data-sim="result" aria-live="polite"></div>
    <details class="meta-options"><summary>Como interpretar a estimativa</summary>
    <p>A porcentagem é a frequência de vitória neste modelo, não uma chance oficial do servidor. Um resultado de 100% aqui não garante vitória no jogo. Os dois times começam com HP cheio; a ordem exibida é mantida e o sobrevivente conserva o HP entre confrontos.</p>
    <p>Hipóteses: maior velocidade ataca primeiro; empate de velocidade é sorteado. Cada lado escolhe o golpe com maior dano estimado contra a defesa física ou especial do adversário. Não usa a amplificação de tipos das hunts. Testamos também o rival causando 15% menos ou mais dano para mostrar a sensibilidade do resultado.</p>
    <p>Golpes e atributos lidos têm prioridade. Sem golpes lidos, usamos golpes naturais do catálogo liberados pelo nível; TMs não lidas ficam de fora. HP ausente é estimado pela conversão do cliente público: máximo entre 24 e 12 × atributo HP. Confira os valores e ajuste-os nos campos, se necessário.</p>
    <p>Modelo de dano adotado: [((2 × nível / 5 + 2) × poder × ataque / defesa) / 50 + 2] × STAB (1,5) × tipo × sorteio de 0,85 a 1. Essa fórmula, a variação e a escolha de golpes não foram confirmadas no servidor do ginásio.</p>
    <p>Não acrescentamos efeitos de Poison/Burn, críticos, bloqueios, cura, trocas voluntárias ou bônus invisíveis. Os atributos digitados são usados como estão. Combates travados por imunidade ou acima de 1.200 rodadas ficam como sem conclusão. A elegibilidade de insígnias e cooldowns continua sendo decidida pelo jogo.</p></details>`,
  );
  const el = (name) => container.querySelector(`[data-sim="${name}"]`);
  let draft = [],
    dirty = false,
    profile,
    teamSig = '',
    recordSig = '',
    worker = null,
    generation = 0;
  function cancel(
    message = 'Dados alterados. Clique em Simular batalha para recalcular.',
  ) {
    generation++;
    worker?.terminate();
    worker = null;
    el('run').disabled = false;
    el('result').replaceChildren();
    el('feedback').textContent = message;
  }
  function currentGym() {
    const gym = GYMS.find((g) => g.id === el('gym').value),
      record = getContext().gymLeaders?.records?.[gym?.id];
    return { gym, record, leader: record?.lastPlayer };
  }
  function renderOpponent() {
    const { gym, record, leader } = currentGym();
    el('opponent').textContent =
      leader && !record.vacant
        ? `${gym.type} GYM — ${leader.name} · Equipe observada em ${date(leader.teamObservedAt ?? leader.observedAt)}. Reabra Ginásios para conferir mudanças recentes.`
        : 'Nenhum líder atual com equipe disponível. Abra Ginásios no jogo para atualizar.';
  }
  function renderTeam() {
    renderHTML(
      el('team'),
      draft
        .map(
          (p, i) =>
            `<article class="sim-mon"><div class="sim-mon-head">${sprite({ pokeId: p.speciesId, name: p.name }, { shiny: p.shiny })}<div><strong>${i + 1}. ${esc(p.name)}${p.shiny ? ' ✨' : ''}</strong><small>${p.types.map((t) => TYPES[t]).join(' · ')}</small></div><button type="button" data-order="${i}" data-direction="-1" ${i === 0 ? 'disabled' : ''} aria-label="Subir ${esc(p.name)}">↑</button><button type="button" data-order="${i}" data-direction="1" ${i === draft.length - 1 ? 'disabled' : ''} aria-label="Descer ${esc(p.name)}">↓</button></div><div class="sim-fields">${fields.map(([key, label]) => `<label>${label}<input type="number" min="1" step="1" max="${key === 'level' ? 1000000 : 1e9}" data-slot="${i}" data-stat="${key}" aria-label="${esc(p.name)} ${label}" value="${esc((key === 'level' || key === 'maxHp' ? p[key] : p.current[key]) ?? '')}"></label>`).join('')}</div><small>${p.hpSource === 'derived' ? 'HP convertido do atributo do inventário' : 'HP máximo lido'} · ${p.movesSource === 'catalog' ? 'Golpes naturais estimados pelo catálogo' : 'Golpes lidos do jogo'}. As alterações aqui são apenas para simulação.</small></article>`,
        )
        .join('') ||
        '<p class="empty">Equipe ainda não lida nesta conta. Abra o inventário do jogo.</p>',
    );
  }
  function loadTeam() {
    draft = (getContext().team?.members || []).map((p) =>
      simulationMember(p, catalog.creatures),
    );
    dirty = false;
    cancel('Equipe carregada. Escolha o ginásio e clique em Simular batalha.');
    renderTeam();
    sync();
  }
  function sync() {
    const c = getContext(),
      team = c.team;
    el('sync').textContent = !c.profileId
      ? 'Abra o Gym Leader pela barra BDS na conta que deseja analisar.'
      : !team
        ? 'Aguardando a leitura da equipe. Abra ou reabra o inventário desta conta.'
        : `Equipe da conta desta aba · ${team.members.length} Pokémon · Leitura em ${date(team.observedAt)}.${dirty ? ' Ajustes locais ativos; Usar equipe atual restaura os dados lidos.' : ''}`;
    el('load').disabled = !team;
  }
  function renderResult(result, team, opponents) {
    if (result.errors?.length) {
      el('feedback').textContent = result.errors.join(' ');
      return;
    }
    const central = result.scenarios[0],
      labels = { win: 'Vitória', loss: 'Derrota', draw: 'Sem conclusão' };
    el('feedback').textContent =
      'Simulação concluída. Percentuais condicionados às hipóteses do modelo.';
    renderHTML(
      el('result'),
      `<div class="sim-result"><h3>Chance estimada no modelo</h3><p>Estimativa aproximada; não reproduz integralmente o servidor. Efeitos de status, críticos e bloqueios não estão incluídos.</p><div class="sim-percentages">${['win', 'loss', 'draw'].map((k) => `<div data-outcome="${k}"><strong>${fmt(central[k], 1)}%</strong><span>${labels[k]}</span><small>${fmt(central.counts[k])} de ${fmt(central.trials)}</small></div>`).join('')}</div><p>${fmt(central.meanRounds, 1)} rodadas em média · 1.200 rodadas no máximo por batalha.</p><details><summary>Sensibilidade: dano do rival ±15%</summary><table><thead><tr><th>Cenário hipotético</th><th>Vitória</th><th>Derrota</th><th>Sem conclusão</th></tr></thead><tbody>${result.scenarios.map((s) => `<tr><td>${s.label}<small>${fmt(s.trials)} simulações</small></td><td>${fmt(s.win, 1)}%</td><td>${fmt(s.loss, 1)}%</td><td>${fmt(s.draw, 1)}%</td></tr>`).join('')}</tbody></table><p>Variações hipotéticas de dano, não um intervalo de confiança sobre o jogo real.</p></details><details><summary>Golpes escolhidos em cada confronto</summary>${team
        .map(
          (p, i) =>
            `<div class="sim-matchups"><strong>${esc(p.name)}</strong>${opponents
              .map((q, j) => {
                const pair = result.matrix[i][j];
                return `<p>× ${esc(q.name)}: <b>${esc(pair.ours.name)}</b> (${pair.ours.category === 'SPECIAL' ? 'especial' : 'físico'}, ${fmt(pair.ours.effectiveness, 2)}×) · rival: ${esc(pair.theirs.name)}</p>`;
              })
              .join('')}</div>`,
        )
        .join(
          '',
        )}</details><details><summary>Exemplo de uma simulação · ${labels[result.example.outcome]}</summary><p>Primeiras ${result.example.events.length} ações; um exemplo não representa todas as batalhas.</p><ol class="sim-log">${result.example.events.map((e) => `<li>Rodada ${e.round} · ${e.ours ? 'Você' : 'Rival'}: ${esc(e.attacker)} usa ${esc(e.move)} em ${esc(e.defender)} — ${fmt(e.damage)} de dano; HP restante ${fmt(e.remaining)}.</li>`).join('')}</ol>${result.example.reason ? '<p>Sem conclusão por imunidade ou limite de rodadas.</p>' : ''}</details></div>`,
    );
  }
  function run() {
    cancel('Conferindo as equipes…');
    const context = getContext(),
      { gym, record, leader } = currentGym();
    if (!context.profileId || !context.team) {
      el('feedback').textContent =
        'Abra o inventário da conta do jogo para ler sua equipe antes de simular.';
      return;
    }
    if (!gym || record?.vacant || !leader?.team?.length) {
      el('feedback').textContent =
        'Abra Ginásios no jogo. Precisamos da equipe do líder atual, não de um posto vago.';
      return;
    }
    const team = draft.map((p) =>
      p.movesSource === 'catalog'
        ? simulationMember({ ...p, moves: [] }, catalog.creatures)
        : p,
    );
    const opponents = leader.team.map((p) =>
      simulationMember(p, catalog.creatures),
    );
    const free = el('mode').value === 'free',
      errors = validateBattle(team, opponents, gym.type, free);
    if (errors.length) {
      el('feedback').textContent = errors.join(' ');
      return;
    }
    const job = generation;
    el('run').disabled = true;
    el('feedback').textContent = 'Simulando as batalhas…';
    try {
      worker = new Worker(
        new URL('./gym-simulation-worker.js', import.meta.url),
        { type: 'module' },
      );
      worker.onmessage = ({ data }) => {
        if (job !== generation) return;
        worker.terminate();
        worker = null;
        el('run').disabled = false;
        renderResult(data, team, opponents);
      };
      worker.onerror = () => {
        if (job === generation)
          cancel(
            'Não foi possível iniciar o cálculo. Recarregue a extensão e tente novamente.',
          );
      };
      worker.postMessage({ team, opponents, chart, gymType: gym.type, free });
    } catch {
      cancel(
        'Não foi possível iniciar o cálculo. Recarregue a extensão e tente novamente.',
      );
    }
  }
  el('load').addEventListener('click', loadTeam);
  el('run').addEventListener('click', run);
  el('gym').addEventListener('change', () => {
    cancel();
    renderOpponent();
  });
  el('mode').addEventListener('change', () => cancel());
  el('team').addEventListener('input', (e) => {
    const input = e.target.closest('[data-stat]');
    if (!input) return;
    const p = draft[Number(input.dataset.slot)],
      key = input.dataset.stat,
      value = input.value === '' ? null : Number(input.value);
    if (key === 'level' || key === 'maxHp') p[key] = value;
    else p.current[key] = value;
    dirty = true;
    cancel();
    sync();
  });
  el('team').addEventListener('click', (e) => {
    const button = e.target.closest('[data-order]');
    if (!button) return;
    const i = Number(button.dataset.order),
      j = i + Number(button.dataset.direction);
    if (j < 0 || j >= draft.length) return;
    [draft[i], draft[j]] = [draft[j], draft[i]];
    dirty = true;
    cancel();
    renderTeam();
    sync();
  });
  window.addEventListener('pagehide', () => worker?.terminate());
  function render() {
    const context = getContext(),
      nextTeam = JSON.stringify([
        context.profileId,
        context.team?.members ?? null,
      ]);
    if (profile !== context.profileId) {
      profile = context.profileId;
      dirty = false;
      draft = [];
      teamSig = '';
      cancel('');
    }
    if (nextTeam !== teamSig) {
      teamSig = nextTeam;
      cancel('A leitura da equipe mudou. Confira os dados e simule novamente.');
      if (!dirty) {
        draft = (context.team?.members || []).map((p) =>
          simulationMember(p, catalog.creatures),
        );
        renderTeam();
      }
    }
    const records = context.gymLeaders?.records || {},
      nextRecords = JSON.stringify(records);
    if (nextRecords !== recordSig) {
      recordSig = nextRecords;
      const previous = el('gym').value;
      const choices = GYMS.filter(
        (g) => records[g.id]?.lastPlayer?.team?.length && !records[g.id].vacant,
      );
      renderHTML(
        el('gym'),
        choices
          .map(
            (g) =>
              `<option value="${g.id}">${g.type} — ${g.city} — ${esc(records[g.id].lastPlayer.name)}</option>`,
          )
          .join('') || '<option value="">Aguardando Ginásios</option>',
      );
      if (choices.some((g) => g.id === previous)) el('gym').value = previous;
      cancel(
        'Registro do ginásio atualizado. Confira as equipes e simule novamente.',
      );
      renderOpponent();
    }
    sync();
  }
  render.selectGym = (id) => {
    el('gym').value = id;
    renderOpponent();
    run();
    container.scrollIntoView({ block: 'start', behavior: 'smooth' });
  };
  return render;
}
