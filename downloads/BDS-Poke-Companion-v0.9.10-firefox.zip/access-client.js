import { OWNER_EMAIL } from './access-config.js';
const CACHE_MS = 300000;
const messages = {
  INVALID_LOGIN_CREDENTIALS: 'E-mail ou senha incorretos.',
  EMAIL_NOT_FOUND: 'E-mail ou senha incorretos.',
  INVALID_PASSWORD: 'E-mail ou senha incorretos.',
  EMAIL_EXISTS:
    'Não foi possível criar a conta. Tente entrar ou recuperar a senha.',
  TOO_MANY_ATTEMPTS_TRY_LATER: 'Muitas tentativas. Aguarde e tente novamente.',
  USER_DISABLED: 'Esta conta foi desativada.',
  OPERATION_NOT_ALLOWED:
    'O login por e-mail ainda não foi habilitado pelo proprietário.',
  INVALID_EMAIL: 'Informe um e-mail válido.',
  WEAK_PASSWORD: 'Use uma senha com pelo menos 12 caracteres.',
  QUOTA_EXCEEDED: 'O serviço atingiu o limite gratuito. Tente mais tarde.',
  PERMISSION_DENIED:
    'A operação não foi autorizada. Confira seu acesso ou a configuração do serviço.',
};
const emailValue = (x) =>
  String(x || '')
    .trim()
    .toLowerCase();
export const configured = (c) =>
  !!c &&
  /^[a-z][a-z0-9-]{4,61}[a-z0-9]$/.test(c.projectId) &&
  /^AIza[\w-]{30,}$/.test(c.apiKey);
const encode = (value) =>
  value === null
    ? { nullValue: null }
    : typeof value === 'string'
      ? { stringValue: value }
      : typeof value === 'number'
        ? { integerValue: String(value) }
        : value;
export const fields = (object) =>
  Object.fromEntries(
    Object.entries(object).map(([key, value]) => [key, encode(value)]),
  );
export const decode = (document) =>
  document?.fields
    ? Object.fromEntries(
        Object.entries(document.fields).map(([key, value]) => [
          key,
          value.stringValue ??
            value.timestampValue ??
            (value.integerValue !== undefined
              ? Number(value.integerValue)
              : null),
        ]),
      )
    : null;
const timestamp = (value) =>
  value === null ? null : { timestampValue: value };

export function createAccessClient({
  config,
  storage,
  fetchImpl = fetch,
  now = Date.now,
  uuid = () => crypto.randomUUID(),
}) {
  let cached = null,
    session = null,
    loaded = false,
    lastAttempt = 0;
  const base = `https://firestore.googleapis.com/v1/projects/${config.projectId}/databases/(default)/documents`;
  const docName = (path) =>
    `projects/${config.projectId}/databases/(default)/documents/${path}`;
  function requireConfig() {
    if (!configured(config))
      throw Error(
        'O proprietário ainda precisa configurar o serviço de acesso.',
      );
  }
  async function request(
    url,
    {
      body,
      token,
      method = body ? 'POST' : 'GET',
      form = false,
      allow404 = false,
    } = {},
  ) {
    const controller = new AbortController(),
      timer = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetchImpl(url, {
        method,
        cache: 'no-store',
        credentials: 'omit',
        redirect: 'error',
        signal: controller.signal,
        headers: {
          ...(body
            ? {
                'Content-Type': form
                  ? 'application/x-www-form-urlencoded'
                  : 'application/json',
              }
            : {}),
          ...(token ? { Authorization: 'Bearer ' + token } : {}),
          'X-Firebase-Locale': 'pt-BR',
        },
        ...(body
          ? {
              body: form
                ? new URLSearchParams(body).toString()
                : JSON.stringify(body),
            }
          : {}),
      });
      if (allow404 && response.status === 404) return null;
      const data = await response.json();
      if (!response.ok) {
        const code = String(
          data.error?.message || data.error?.status || '',
        ).split(' : ')[0];
        const error = Error(
          messages[code] ||
            'Não foi possível concluir no serviço de acesso. Tente novamente.',
        );
        error.code = code;
        error.status = response.status;
        throw error;
      }
      return data;
    } catch (error) {
      if (error.name === 'AbortError' || error instanceof TypeError)
        throw Error(
          'Sem conexão com o serviço de acesso. Confira a internet e tente novamente.',
        );
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  const auth = (operation, body) => {
    requireConfig();
    return request(
      `https://identitytoolkit.googleapis.com/v1/accounts:${operation}?key=${encodeURIComponent(config.apiKey)}`,
      { body },
    );
  };
  async function load() {
    if (!loaded) {
      session = (await storage.get('accessSession')).accessSession || null;
      loaded = true;
    }
    return session;
  }
  async function save(value) {
    session = value;
    loaded = true;
    await storage.set({ accessSession: value });
    cached = null;
  }
  async function keep(data) {
    await save({
      uid: data.localId || data.user_id,
      email: data.email || session?.email || '',
      idToken: data.idToken || data.id_token,
      refreshToken: data.refreshToken || data.refresh_token,
      expiresAt:
        now() + Number(data.expiresIn || data.expires_in || 3600) * 1000,
    });
  }
  async function token(force = false) {
    requireConfig();
    await load();
    if (!session?.refreshToken) throw Error('Entre na sua conta BDS.');
    if (force || session.expiresAt < now() + 60000) {
      const data = await request(
        `https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(config.apiKey)}`,
        {
          body: {
            grant_type: 'refresh_token',
            refresh_token: session.refreshToken,
          },
          form: true,
        },
      );
      await keep(data);
    }
    return session.idToken;
  }
  async function document(path) {
    return request(base + '/' + path, { token: await token(), allow404: true });
  }
  async function commit(writes) {
    return request(base + ':commit', {
      body: { writes },
      token: await token(),
    });
  }
  const create = (path, data, timeFields = []) => ({
    update: { name: docName(path), fields: fields(data) },
    currentDocument: { exists: false },
    ...(timeFields.length
      ? {
          updateTransforms: timeFields.map((fieldPath) => ({
            fieldPath,
            setToServerValue: 'REQUEST_TIME',
          })),
        }
      : {}),
  });
  function state(phase, extra = {}) {
    return {
      phase,
      allowed: phase === 'active',
      owner: false,
      email: session?.email || '',
      uid: session?.uid || '',
      ...extra,
    };
  }
  async function status(force = false) {
    if (!configured(config)) return state('configuration');
    await load();
    if (!session) return state('signed-out');
    if (
      !force &&
      cached &&
      now() < cached.validUntil &&
      now() >= cached.checkedAt
    )
      return cached;
    if (
      !force &&
      now() - lastAttempt < 10000 &&
      cached?.phase === 'unavailable'
    )
      return cached;
    lastAttempt = now();
    try {
      let idToken = await token(force);
      const account = (await auth('lookup', { idToken })).users?.[0];
      if (!account || account.localId !== session.uid)
        throw Error('Sessão inválida. Entre novamente.');
      session.email = account.email;
      if (!account.emailVerified)
        return (cached = {
          ...state('unverified'),
          checkedAt: now(),
          validUntil: now() + 10000,
        });
      // Refresh after verification so Firestore evaluates the new verified claim.
      if (force) idToken = await token(true);
      if (emailValue(account.email) === OWNER_EMAIL) {
        const owner = decode(await document('settings/owner'));
        if (!owner)
          return (cached = {
            ...state('owner-setup'),
            checkedAt: now(),
            validUntil: now() + 10000,
          });
        if (owner.uid === session.uid) {
          const ready = decode(await document('product/access'))?.version === 1;
          return (cached = {
            ...state(ready ? 'active' : 'owner-setup', { owner: true }),
            checkedAt: now(),
            validUntil: now() + (ready ? CACHE_MS : 10000),
          });
        }
        return state('blocked', {
          message:
            'A propriedade já está vinculada a outra identidade. Recupere a conta original no Firebase.',
        });
      }
      let license = decode(
        await document('licenses/' + encodeURIComponent(session.uid)),
      );
      if (!license) {
        await commit([
          create(
            'licenses/' + session.uid,
            {
              uid: session.uid,
              email: account.email,
              name: String(
                account.displayName || account.email.split('@')[0],
              ).slice(0, 80),
              status: 'pending',
              expiresAt: null,
              lastAuditId: null,
            },
            ['createdAt', 'updatedAt'],
          ),
        ]);
        license = decode(await document('licenses/' + session.uid));
      }
      const extra = { expiresAt: license?.expiresAt || null };
      let phase =
        license?.status === 'blocked'
          ? 'blocked'
          : license?.status === 'active'
            ? 'active'
            : 'pending';
      if (
        phase === 'active' &&
        license.expiresAt &&
        Date.parse(license.expiresAt) <= now()
      )
        phase = 'expired';
      if (phase === 'active') {
        // The server rules check confirmed email, current status and server-side expiry.
        const proof = await document('product/access');
        if (decode(proof)?.version !== 1)
          throw Error('O proprietário precisa concluir a ativação do serviço.');
      }
      return (cached = {
        ...state(phase, extra),
        checkedAt: now(),
        validUntil: Math.min(
          now() + CACHE_MS,
          phase === 'active' && extra.expiresAt
            ? Date.parse(extra.expiresAt)
            : Infinity,
        ),
      });
    } catch (error) {
      if (
        [
          'INVALID_ID_TOKEN',
          'TOKEN_EXPIRED',
          'USER_DISABLED',
          'USER_NOT_FOUND',
          'INVALID_REFRESH_TOKEN',
        ].includes(error.code)
      ) {
        await save(null);
        return state('signed-out', {
          message: 'Sua sessão expirou. Entre novamente.',
        });
      }
      return (cached = {
        ...state('unavailable', { message: error.message }),
        checkedAt: now(),
        validUntil: now() + 10000,
      });
    }
  }
  async function signIn(email, password) {
    const data = await auth('signInWithPassword', {
      email: emailValue(email),
      password,
      returnSecureToken: true,
    });
    await keep(data);
    return status(true);
  }
  async function signUp(email, password, name) {
    name = String(name || '').trim();
    if (name.length < 1 || name.length > 80)
      throw Error('Informe um nome com até 80 caracteres.');
    if (typeof password !== 'string' || password.length < 12)
      throw Error(messages.WEAK_PASSWORD);
    const data = await auth('signUp', {
      email: emailValue(email),
      password,
      returnSecureToken: true,
    });
    await keep(data);
    await auth('update', { idToken: await token(), displayName: name });
    await resend();
    return status(true);
  }
  async function resend() {
    const idToken = await token();
    await auth('sendOobCode', { requestType: 'VERIFY_EMAIL', idToken });
    return { sent: true };
  }
  async function reset(email) {
    try {
      await auth('sendOobCode', {
        requestType: 'PASSWORD_RESET',
        email: emailValue(email),
      });
    } catch (error) {
      if (error.code !== 'EMAIL_NOT_FOUND') throw error;
    }
    return { sent: true };
  }
  async function logout() {
    await save(null);
    return state('signed-out');
  }
  async function claimOwner() {
    const s = await status(true);
    if (s.phase !== 'owner-setup' && !(s.allowed && s.owner))
      throw Error(
        'Somente o e-mail proprietário confirmado pode concluir esta etapa.',
      );
    if (s.phase === 'owner-setup' && !s.owner)
      await commit([
        create('settings/owner', { uid: s.uid, email: s.email }, ['createdAt']),
      ]);
    if (!(await document('product/access')))
      await commit([create('product/access', { version: 1 })]);
    return status(true);
  }
  async function requireOwner() {
    const s = await status(true);
    if (!s.allowed || !s.owner)
      throw Error('Apenas a conta proprietária pode gerenciar acessos.');
    return s;
  }
  async function list(pageToken = '') {
    await requireOwner();
    const query = new URLSearchParams({
      pageSize: '100',
      orderBy: 'createdAt desc',
    });
    if (pageToken) query.set('pageToken', pageToken);
    const result = await request(
      base + '/licenses?' + query.toString().replace(/\+/g, '%20'),
      { token: await token() },
    );
    return {
      users: (result.documents || []).map(decode),
      nextPageToken: result.nextPageToken || null,
    };
  }
  async function manage(uid, statusValue, days) {
    const s = await requireOwner();
    if (!/^[A-Za-z0-9_-]{1,128}$/.test(uid) || uid === s.uid)
      throw Error('Não é possível alterar a conta proprietária.');
    if (
      !['active', 'blocked'].includes(statusValue) ||
      ![0, 7, 30, 90, 365].includes(days)
    )
      throw Error('Ação inválida.');
    const expiresAt =
        statusValue === 'active' && days
          ? new Date(now() + days * 86400000).toISOString()
          : null,
      id = uuid();
    await commit([
      {
        update: {
          name: docName('licenses/' + uid),
          fields: fields({
            status: statusValue,
            expiresAt: timestamp(expiresAt),
            lastAuditId: id,
          }),
        },
        updateMask: { fieldPaths: ['status', 'expiresAt', 'lastAuditId'] },
        currentDocument: { exists: true },
        updateTransforms: [
          { fieldPath: 'updatedAt', setToServerValue: 'REQUEST_TIME' },
        ],
      },
      create(
        'audit/' + id,
        {
          actorUid: s.uid,
          targetUid: uid,
          status: statusValue,
          expiresAt: timestamp(expiresAt),
        },
        ['createdAt'],
      ),
    ]);
    return { updated: true };
  }
  return {
    status,
    signIn,
    signUp,
    resend,
    reset,
    logout,
    claimOwner,
    list,
    manage,
  };
}
