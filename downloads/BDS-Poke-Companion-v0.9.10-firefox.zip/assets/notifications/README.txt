BDS notification voices

capture.wav: "Pokémon"
pheromone.wav: "Pheromone"
bronze.wav: "Token"

Generated locally with Kokoro-82M v1.0 (Apache-2.0), female voice af_heart.
https://huggingface.co/hexgrad/Kokoro-82M
https://huggingface.co/hexgrad/Kokoro-82M/blob/main/VOICES.md
ONNX export: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1

Mono PCM16 WAV, 24 kHz, approximately 0.7 seconds each.
The extension only plays these finished recordings. It does not contain or run
the model, contact a speech service, record voices, or send game data for speech.
Generation script: tools/generate-notification-voices.py in the source package.
