// Serialized by scripting.executeScript into the game's MAIN world.
// Read-only adapter: no send/request method, token, header or account store is read.
export function installLiveBridge(channel) {
  if (
    location.origin !== "https://poke.idleworld.online" ||
    location.pathname !== "/play"
  )
    return;
  window.__bdsLiveBridge?.stop?.();
  let stopped = false,
    seq = 0,
    unsub = [],
    subscription = null,
    lastLink = "",
    lastContext = "",
    lastPenalty = "",
    timer,
    lastBeat = 0;
  const text = (v, n = 100) => (typeof v === "string" ? v.slice(0, n) : null);
  const number = (v) =>
    typeof v === "number" && Number.isFinite(v) ? v : null;
  const integer = (v) => (Number.isSafeInteger(v) && v >= 0 ? v : null);
  let knownPokes = null,
    candidates = [],
    pendingCaptures = [],
    captureIds = new Set(),
    lastInventory = {},
    lastTeam = "",
    lastTeamAt = 0;
  let combatKey = "",
    nativeAfter = 0,
    previousField = null,
    fieldBatch = null,
    lastEnvironment = "",
    lastGear = "",
    lastGearAt = 0,
    fieldDefaults = null,
    mobLife = new Map(),
    waveDeadAt = null,
    tmHits = new Map();
  const tmNames = new Set([
    "Omega Clap",
    "Ignition Point",
    "Cyclonic Tide",
    "Petal Bloom",
    "Static Overload",
    "Ice Time",
    "Meteor Fists",
    "Toxic Deluge",
    "Crossing Fissure",
    "Massive Hurricane",
    "Mental Singularity",
    "Hive Crush",
    "Crumbling Rain",
    "Untold Nightmare",
    "Draconic Soul",
    "Endless Hollow",
    "Steel Flare",
    "Lovely Expulsion",
  ]);
  const telemetry = () => ({
    distanceTiles: 0,
    movementMs: 0,
    trainerTiles: 0,
    trainerMovementMs: 0,
    respawnMs: 0,
    respawnSamples: 0,
    waveMs: 0,
    waveSamples: 0,
  });
  function resetField() {
    previousField = null;
    fieldBatch = null;
    mobLife.clear();
    tmHits.clear();
    waveDeadAt = null;
    lastEnvironment = "";
  }
  function environment(e) {
    const payload = {
      key: combatKey,
      heroStepMs: number(
        e.stepMs?.hero ?? e.heroStepMs ?? fieldDefaults?.heroStepMs,
      ),
      trainerStepMs: number(
        e.stepMs?.trainer ?? e.trainerStepMs ?? fieldDefaults?.trainerStepMs,
      ),
      bike: typeof e.bike === "boolean" ? e.bike : null,
      apricorn: typeof e.apricorn === "boolean" ? e.apricorn : null,
    };
    const sig = JSON.stringify(payload);
    if (combatKey && sig !== lastEnvironment) {
      if (lastEnvironment) resetField();
      lastEnvironment = sig;
      emit("hunt-environment", payload);
    }
  }
  function field(e) {
    // Native render packets: slot -1 is damage TO the hero, not an AoE target.
    // Keep only bounded aggregates; never store the full world or send game commands.
    try {
      readContext();
    } catch {
      return;
    }
    if (
      !combatKey ||
      !Number.isSafeInteger(e?.seq) ||
      !Number.isFinite(e.serverNow) ||
      !Array.isArray(e.mobs) ||
      (e.hits != null && !Array.isArray(e.hits)) ||
      typeof e.fighting !== "boolean"
    )
      return;
    if (previousField && e.seq <= previousField.seq) return;
    environment(e);
    const now = Date.now(),
      hero = e.hero;
    if (!Number.isFinite(hero?.row) || !Number.isFinite(hero?.col)) return;
    const dt = previousField ? e.serverNow - previousField.serverNow : 0;
    if (
      previousField &&
      (dt <= 0 || dt > 5000 || now - previousField.at > 5000)
    )
      resetField();
    fieldBatch ||= {
      from: now,
      to: now,
      combatMs: 0,
      travelMs: 0,
      waitMs: 0,
      moves: {},
      ...telemetry(),
    };
    if (
      dt > 0 &&
      dt <= 5000 &&
      previousField &&
      now - previousField.at <= 5000
    ) {
      const moving =
        hero.row !== previousField.row || hero.col !== previousField.col;
      const phase = previousField.waiting
        ? "waitMs"
        : previousField.fighting
          ? "combatMs"
          : moving ||
              (Number.isInteger(previousField.targetSlot) &&
                previousField.targetSlot >= 0)
            ? "travelMs"
            : "waitMs";
      fieldBatch[phase] += dt;
      const distance = Math.hypot(
        hero.row - previousField.row,
        hero.col - previousField.col,
      );
      if (!e.teleport && phase === "travelMs" && distance <= 8) {
        fieldBatch.distanceTiles += distance;
        fieldBatch.movementMs += dt;
      }
      if (
        !e.teleport &&
        Number.isFinite(e.trainer?.row) &&
        Number.isFinite(e.trainer?.col) &&
        previousField.trainer
      ) {
        const d = Math.hypot(
          e.trainer.row - previousField.trainer.row,
          e.trainer.col - previousField.trainer.col,
        );
        if (phase === "travelMs" && d <= 8) {
          fieldBatch.trainerTiles += d;
          fieldBatch.trainerMovementMs += dt;
        }
      }
    }
    // Only complete death -> live transitions are timed; joining a hunt with
    // an already dead monster is not a full respawn sample. Storage is bounded.
    const life = new Map();
    for (const mob of e.mobs.slice(0, 256)) {
      if (
        !Number.isInteger(mob?.slot) ||
        mob.slot < 0 ||
        typeof mob.dead !== "boolean"
      )
        continue;
      const old = mobLife.get(mob.slot),
        dead = mob.dead || mob.respawning === true;
      const since = dead
        ? old?.dead
          ? old.since
          : old
            ? e.serverNow
            : null
        : null;
      if (!dead && old?.dead && old.since !== null) {
        const ms = e.serverNow - old.since;
        if (ms > 0 && ms <= 3600000) {
          fieldBatch.respawnMs += ms;
          fieldBatch.respawnSamples++;
        }
      }
      life.set(mob.slot, { dead, since });
    }
    mobLife = life;
    if (e.allMobsDead === true && previousField && !previousField.allMobsDead)
      waveDeadAt = e.serverNow;
    if (e.allMobsDead === false && waveDeadAt !== null) {
      const ms = e.serverNow - waveDeadAt;
      if (ms > 0 && ms <= 3600000) {
        fieldBatch.waveMs += ms;
        fieldBatch.waveSamples++;
      }
      waveDeadAt = null;
    }
    const slots = new Set(e.mobs.slice(0, 256).map((m) => m?.slot));
    const moves = new Map();
    for (const hit of (e.hits || []).slice(0, 256)) {
      if (
        !Number.isInteger(hit?.slot) ||
        hit.slot < 0 ||
        !slots.has(hit.slot) ||
        !(hit.amount > 0) ||
        typeof hit.move !== "string" ||
        !hit.move ||
        hit.move.length > 100
      )
        continue;
      if (!moves.has(hit.move)) moves.set(hit.move, new Set());
      moves.get(hit.move).add(hit.slot);
    }
    // Elemental damage can be staggered over several packets (e.g. Dragon).
    // Merge its targets for 3s, shorter than its published 10s cooldown.
    const completed = new Map();
    for (const [name, pending] of tmHits)
      if (e.serverNow - pending.at >= 3000) {
        completed.set(name, pending.targets);
        tmHits.delete(name);
      }
    for (const [name, targets] of moves) {
      if (!tmNames.has(name)) {
        completed.set(name, targets);
        continue;
      }
      const pending = tmHits.get(name) || {
        at: e.serverNow,
        targets: new Set(),
      };
      for (const slot of targets) pending.targets.add(slot);
      tmHits.set(name, pending);
    }
    for (const [name, targets] of completed) {
      // A batch is one move name in one server update, not an asserted cooldown/cast.
      const key = "$" + name;
      if (!fieldBatch.moves[key] && Object.keys(fieldBatch.moves).length >= 24)
        continue;
      const m = (fieldBatch.moves[key] ||= {
        name,
        batches: 0,
        targets: 0,
        maxTargets: 0,
      });
      m.batches++;
      m.targets += targets.size;
      m.maxTargets = Math.max(m.maxTargets, targets.size);
    }
    previousField = {
      seq: e.seq,
      serverNow: e.serverNow,
      at: now,
      row: hero.row,
      col: hero.col,
      fighting: e.fighting,
      waiting: e.allMobsDead === true || e.fainted === true,
      allMobsDead: e.allMobsDead === true,
      targetSlot: e.targetSlot,
      trainer:
        Number.isFinite(e.trainer?.row) && Number.isFinite(e.trainer?.col)
          ? { row: e.trainer.row, col: e.trainer.col }
          : null,
    };
    fieldBatch.to = now;
    if (now - fieldBatch.from >= 2000) {
      emit("hunt-combat", {
        ...fieldBatch,
        key: combatKey,
        moves: Object.values(fieldBatch.moves),
      });
      fieldBatch = {
        from: now,
        to: now,
        combatMs: 0,
        travelMs: 0,
        waitMs: 0,
        moves: {},
        ...telemetry(),
      };
    }
  }
  const identity = (v) =>
    typeof v === "string" && v.length <= 100
      ? v
      : Number.isSafeInteger(v)
        ? String(v)
        : null;
  function inventory(patch) {
    if (
      Object.entries(patch).some(([key, value]) => lastInventory[key] !== value)
    ) {
      Object.assign(lastInventory, patch);
      emit("inventory", patch);
    }
  }
  function balls(e) {
    if (!Array.isArray(e?.catalog) || !e.counts || typeof e.counts !== "object")
      return;
    const ball = e.catalog.find((b) => b?.name === "Ultra Ball");
    if (!ball) return;
    const raw = e.counts[String(ball.id)] ?? 0;
    const qty =
      typeof raw === "string" && /^\d+$/.test(raw) ? Number(raw) : raw;
    if (integer(qty) !== null) inventory({ ultra: qty });
  }
  function items(e) {
    if (!Array.isArray(e?.items)) return;
    const gear = {};
    for (const [key, id] of [
      ["bicycle", 90131],
      ["lure", 90132],
    ]) {
      const rows = e.items.filter((i) => i?.itemId === id && i.quantity > 0);
      const dates = rows.map((i) =>
        typeof i.expiresAt === "string" ? Date.parse(i.expiresAt) : null,
      );
      gear[key] = {
        present: rows.length > 0,
        until:
          dates.length && dates.every(Number.isFinite)
            ? Math.max(...dates)
            : rows.length
              ? null
              : 0,
      };
    }
    const sig = JSON.stringify(gear);
    if (sig !== lastGear || Date.now() - lastGearAt >= 10000) {
      if (lastGear && sig !== lastGear) resetField();
      lastGear = sig;
      lastGearAt = Date.now();
      emit("hunt-gear", gear);
    }
    const rows = e.items.filter((i) => i?.itemId === 204);
    if (rows.some((i) => integer(i.quantity) === null)) return;
    const qty = rows.reduce((sum, i) => sum + i.quantity, 0);
    if (integer(qty) !== null) inventory({ potion: qty });
  }
  const sameSpecies = (a, b) =>
    a.speciesId && b.speciesId
      ? a.speciesId === b.speciesId
      : !!a.name && a.name === b.name;
  function matchCaptures() {
    const cutoff = Date.now() - 10000;
    candidates = candidates.filter((p) => p.at >= cutoff);
    pendingCaptures = pendingCaptures.filter((p) => p.at >= cutoff);
    for (const pending of [...pendingCaptures]) {
      const matches = candidates.filter((p) => sameSpecies(p, pending));
      // Do not guess which IV belongs to a capture if several new specimens match.
      if (matches.length !== 1) continue;
      const poke = matches[0];
      pendingCaptures.splice(pendingCaptures.indexOf(pending), 1);
      candidates.splice(candidates.indexOf(poke), 1);
      emit("capture-iv", {
        id: poke.id,
        name: poke.name,
        ivTotal: poke.ivTotal,
      });
    }
  }
  function pokes(e) {
    // The game's socket assembles chunks/deltas into this full account list.
    // Family storage uses a separate `family` event / depot.pokes, never this list.
    if (e?.type && e.type !== "pokes") return;
    if (!Array.isArray(e?.list) || e.list.length > 100000) {
      teamSnapshot(null);
      inventory({
        pokemon: null,
        pokemonTeam: null,
        pokemonListed: null,
        pokemonStarter: null,
      });
      return;
    }
    const now = Date.now(),
      ids = new Set(),
      equipped = [];
    let complete = true,
      team = 0,
      listed = 0,
      starter = 0;
    for (const p of e.list) {
      const id = identity(p?.id);
      if (!id) {
        complete = false;
        continue;
      }
      if (!ids.has(id)) {
        ids.add(id);
        if (p.team) {
          team++;
          equipped.push(p);
        }
        if (p.listed) listed++;
        if (p.starter) starter++;
      }
      if (
        knownPokes &&
        !knownPokes.has(id) &&
        integer(p.ivTotal) !== null &&
        p.ivTotal <= 192
      )
        candidates.push({
          id,
          speciesId: integer(p.speciesId),
          name: text(p.name),
          ivTotal: p.ivTotal,
          at: now,
        });
    }
    // Count the current snapshot, not knownPokes (historical notification IDs).
    // Team and box are already present; do not add the HUD or family inventory.
    // Listed Pokémon and starters remain owned and count toward capture capacity.
    // These are annotations within the total, not extra Pokémon to add to it.
    inventory({
      pokemon: complete ? ids.size : null,
      pokemonTeam: complete ? team : null,
      pokemonListed: complete ? listed : null,
      pokemonStarter: complete ? starter : null,
    });
    teamSnapshot(complete && equipped.length <= 6 ? equipped : null);
    if (!knownPokes) emit("capture-ready", { ready: true });
    // Retain IDs across withdrawals/trades to avoid treating an old Pokémon as new.
    knownPokes ||= new Set();
    for (const id of ids) knownPokes.add(id);
    if (knownPokes.size > 100000) {
      knownPokes = ids;
      candidates = [];
      pendingCaptures = [];
    }
    candidates = candidates.slice(-100);
    matchCaptures();
  }
  function teamSnapshot(equipped) {
    // The public game client uses team=true, slot ordering and combatHp(hp,false)
    // = max(24, round(hp*12)). Only the six equipped specimens leave this bridge.
    const members =
      equipped
        ?.slice()
        .sort((a, b) => (integer(a.slot) ?? 99) - (integer(b.slot) ?? 99))
        .map((p) => ({
          id: identity(p.id),
          speciesId: integer(p.speciesId),
          name: text(p.name),
          level: integer(p.level),
          shiny: p.shiny === true,
          types: [text(p.type1, 20), text(p.type2, 20)].filter(Boolean),
          maxHp:
            integer(p.maxHp) ||
            (integer(p.stats?.hp) !== null
              ? Math.max(24, Math.round(p.stats.hp * 12))
              : null),
          hpSource: integer(p.maxHp) > 0 ? "observed" : "derived",
          current: {
            atk: integer(p.stats?.atk),
            def: integer(p.stats?.def),
            spa: integer(p.stats?.spAtk),
            spd: integer(p.stats?.spDef),
            vel: integer(p.stats?.speed),
          },
          tms:
            p.tms == null
              ? []
              : Array.isArray(p.tms)
                ? p.tms.slice(0, 3).map((t) => text(t, 20)?.toUpperCase())
                : null,
          modifiers: JSON.stringify([
            p.heldX ?? null,
            p.heldY ?? null,
            p.berries ?? null,
            p.addons ?? null,
          ]).slice(0, 2000),
          modifierUntil: Object.values(p.berries || {})
            .filter((v) => Number.isFinite(v))
            .slice(0, 12),
          moves: Array.isArray(p.moves)
            ? p.moves.slice(0, 12).map((m) => ({
                name: text(m?.name),
                type: text(m?.type, 20),
                category: text(m?.category, 20),
                power: integer(m?.power),
              }))
            : [],
        })) ?? null;
    const sig = JSON.stringify(members),
      now = Date.now();
    if (sig !== lastTeam || now - lastTeamAt >= 60000) {
      if (lastTeam && sig !== lastTeam) resetField();
      lastTeam = sig;
      lastTeamAt = now;
      emit("team-snapshot", { observedAt: now, members });
      emit("hunt-party", { members });
    }
  }
  const emit = (kind, payload) => {
    if (!stopped)
      window.postMessage(
        { bdsLive: channel, seq: ++seq, at: Date.now(), kind, payload },
        location.origin,
      );
  };
  function fiberFor(el) {
    if (!el) return null;
    const key = Object.keys(el).find((k) => k.startsWith("__reactFiber$"));
    let f = key ? el[key] : null;
    if (!f) return null;
    let root = f,
      n = 0;
    while (root.return && n++ < 160) root = root.return;
    if (
      root.stateNode?.current &&
      root.stateNode.current !== root &&
      f.alternate
    )
      f = f.alternate;
    return f;
  }
  function ancestors(el, read) {
    let f = fiberFor(el),
      n = 0;
    while (f && n++ < 160) {
      const found = read(f.memoizedProps, f);
      if (found) return found;
      f = f.return;
    }
    return null;
  }
  function gameContext() {
    const valid = (v) =>
      v &&
      typeof v.online === "boolean" &&
      typeof v.subscribe === "function" &&
      typeof v.requestPokes === "function" &&
      typeof v.requestBalls === "function";
    for (const el of document.querySelectorAll(
      ".game-canvas-host,.phud,.cap-panel,.dex-window",
    )) {
      const value = ancestors(el, (p, f) => {
        if (valid(p?.value)) return p.value;
        // React consumers retain the context they actually used, including during commits.
        // Read only the public game context; never inspect hooks/account/auth stores.
        let d = f.dependencies?.firstContext,
          n = 0;
        while (d && n++ < 30) {
          if (valid(d.memoizedValue)) return d.memoizedValue;
          d = d.next;
        }
        return null;
      });
      if (value) return value;
    }
    return null;
  }
  function readContext() {
    const hud = ancestors(document.querySelector(".phud"), (p) =>
      Array.isArray(p?.party) ? p : null,
    );
    const active = hud?.party.find((p) => p?.active === true),
      root = document.querySelector(".game-root");
    const world = ancestors(root, (p) =>
      p?.className?.split?.(" ").includes("game-root") ? p : null,
    );
    const elements = Array.isArray(world?.children)
      ? world.children
      : [world?.children];
    const field = elements
      .flat(2)
      .find(
        (e) =>
          typeof e?.props?.slug === "string" &&
          typeof e.props.onKill === "function",
      )?.props;
    const value = {
      active: active
        ? {
            capId: text(active.capId, 100),
            name: text(active.name),
            level: integer(active.level),
            looktype: integer(active.looktype),
            type1: text(active.type1, 20),
          }
        : null,
      location: text(hud?.location),
      huntSlug: field?.enabled === true ? text(field.slug) : null,
    };
    const sig = JSON.stringify(value);
    const key =
      value.active?.capId && value.huntSlug
        ? JSON.stringify([value.active.capId, value.huntSlug])
        : "";
    if (key !== combatKey) {
      combatKey = key;
      nativeAfter = Date.now() + 2000;
      fieldDefaults = null;
      resetField();
    }
    if (sig !== lastContext) {
      lastContext = sig;
      emit("context", value);
    }
  }
  function kill(e) {
    try {
      readContext();
    } catch {}
    emit("kill", {
      speciesId: integer(e?.speciesId),
      baseDex: integer(e?.baseDex),
      speciesName: text(e?.speciesName),
      loot: Array.isArray(e?.loot)
        ? e.loot.slice(0, 100).map((l) => ({
            itemId: integer(l?.itemId),
            name: text(l?.name),
            qty: integer(l?.qty),
          }))
        : [],
      xpGained: number(e?.xpGained),
      pokeXp: e?.pokeXp
        ? {
            speciesId: integer(e.pokeXp.speciesId),
            xpGained: number(e.pokeXp.xpGained),
          }
        : null,
    });
  }
  function nativeAnalyzer(e) {
    try {
      readContext();
    } catch {
      return;
    }
    if (!combatKey || Date.now() < nativeAfter) return;
    emit("hunt-native", {
      key: combatKey,
      seconds: number(e?.seconds),
      kills: integer(e?.kills),
      xpGained: number(e?.xpGained),
      xpPerHour: number(e?.xpPerHour),
      killsPerHour: number(e?.killsPerHour),
    });
  }
  function capture(e) {
    if (e?.success === true) {
      const id = identity(e.pendingId);
      if (id && captureIds.has(id)) return;
      if (id) {
        captureIds.add(id);
        if (captureIds.size > 4096)
          captureIds.delete(captureIds.values().next().value);
      }
      emit("capture", {
        success: true,
        speciesId: integer(e.speciesId),
        baseDex: integer(e.baseDex),
        speciesName: text(e.speciesName),
      });
      // The native result confirms success; IV comes from the next/previous new
      // specimen in the game's public pokes event, never from old log rows.
      if (knownPokes) {
        pendingCaptures.push({
          speciesId: integer(e.speciesId),
          name: text(e.speciesName),
          at: Date.now(),
        });
        pendingCaptures = pendingCaptures.slice(-100);
        matchCaptures();
      }
    }
  }
  function boosts(e) {
    if (!Array.isArray(e?.boosts)) return;
    const lock = e.boosts.find((b) => b?.key === "shinylock");
    if (lock && integer(lock.until) === null) return;
    try {
      readContext();
    } catch {}
    const payload = {
      until: lock ? integer(lock.until) : 0,
      frozen: lock?.frozen === true,
    };
    const sig = JSON.stringify([combatKey, payload]);
    if (sig !== lastPenalty) {
      lastPenalty = sig;
      emit("hunt-penalty", payload);
    }
  }
  function disconnect() {
    resetField();
    nativeAfter = Date.now() + 2000;
    fieldDefaults = null;
    lastPenalty = "";
    for (const fn of unsub)
      try {
        fn();
      } catch {}
    unsub = [];
    subscription = null;
  }
  function poll() {
    if (stopped) return;
    if (location.pathname !== "/play") {
      stop();
      return;
    }
    const ctx = gameContext();
    if (subscription !== ctx?.subscribe) {
      disconnect();
      if (ctx) {
        const offKill = ctx.subscribe("field-kill", kill);
        unsub.push(offKill);
        const offCapture = ctx.subscribe("catch-result", capture);
        unsub.push(offCapture);
        unsub.push(ctx.subscribe("boosts", boosts));
        unsub.push(ctx.subscribe("balls", balls));
        unsub.push(ctx.subscribe("inventory", items));
        unsub.push(ctx.subscribe("pokes", pokes));
        unsub.push(ctx.subscribe("field", field));
        unsub.push(ctx.subscribe("analyzer", nativeAnalyzer));
        unsub.push(
          ctx.subscribe("field-init", (e) => {
            try {
              readContext();
            } catch {
              return;
            }
            if (combatKey && e?.slug === JSON.parse(combatKey)[1]) {
              resetField();
              fieldDefaults = {
                heroStepMs: number(e.heroStepMs),
                trainerStepMs: number(e.trainerStepMs),
              };
              environment(e);
            }
          }),
        );
        subscription = ctx.subscribe;
      }
    }
    const link = { connected: !!ctx, online: ctx?.online === true },
      sig = JSON.stringify(link);
    if (sig !== lastLink) {
      if (!link.connected || !link.online) {
        teamSnapshot(null);
        lastGear = "";
        resetField();
        knownPokes = null;
        candidates = [];
        pendingCaptures = [];
        emit("capture-ready", { ready: false });
        inventory({
          ultra: null,
          potion: null,
          pokemon: null,
          pokemonTeam: null,
          pokemonListed: null,
          pokemonStarter: null,
        });
      }
      lastLink = sig;
      emit("link", link);
    }
    try {
      readContext();
    } catch {}
    if (Date.now() - lastBeat >= 5000) {
      lastBeat = Date.now();
      emit("heartbeat", {});
    }
  }
  // Observe only Pokédex/Gyms GETs that the player causes the game to issue.
  // Forward the original response unchanged and clone only its progress fields.
  const originalFetch = window.fetch;
  function observedFetch(...args) {
    if (stopped) return Reflect.apply(originalFetch, this, args);
    let observe = null;
    const observedAt = Date.now();
    try {
      const input = args[0],
        url = new URL(
          typeof input === "string" || input instanceof URL
            ? String(input)
            : input.url,
          location.href,
        );
      const method =
        args[1]?.method ||
        (typeof input === "object" ? input.method : null) ||
        "GET";
      if (
        url.origin === location.origin &&
        ["/api/game/pokedex", "/api/game/gyms"].includes(url.pathname) &&
        method.toUpperCase() === "GET"
      )
        observe = url.pathname;
    } catch {}
    const promise = Reflect.apply(originalFetch, this, args);
    if (observe)
      promise
        .then((response) => {
          if (stopped || !response.ok) return;
          const snapshotSeq = seq;
          if (observe === "/api/game/gyms") {
            response
              .clone()
              .json()
              .then((data) => {
                if (!Array.isArray(data?.details) || data.details.length > 18)
                  return;
                const rows = data.details.map((g) => ({
                  id: text(g.id, 40),
                  isNpc: g.defender?.isNpc,
                  name: text(g.defender?.name),
                  sinceAt: text(g.defender?.sinceAt, 50),
                  defenses: integer(g.defender?.defenses),
                  team: Array.isArray(g.team)
                    ? g.team.slice(0, 6).map((p) => ({
                        speciesId: integer(p.speciesId),
                        name: text(p.name),
                        level: integer(p.level),
                        shiny: p.shiny === true,
                        maxHp: integer(p.maxHp),
                        current: {
                          atk: integer(p.stats?.atk),
                          def: integer(p.stats?.def),
                          spa: integer(p.stats?.spAtk),
                          spd: integer(p.stats?.spDef),
                          vel: integer(p.stats?.speed),
                        },
                        moves: Array.isArray(p.moves)
                          ? p.moves.slice(0, 12).map((m) => ({
                              name: text(m.name),
                              type: text(m.type, 20),
                              category: text(m.category, 20),
                              power: integer(m.power),
                            }))
                          : [],
                      }))
                    : null,
                }));
                emit("gym-snapshot", { observedAt, rows });
              })
              .catch(() => {});
            return;
          }
          response
            .clone()
            .json()
            .then((data) => {
              if (!Array.isArray(data?.species) || data.species.length > 1000)
                return;
              const threshold = integer(data.unlockKills) || 100,
                rows = data.species
                  .filter(
                    (r) =>
                      Number.isSafeInteger(r.id) &&
                      r.id > 0 &&
                      Number.isSafeInteger(r.kills) &&
                      r.kills >= 0 &&
                      typeof r.caught === "boolean" &&
                      typeof r.unlocked === "boolean",
                  )
                  .map((r) => ({
                    id: r.id,
                    kills: r.kills,
                    caught: r.caught,
                    complete: r.unlocked,
                    threshold,
                    atLeast: false,
                  }));
              emit("dex-snapshot", { rows, threshold, snapshotSeq });
            })
            .catch(() => {});
        })
        .catch(() => {});
    return promise;
  }
  window.fetch = observedFetch;
  function command(e) {
    if (
      e.source === window &&
      e.origin === location.origin &&
      e.data?.bdsLiveControl === channel &&
      e.data.command === "stop"
    )
      stop();
  }
  function stop() {
    if (stopped) return;
    stopped = true;
    clearInterval(timer);
    disconnect();
    knownPokes = null;
    candidates = [];
    pendingCaptures = [];
    captureIds.clear();
    lastInventory = {};
    window.removeEventListener("message", command);
    if (window.fetch === observedFetch) window.fetch = originalFetch;
  }
  function safePoll() {
    try {
      poll();
    } catch (error) {
      disconnect();
      emit("link", {
        connected: false,
        online: false,
        error: "Não foi possível conectar os eventos do jogo.",
      });
    }
  }
  window.addEventListener("message", command);
  window.__bdsLiveBridge = { stop };
  safePoll();
  timer = setInterval(safePoll, 1000);
  return { installed: true };
}
