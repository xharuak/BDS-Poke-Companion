// Preferences and decisions are local to one bound game account.
export const DEFAULT_NOTIFICATIONS = Object.freeze({
  capture: false,
  minIV: 160,
  bronze: false,
  pheromone: false,
  volume: 50,
});
export function notificationSettings(value = {}) {
  return {
    capture: value.capture === true,
    minIV:
      Number.isInteger(value.minIV) && value.minIV >= 0 && value.minIV <= 192
        ? value.minIV
        : 160,
    bronze: value.bronze === true,
    pheromone: value.pheromone === true,
    volume:
      Number.isInteger(value.volume) && value.volume >= 1 && value.volume <= 100
        ? value.volume
        : 50,
  };
}
export function inventoryUpdate(previous = {}, payload = {}) {
  const next = { ...previous };
  for (const key of ['ultra', 'potion', 'pokemon']) {
    if (
      payload[key] === null ||
      (Number.isSafeInteger(payload[key]) && payload[key] >= 0)
    )
      next[key] = payload[key];
  }
  if (
    payload.pokemon === null ||
    (Number.isSafeInteger(payload.pokemon) && payload.pokemon >= 0)
  ) {
    const details = ['pokemonTeam', 'pokemonListed', 'pokemonStarter'];
    for (const key of details) delete next[key];
    if (
      payload.pokemon !== null &&
      details.every(
        (key) =>
          Number.isSafeInteger(payload[key]) &&
          payload[key] >= 0 &&
          payload[key] <= payload.pokemon,
      )
    )
      for (const key of details) next[key] = payload[key];
  }
  return next;
}
export function notificationsFor(event, prefs) {
  const settings = notificationSettings(prefs),
    p = event.payload || {};
  if (
    event.kind === 'capture-iv' &&
    settings.capture &&
    typeof p.id === 'string' &&
    p.id.length > 0 &&
    p.id.length <= 100 &&
    Number.isInteger(p.ivTotal) &&
    p.ivTotal >= settings.minIV &&
    p.ivTotal <= 192
  ) {
    return [
      {
        kind: 'capture',
        text: `${String(p.name || 'Pokémon').slice(0, 100)} · IV ${p.ivTotal}/192`,
      },
    ];
  }
  if (event.kind !== 'kill' || !Array.isArray(p.loot)) return [];
  return [
    ['bronze', 70000, 'Bronze Boss Token'],
    ['pheromone', 44417, 'Strange Pheromone'],
  ].flatMap(([kind, id, name]) => {
    if (!settings[kind]) return [];
    const qty = p.loot
      .filter(
        (l) =>
          l &&
          (l.itemId === id || (l.itemId == null && l.name === name)) &&
          Number.isSafeInteger(l.qty) &&
          l.qty > 0,
      )
      .reduce((sum, l) => sum + l.qty, 0);
    return Number.isSafeInteger(qty) && qty > 0
      ? [{ kind, text: `${name} ×${qty}` }]
      : [];
  });
}
