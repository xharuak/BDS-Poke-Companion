import { findSpecies } from "./core.js";
import { bestMove } from "./battle.js";
import { observeNativeAnalyzer } from "./hunt-native.js";
import {
  cleanHuntParty,
  cleanHuntGear,
  cleanHuntEnvironment,
  personalSetup,
  TELEMETRY_SUMS,
  personalWork,
  personalCost,
  attackRates,
  respawnObservation,
} from "./hunt-personal.js";
export const ENTRY_PENALTY_MS = 60000;
const counters = () => ({
  kills: 0,
  pokeXp: 0,
  trainerXp: 0,
  pokeSamples: 0,
  trainerSamples: 0,
});
function addCombat(run, p) {
  // Discard batches crossing a reset/entry cutoff rather than backfilling old hits.
  if (p.from < run.start || p.from < (run.combat?.to || 0)) return;
  const old = run.combat || { combatMs: 0, travelMs: 0, waitMs: 0, moves: {} };
  const moves = { ...old.moves };
  for (const m of p.moves) {
    const key = "$" + m.name;
    if (!moves[key] && Object.keys(moves).length >= 24) continue;
    const prev = moves[key] || { batches: 0, targets: 0, maxTargets: 0 };
    moves[key] = {
      name: m.name,
      batches: prev.batches + m.batches,
      targets: prev.targets + m.targets,
      maxTargets: Math.max(prev.maxTargets, m.maxTargets),
    };
  }
  run.combat = {
    to: p.to,
    combatMs: old.combatMs + p.combatMs,
    travelMs: old.travelMs + p.travelMs,
    waitMs: old.waitMs + p.waitMs,
    moves,
    ...Object.fromEntries(
      TELEMETRY_SUMS.map((k) => [k, (old[k] || 0) + (p[k] || 0)]),
    ),
  };
}
function validCombat(p, run, at) {
  return (
    p.key === JSON.stringify([run.capId, run.slug]) &&
    Number.isFinite(p.from) &&
    Number.isFinite(p.to) &&
    p.to > p.from &&
    p.to <= at &&
    at - p.to <= 5000 &&
    p.to - p.from <= 10000 &&
    ["combatMs", "travelMs", "waitMs"].every(
      (k) => Number.isFinite(p[k]) && p[k] >= 0,
    ) &&
    p.combatMs + p.travelMs + p.waitMs <= (p.to - p.from) * 1.5 + 1000 &&
    TELEMETRY_SUMS.every(
      (k) =>
        p[k] === undefined ||
        (Number.isFinite(p[k]) &&
          p[k] >= 0 &&
          p[k] <=
            (k.endsWith("Samples") ? 256 : k.endsWith("Tiles") ? 10000 : 1e9)),
    ) &&
    Array.isArray(p.moves) &&
    p.moves.length <= 24 &&
    p.moves.every(
      (m) =>
        typeof m.name === "string" &&
        m.name.length > 0 &&
        m.name.length <= 100 &&
        Number.isSafeInteger(m.batches) &&
        m.batches > 0 &&
        m.batches <= 1000 &&
        Number.isSafeInteger(m.targets) &&
        m.targets >= m.batches &&
        m.targets <= m.batches * 256 &&
        Number.isSafeInteger(m.maxTargets) &&
        m.maxTargets >= 1 &&
        m.maxTargets <= 256,
    )
  );
}
function countKill(run, e) {
  run.kills++;
  if (
    Number.isFinite(e.pokeXp?.xpGained) &&
    e.pokeXp.xpGained >= 0 &&
    e.pokeXp.speciesId === run.speciesId
  ) {
    run.pokeXp += e.pokeXp.xpGained;
    run.pokeSamples++;
  }
  if (Number.isFinite(e.xpGained) && e.xpGained >= 0) {
    run.trainerXp += e.xpGained;
    run.trainerSamples++;
  }
}

export function activeSpecies(active, creatures) {
  if (!active) return null;
  const byId = creatures.find((c) => c.pokeId === active.speciesId);
  if (byId) return byId;
  const named = findSpecies(creatures, active.name);
  if (named) return named;
  const looks = creatures.filter((c) => c.looktype === active.looktype);
  return looks.length === 1 ? looks[0] : null;
}
export function huntEvent(state = {}, event, creatures) {
  const s = { ...state, runs: [...(state.runs || [])] },
    at = event.at;
  function finish(end = at) {
    if (s.run) {
      const run = { ...s.run, end: Math.max(s.run.start, end) };
      if (run.kills) s.runs.push(run);
      s.runs = s.runs.slice(-60);
      s.run = null;
    }
  }
  // No unobserved time is attributed to a hunt after a suspended tab or lost adapter.
  if (s.lastSeen && at - s.lastSeen > 15000) {
    finish(s.lastSeen);
    s.party = null;
    s.gear = null;
    s.environment = null;
    s.penaltyUntil = at + ENTRY_PENALTY_MS;
    s.penaltySource = "conservative";
  }
  if (event.kind === "link") {
    s.online =
      event.payload.connected === true && event.payload.online === true;
    if (!s.online) {
      finish(at);
      s.party = null;
      s.gear = null;
      s.environment = null;
    }
  }
  if (event.kind === "context") {
    if (
      s.slug !== event.payload.huntSlug ||
      s.active?.capId !== event.payload.active?.capId
    )
      s.environment = null;
    if (s.slug !== event.payload.huntSlug) {
      s.penaltyUntil = event.payload.huntSlug ? at + ENTRY_PENALTY_MS : 0;
      s.penaltySource = s.slug === undefined ? "conservative" : "entry";
      s.penaltyFrozen = false;
    }
    s.active = event.payload.active;
    s.slug = event.payload.huntSlug;
    const species = activeSpecies(s.active, creatures);
    s.active = s.active
      ? { ...s.active, speciesId: species?.pokeId || null }
      : null;
    if (
      s.run &&
      (s.run.capId !== s.active?.capId ||
        s.run.slug !== s.slug ||
        s.run.speciesId !== s.active?.speciesId)
    )
      finish(at);
  }
  if (event.kind === "hunt-party") s.party = cleanHuntParty(event.payload);
  if (event.kind === "hunt-gear") s.gear = cleanHuntGear(event.payload);
  if (event.kind === "hunt-environment") {
    const value = cleanHuntEnvironment(
      event.payload,
      JSON.stringify([s.active?.capId, s.slug]),
    );
    if (value) s.environment = value;
  }
  const setup = personalSetup(s, at);
  if (s.run && s.run.setupKey !== setup.key) finish();
  if (event.kind === "hunt-penalty") {
    const { until, frozen } = event.payload;
    const changed = until !== s.penaltyUntil || frozen !== !!s.penaltyFrozen,
      wasFrozen = s.penaltyFrozen;
    // The game's public boosts event identifies shinylock and its real expiry.
    // A new debuff in the same map starts a new observation segment too.
    if (
      s.run &&
      ((until > at && until > (s.penaltyUntil || 0) + 1500) ||
        (frozen && !s.penaltyFrozen))
    )
      finish(at);
    s.penaltyUntil = until;
    s.penaltySource = "game";
    s.penaltyFrozen = frozen;
    if (s.run && s.run.steady) {
      const start = Math.max(s.run.start, until);
      if (
        changed &&
        (until > s.run.steady.start ||
          s.run.steady.start > at ||
          wasFrozen ||
          frozen)
      ) {
        // Do not backfill XP that was excluded before the timer was known.
        s.run = {
          ...s.run,
          steady: {
            start: Math.max(at, start),
            speciesId: s.run.speciesId,
            ...counters(),
          },
        };
      }
    }
  }
  if (s.online && s.active?.capId && s.active?.speciesId && s.slug && !s.run) {
    s.run = {
      capId: s.active.capId,
      speciesId: s.active.speciesId,
      name: s.active.name,
      slug: s.slug,
      start: at,
      levelMin: s.active.level,
      levelMax: s.active.level,
      setupKey: setup.key,
      ...counters(),
      steady: {
        start: Math.max(at, s.penaltyUntil || 0),
        speciesId: s.active.speciesId,
        ...counters(),
      },
    };
  }
  if (s.run) {
    s.run = {
      ...s.run,
      steady: s.run.steady ? { ...s.run.steady } : null,
      last: at,
      environment: s.environment,
      penaltyUntil: s.penaltyUntil || 0,
      penaltySource: s.penaltySource,
      penaltyFrozen: s.penaltyFrozen,
      levelMin: Math.min(s.run.levelMin, s.active.level),
      levelMax: Math.max(s.run.levelMax, s.active.level),
    };
  }
  if (event.kind === "kill" && s.run) {
    // Never substitute trainer XP, base XP, or an ally's XP for the active Pokémon's gain.
    countKill(s.run, event.payload);
    if (s.run.steady && at >= s.run.steady.start && !s.penaltyFrozen)
      countKill(s.run.steady, event.payload);
  }
  if (event.kind === "hunt-native" && s.run) {
    const native = observeNativeAnalyzer(s.run, event.payload, at);
    if (native) s.run.native = native;
  }
  if (
    event.kind === "hunt-combat" &&
    s.run &&
    validCombat(event.payload, s.run, at)
  ) {
    addCombat(s.run, event.payload);
    if (s.run.steady && !s.penaltyFrozen)
      addCombat(s.run.steady, event.payload);
  }
  s.lastSeen = at;
  return s;
}
export function resetHunt(state = {}, at = Date.now(), creatures = []) {
  // Reset the measurement, not the game's entry timer, active Pokémon or map.
  return huntEvent(
    { ...state, runs: [], run: null, lastSeen: at },
    { kind: "heartbeat", payload: {}, at },
    creatures,
  );
}
function metrics(run, end) {
  const seconds = Math.max(0, (end - run.start) / 1000);
  const complete = run.kills > 0 && run.pokeSamples === run.kills;
  return {
    ...run,
    seconds,
    complete,
    reliable: complete && seconds >= 120 && run.kills >= 20,
    xpHour: complete && seconds > 0 ? (run.pokeXp * 3600) / seconds : null,
    trainerHour:
      run.trainerSamples === run.kills && seconds > 0
        ? (run.trainerXp * 3600) / seconds
        : null,
    killsHour: seconds > 0 ? (run.kills * 3600) / seconds : null,
    secondsKill: run.kills ? seconds / run.kills : null,
    xpKill: complete ? run.pokeXp / run.kills : null,
  };
}
export function runMetrics(run, now = Date.now()) {
  const end = run.end ?? Math.min(now, (run.last || run.start) + 15000);
  const total = metrics(run, end),
    steady = run.steady ? metrics(run.steady, end) : null;
  return {
    ...total,
    steady,
    reliable: !!steady?.reliable && !run.penaltyFrozen,
    penaltyRemaining: Math.max(0, ((run.penaltyUntil || 0) - end) / 1000),
  };
}
export function measuredHunts(state, regions, hunts, now = Date.now()) {
  const bySlug = new Map(hunts.map((h) => [h.slug, h])),
    active = state?.active;
  return [...(state?.runs || []), ...(state?.run ? [state.run] : [])]
    .filter(
      (r) =>
        r.capId === active?.capId &&
        regions.includes(bySlug.get(r.slug)?.region),
    )
    .map((r) => ({
      ...runMetrics(r, now),
      hunt: bySlug.get(r.slug),
      comparable:
        r.setupKey === personalSetup(state, now).key &&
        r.levelMax <= r.levelMin * 1.1 &&
        active.level >= r.levelMin * 0.95 &&
        active.level <= r.levelMax * 1.05,
    }))
    .sort((a, b) => (b.steady?.xpHour ?? -1) - (a.steady?.xpHour ?? -1));
}
export function spawnGeometry(spawns, region = null) {
  if (!Array.isArray(spawns) || !spawns.length) return null;
  if (spawns.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y)))
    return null;
  // Compact adjacent spawns form a group. Complete-link diameter prevents a
  // long chain of nearby individuals from merging the whole map into one group.
  const groups = [];
  const ordered = spawns
    .map((_, i) => i)
    .sort((a, b) => spawns[a].x - spawns[b].x || spawns[a].y - spawns[b].y);
  // Nightmare's public points are more spread out than Orre's 1-tile packs.
  // Apply the player's four-member rule, using nearest remaining points. This
  // is an explicitly labelled spatial estimate, not a server group identifier.
  if (region === "nightmare") {
    const remaining = new Set(ordered);
    while (remaining.size) {
      const seed = remaining.values().next().value;
      const indices = [...remaining]
        .sort(
          (a, b) =>
            Math.hypot(
              spawns[a].x - spawns[seed].x,
              spawns[a].y - spawns[seed].y,
            ) -
            Math.hypot(
              spawns[b].x - spawns[seed].x,
              spawns[b].y - spawns[seed].y,
            ),
        )
        .slice(0, 4);
      indices.forEach((i) => remaining.delete(i));
      groups.push({ indices });
    }
  }
  for (const index of region === "nightmare" ? [] : ordered) {
    const p = spawns[index];
    const group = groups.find(
      (g) =>
        !["kanto", "outland"].includes(region) &&
        (!["orre", "nightmare"].includes(region) || g.indices.length < 4) &&
        g.indices.some(
          (i) =>
            Math.hypot(p.x - spawns[i].x, p.y - spawns[i].y) <=
            Math.SQRT2 + 0.001,
        ) &&
        g.indices.every(
          (i) => Math.hypot(p.x - spawns[i].x, p.y - spawns[i].y) <= 2.5,
        ),
    );
    if (group) group.indices.push(index);
    else groups.push({ indices: [index] });
  }
  for (const g of groups) {
    g.size = g.indices.length;
    g.x = g.indices.reduce((n, i) => n + spawns[i].x, 0) / g.size;
    g.y = g.indices.reduce((n, i) => n + spawns[i].y, 0) / g.size;
    g.normalCapacity = g.indices.filter(
      (i) =>
        Math.abs(spawns[i].x - g.x) <= 6 && Math.abs(spawns[i].y - g.y) <= 6,
    ).length;
    g.tmCapacity = g.indices.filter(
      (i) =>
        Math.abs(spawns[i].x - g.x) <= 3 && Math.abs(spawns[i].y - g.y) <= 3,
    ).length;
  }
  // Distance between group centers, not between members of the same group.
  const distance =
    groups.length > 1
      ? groups.reduce(
          (sum, p, i) =>
            sum +
            Math.min(
              ...groups
                .filter((_, j) => i !== j)
                .map((q) => Math.hypot(p.x - q.x, p.y - q.y)),
            ),
          0,
        ) / groups.length
      : null;
  return {
    count: spawns.length,
    distance,
    groups,
    groupCount: groups.length,
    groupSize: spawns.length / groups.length,
    inferredGroups: region === "nightmare",
    travelPerKill:
      distance === null ? null : (distance * groups.length) / spawns.length,
  };
}
export function spawnDescription(geometry, region) {
  if (!geometry) return "Spawns não identificados";
  const distance = Number.isFinite(geometry.distance)
    ? geometry.distance.toLocaleString("pt-BR", { maximumFractionDigits: 1 })
    : "—";
  if (["kanto", "outland"].includes(region))
    return `${geometry.count} monstros · ${geometry.count} pontos de spawn individuais · ${distance} tiles entre pontos`;
  return `${geometry.count} monstros · ${geometry.groupCount} grupos · ${geometry.groupSize.toLocaleString("pt-BR", { maximumFractionDigits: 1 })} monstros/grupo · ${distance} tiles entre grupos${geometry.inferredGroups ? " · agrupamento aproximado" : ""}`;
}
export function huntProfile(
  hunt,
  spawns,
  attacker,
  level,
  creatures,
  chart,
  loadout = null,
) {
  const geometry = spawnGeometry(spawns, hunt.region);
  if (!geometry || !attacker) return null;
  const targets = spawns.map((p) =>
    creatures.find((c) => c.pokeId === p.pokeId),
  );
  if (
    targets.some(
      (c) => !c || !Number.isFinite(c.experience) || !Number.isFinite(c.baseHp),
    )
  )
    return null;
  const movesByTarget = new Map();
  const results = targets.map((c) => {
    if (!movesByTarget.has(c))
      movesByTarget.set(
        c,
        bestMove(chart, attacker, c, level, loadout?.current),
      );
    return { c, best: movesByTarget.get(c) };
  });
  const personal = loadout
    ? personalWork(geometry, targets, hunt, attacker, loadout, chart)
    : null;
  if (results.some((r) => !r.best || r.best.score <= 0) && !personal)
    return null;
  // Same attacker/quality throughout. Target HP and defense scale with level;
  // this is a sensitivity proxy, deliberately not a claim about server damage.
  const burden =
    results.reduce(
      (n, { c, best }) =>
        n + (c.baseHp * Math.max(1, hunt.level) ** 2) / best.score,
      0,
    ) / targets.length;
  const xp = targets.reduce((n, c) => n + c.experience, 0) / targets.length;
  const work = geometry.groups.map((g) => {
    const buckets = new Map();
    for (const i of g.indices) {
      const { c, best } = results[i],
        amount = (c.baseHp * Math.max(1, hunt.level) ** 2) / best.score;
      const b = buckets.get(best.move.name) || {
        move: best.move.name,
        size: 0,
        total: 0,
        max: 0,
      };
      b.size++;
      b.total += amount;
      b.max = Math.max(b.max, amount);
      buckets.set(b.move, b);
    }
    return [...buckets.values()];
  });
  return {
    hunt,
    ...geometry,
    burden,
    xp,
    moves: [...new Set(results.map((r) => r.best.move.name))],
    work,
    personal,
  };
}
// Cache only the current species/level. Level-ups never grow an unbounded cache.
export function createHuntProfiler(creatures, chart, records) {
  let previousAttacker, previousLevel, previousSetup;
  const profiles = new Map();
  return (hunt, attacker, level, loadout = null) => {
    const setup = JSON.stringify(loadout);
    if (
      attacker !== previousAttacker ||
      level !== previousLevel ||
      setup !== previousSetup
    ) {
      profiles.clear();
      previousAttacker = attacker;
      previousLevel = level;
      previousSetup = setup;
    }
    if (!profiles.has(hunt.slug))
      profiles.set(
        hunt.slug,
        huntProfile(
          hunt,
          records[hunt.slug]?.spawns,
          attacker,
          level,
          creatures,
          chart,
          loadout,
        ),
      );
    return profiles.get(hunt.slug);
  };
}
function combatCost(profile, area) {
  if (!profile.work) return profile.burden;
  return (
    profile.work
      .flat()
      .reduce(
        (n, b) =>
          n +
          Math.max(b.max, b.total / Math.min(b.size, area["$" + b.move] || 1)),
        0,
      ) / profile.count
  );
}
export function combatObservation(measurement) {
  const m = measurement?.steady || measurement,
    c = m?.combat;
  const total = c ? c.combatMs + c.travelMs + c.waitMs : 0;
  const covered = total >= 30000 && total >= (m?.seconds || 0) * 700;
  const area = Object.fromEntries(
    Object.values(c?.moves || {})
      .filter((x) => x.batches >= 5)
      .map((x) => ["$" + x.name, x.targets / x.batches]),
  );
  return {
    covered,
    total,
    area,
    combat: total ? c.combatMs / total : 0,
    travel: total ? c.travelMs / total : 0,
    wait: total ? c.waitMs / total : 0,
  };
}
export function projectHunt(reference, target, measurement, travel = "auto") {
  if (!measurement.reliable) return null;
  measurement = measurement.steady || measurement;
  if (
    !measurement.reliable ||
    !measurement.xpKill ||
    !measurement.secondsKill ||
    !reference?.distance ||
    !target?.distance ||
    !reference.xp ||
    !reference.burden
  )
    return null;
  const observed = combatObservation(measurement),
    combat =
      combatCost(target, observed.area) / combatCost(reference, observed.area),
    spacing =
      (target.travelPerKill ?? target.distance) /
      (reference.travelPerKill ?? reference.distance),
    wait = observed.covered ? observed.wait : 0;
  const xp = (measurement.xpKill * target.xp) / reference.xp;
  const estimate = (f, fightRatio = combat) =>
    (xp * 3600) /
    (measurement.secondsKill *
      (wait + (1 - wait) * ((1 - f) * fightRatio + f * spacing)));
  const chosen =
    travel === "auto"
      ? observed.covered && wait < 1
        ? observed.travel / (1 - wait)
        : 0.5
      : Math.max(0, Math.min(1, Number(travel) || 0));
  const cases = [0.2, 0.5, 0.8].map((f) => estimate(f));
  // Sensitivity also includes serial combat; no unobserved four-target bonus.
  cases.push(
    ...[0.2, 0.5, 0.8].map((f) =>
      estimate(f, target.burden / reference.burden),
    ),
  );
  const value = estimate(chosen);
  cases.push(value);
  return Number.isFinite(value)
    ? {
        xpHour: value,
        low: Math.min(...cases),
        high: Math.max(...cases),
        combatRatio: combat,
        spacingRatio: spacing,
        timingObserved: travel === "auto" && observed.covered,
        areaObserved: Object.keys(observed.area).length > 0,
      }
    : null;
}

export function projectPersonalHunt(
  reference,
  target,
  measurement,
  targetMeasurement = null,
) {
  if (
    !measurement?.reliable ||
    !measurement.comparable ||
    !reference?.personal ||
    !target?.personal
  )
    return null;
  const m = measurement.steady || measurement;
  const sameMap = reference.hunt.slug === target.hunt.slug;
  // The catalog's relative XP is not a verified conversion between regions.
  // In particular Orre Vibrava lists 1,508, versus 13,508 for Ancient Marowak;
  // multiplying the observed Orre XP by that ratio produced fictitious 360M/h.
  // Require actual XP/kill and respawn from THIS target and account instead.
  const targetSample = sameMap ? measurement : targetMeasurement;
  const t = targetSample?.steady || targetSample;
  if (
    !targetSample?.comparable ||
    !t?.complete ||
    !(t.xpKill > 0) ||
    t.kills < 5
  )
    return null;
  if (
    targetSample.native?.check?.consistent === false ||
    measurement.native?.check?.consistent === false
  )
    return null;
  if (sameMap || targetSample.reliable) {
    if (!(t.secondsKill > 0)) return null;
    const xpHour = (t.xpKill * 3600) / t.secondsKill;
    return {
      xpHour,
      low: xpHour,
      high: xpHour,
      combatRatio: 1,
      spacingRatio: 1,
      timingObserved: true,
      respawnKnown: true,
      sameMap,
      measured: true,
      tmObserved: true,
      secondsKill: t.secondsKill,
      xpKill: t.xpKill,
    };
  }
  const respawn = respawnObservation(t);
  const respawnKnown = respawn.seconds != null || respawn.waveSeconds != null;
  if (!respawnKnown) return null;
  const observed = combatObservation(m),
    rates = attackRates(m, reference.personal);
  if (
    !observed.covered ||
    !rates ||
    !m.secondsKill ||
    !m.xpKill ||
    !reference.travelPerKill ||
    !target.travelPerKill
  )
    return null;
  const baseCost = personalCost(reference.personal, rates);
  const combatRatio = personalCost(target.personal, rates) / baseCost;
  if (!Number.isFinite(combatRatio)) return null;
  const spacingRatio = target.travelPerKill / reference.travelPerKill;
  const xpKill = t.xpKill;
  // Travel time is calibrated to the CURRENT specimen/account, including its
  // real step speed and bike. Respawn measurements already include the lure.
  // Neither +30% description is applied a second time to the measured XP.
  const fightSeconds = m.secondsKill * observed.combat;
  const travelSeconds = m.secondsKill * observed.travel;
  const scale = fightSeconds / baseCost;
  if (!(scale > 0) || !Number.isFinite(scale)) return null;
  const time = (serial, travel) => {
    const active =
      personalCost(target.personal, rates, serial, scale) +
      travelSeconds * travel;
    if (respawn.waveSeconds != null)
      return active + respawn.waveSeconds / target.count;
    if (respawn.seconds != null)
      return Math.max(active, respawn.seconds / target.count);
    return Infinity;
  };
  const secondsKill = time(false, spacingRatio);
  const xpHour = (xpKill * 3600) / secondsKill;
  if (!Number.isFinite(xpHour) || xpHour <= 0) return null;
  const scenarios = [
    xpHour,
    (xpKill * 3600) / time(false, spacingRatio * 0.75),
    (xpKill * 3600) / time(true, spacingRatio * 1.25),
  ].filter(Number.isFinite);
  return {
    xpHour,
    low: Math.min(...scenarios),
    high: Math.max(...scenarios),
    combatRatio,
    spacingRatio,
    timingObserved: true,
    respawnKnown,
    sameMap,
    measured: false,
    secondsKill,
    xpKill,
    tmObserved: rates.tmObserved,
  };
}
