import { cleanDexRows } from './dex.js';
import { normalize } from './core.js';
// Only the short response-clone race needs replay, not hours of loot/XP history.
export function rememberDexEvent(stream, event) {
  const cutoff = event.at - 120000;
  const recent = (stream.recent || []).filter((e) => e.at >= cutoff);
  const removed = (stream.recent || []).filter((e) => e.at < cutoff);
  if (removed.length)
    stream.recentFloorSeq = Math.max(
      stream.recentFloorSeq || 0,
      removed.at(-1).seq,
    );
  const { speciesId, baseDex, speciesName, success } = event.payload;
  recent.push({
    kind: event.kind,
    seq: event.seq,
    at: event.at,
    payload: { speciesId, baseDex, speciesName, success },
  });
  if (recent.length > 4096)
    stream.recentFloorSeq = Math.max(
      stream.recentFloorSeq || 0,
      recent[recent.length - 4097].seq,
    );
  stream.recent = recent.slice(-4096);
}
export function eventSpecies(event, creatures) {
  const normal = (id) =>
    creatures.find((c) => c.pokeId === id && id > 0 && id < 10000);
  if (normal(event.baseDex)) return event.baseDex;
  const wild = creatures.find((c) => c.pokeId === event.speciesId);
  if (wild) {
    if (normal(wild.captureBase)) return wild.captureBase;
    if (normal(wild.pokeId)) return wild.pokeId;
  }
  const matches = creatures.filter(
    (c) => normalize(c.name) === normalize(event.speciesName),
  );
  const ids = [
    ...new Set(
      matches.map(
        (c) =>
          normal(c.captureBase)?.pokeId || normal(c.pokeId)?.pokeId || null,
      ),
    ),
  ];
  return ids.length === 1 ? ids[0] : null;
}
export function updateDexEvent(progress, event, creatures) {
  if (!progress?.rows || !['kill', 'capture'].includes(event.kind))
    return progress;
  const id = eventSpecies(event.payload, creatures),
    previous = progress.rows[id];
  // Never pretend an unobserved lifetime count or capture history is zero.
  if (!previous) return progress;
  const row = { ...previous };
  if (event.kind === 'capture') {
    if (event.payload.success !== true) return progress;
    row.caught = true;
  } else if (row.kills !== null) {
    row.kills++;
    if (progress.gap) row.atLeast = true;
    if (row.threshold && row.kills >= row.threshold) row.complete = true;
  } else return progress;
  return {
    ...progress,
    rows: { ...progress.rows, [id]: row },
    revision: (progress.revision || 0) + 1,
    updatedAt: new Date(event.at).toISOString(),
    live: true,
  };
}
export function nativeDexSnapshot(
  payload,
  creatures,
  previous,
  tabId,
  recent = [],
) {
  const clean = cleanDexRows(payload.rows),
    threshold =
      Number.isInteger(payload.threshold) && payload.threshold > 0
        ? payload.threshold
        : 100;
  const rows = Object.fromEntries(
    creatures
      .filter((c) => c.pokeId > 0 && c.pokeId < 10000)
      .map((c) => [
        c.pokeId,
        clean[c.pokeId] || {
          id: c.pokeId,
          kills: 0,
          caught: false,
          complete: false,
          threshold,
          atLeast: false,
        },
      ]),
  );
  let progress = {
    tabId,
    rows,
    revision: (previous?.revision || 0) + 1,
    updatedAt: new Date().toISOString(),
    source: 'native',
    live: true,
    gap: false,
  };
  for (const event of recent.filter((e) => e.seq > payload.snapshotSeq))
    progress = updateDexEvent(progress, event, creatures);
  return progress;
}
