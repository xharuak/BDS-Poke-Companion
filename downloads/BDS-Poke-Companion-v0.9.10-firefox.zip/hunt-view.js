import { renderHTML } from "./render-html.js";
import {
  activeSpecies,
  runMetrics,
  measuredHunts,
  createHuntProfiler,
  projectPersonalHunt,
  spawnGeometry,
  spawnDescription,
  combatObservation,
} from "./hunt.js";
import { personalSetup, respawnObservation } from "./hunt-personal.js";
import { REGIONS } from "./battle.js";
import { setupAccessRegions, getAccessibleRegions } from "./access-view.js";
import { sprite } from "./sprites.js";
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
const fmt = (x, d = 0) =>
  Number.isFinite(x)
    ? x.toLocaleString("pt-BR", { maximumFractionDigits: d })
    : "—";
const duration = (s) => `${Math.floor(s / 60)}min ${Math.floor(s % 60)}s`;
export function setupHunt(
  catalog,
  chart,
  spawns,
  getContext,
  send,
  toast,
  refresh,
) {
  const host = $("hunt");
  const profileFor = createHuntProfiler(
    catalog.creatures,
    chart,
    spawns.records,
  );
  renderHTML(
    host,
    `<span class="eyebrow">XP POR HORA · SUA CONTA E SEU EXEMPLAR ATIVO</span><h1>Hunt Analyzer</h1><p>A medição acompanha quem está caçando agora, seus atributos, TMs aprendidas e os bônus desta conta.</p><div id="hunt-live" class="hint" role="status"></div><div id="hunt-active" class="hunt-active"></div><div id="hunt-setup" class="hint"></div><div id="hunt-metrics" class="totals"></div><div id="hunt-native" class="hint"></div><div id="hunt-geometry" class="hint"></div><div id="hunt-movement" class="hint"></div><div id="hunt-combat" class="hint"></div><fieldset id="hunt-access" class="region-access"></fieldset><div class="filters"><label>Filtrar mapa<input id="hunt-query" type="search" placeholder="Nome da hunt"></label><label>Nível máximo da hunt<input id="hunt-max" type="number" min="1" placeholder="Sem limite"></label></div><div id="hunt-recommendation" class="hint"></div><h2>Hunts que você mediu</h2><p class="hunt-note">A referência precisa de 2 minutos e 20 abates com XP identificado após a punição de entrada. Somente amostras do mesmo exemplar, atributos, TMs e bônus atuais são comparadas.</p><div id="hunt-measured"></div><h2>Projeções para sua configuração atual</h2><p class="hunt-note">Estimativas calibradas pelo combate e deslocamento observados. A faixa mostra cenários de alcance e caminho, não uma probabilidade. Mapas sem XP por abate e respawn medidos nesta conta ficam sem valor estimado. Não transferimos o multiplicador de XP de uma região para outra.</p><div id="hunt-projections"></div><details class="meta-options"><summary>Como funciona e limites dos dados</summary><p>XP/h recebido = XP entregue ao Pokémon ativo ÷ tempo observado × 3.600. O primeiro minuto tem −70% de XP: o valor recebido já vem reduzido e não recebe outro desconto. Somente abates após a punição calibram as projeções. Resetar preserva o prazo da punição. Trocar o exemplar, atributos, TMs, equipamentos, bônus ou mapa inicia outra amostra. Desconexões não acumulam tempo fictício.</p><p><b>Spawns fixos:</b> ${Object.keys(spawns.records).length} mapas consultados em ${esc(spawns.checkedAt?.slice(0, 10))}. Kanto e Outland usam pontos individuais. Orre agrupa 4 pontos adjacentes. Nightmare usa a regra de 4 membros informada pelo jogador e aproxima os grupos pelos pontos mais próximos: o catálogo público não informa o vínculo de cada monstro com seu grupo. Essa divisão e as distâncias de Nightmare são estimadas; o XP medido e os alvos atingidos vêm dos eventos reais. Em Kanto/Outland, a distância é entre pontos individuais; em Orre/Nightmare, entre centros de grupos. Paredes e a rota efetiva podem alongá-la. A leitura do campo mede passos e mortes/retornos por slot. Uma morte que ocorreu antes da leitura não gera uma amostra de respawn.</p><p><b>Golden Bicycle e Golden Lure Apricorn:</b> lemos a presença e o vencimento no inventário desta conta, além dos estados informados pelo campo. A bicicleta dá +30% de velocidade na hunt; a duração real do passo é a informada pelo jogo. O lure acelera o respawn em 30%, conforme sua descrição: usamos o intervalo observado, sem converter isso arbitrariamente em +30% de XP. Os dois efeitos já estão nos tempos medidos. Ao vencerem, a amostra antiga deixa de calibrar a configuração atual. A projeção representa a taxa enquanto os bônus indicados estiverem ativos, não uma garantia durante uma hora após seu vencimento. Pesca e arena não recebem estas projeções.</p><p><b>Ataques:</b> usamos ATK/Sp. ATK do exemplar e TMs aprendidas na equipe, não discos no inventário nem TMs disponíveis no catálogo. Sem AoE TM, golpes normais usam 1 alvo no modelo; com AoE TM, o alcance geométrico limita a área, e a média de alvos realmente observada limita o ganho previsto. A TM elemental é independente: poder 300, intervalo mínimo de 10s, caixa 6×6 e ao menos 2 alvos. Seus impactos atrasados são reunidos por 3s para evitar contar um único disparo várias vezes. Medimos média e máximo de alvos atingidos, sem incluir dano sofrido pelo herói. O modelo de outro mapa usa a cadência observada e uma faixa conservadora sem área; a elemental só contribui após ao menos 3 disparos observados. Respeitamos um mínimo de tempo por golpe útil, mesmo contra inimigos fracos.</p><p><b>Projeção:</b> requer 30s de telemetria cobrindo 70% da amostra e ao menos 5 eventos de golpes normais. Combate usa um índice relativo de HP, nível, defesa, poder, atributos reais, STAB, efetividade e ataques em paralelo. Não é uma reprodução do servidor. Deslocamento é calibrado na velocidade e rota observadas. Cada alvo exige ao menos 5 abates com XP identificado após a punição e respawn observado na mesma configuração. Sem isso, não mostramos XP/h. Usamos XP/abate realmente recebido nesse mapa, nunca uma razão entre XP do catálogo de regiões diferentes. Amostras completas de 2 minutos e 20 abates mostram a própria taxa medida. As estimativas para amostras curtas respeitam a cadência de ataques e o respawn observado. Derrotas, curas, pausas e efeitos de equipamentos entram no XP medido; sua mudança contra outro inimigo não é prevista exatamente. A simulação exige confirmar os resultados caçando.</p><p><b>Hunt Analyzer do jogo:</b> abra o painel nativo para receber a taxa oficial da sessão. Observamos apenas a resposta que o jogo já envia; não solicitamos atualizações nem zeramos sua sessão. A taxa nativa e a taxa do Pokémon podem ter períodos ou destinatários de XP diferentes. Conferimos os abates em um intervalo comum, após a punição, sem misturar o histórico anterior à leitura.</p><p>Fontes: <a href="https://poke.idleworld.online/pokepedia/tms" target="_blank" rel="noopener">TMs oficiais</a>, configurações públicas de spawn e eventos da sua sessão. A extensão apenas observa e calcula.</p></details><button id="hunt-reset">Reiniciar medições desta sessão</button>`,
  );
  setupAccessRegions("hunt-access", render);
  // Hunt access refers to targets, not team acquisition routes.
  $("hunt-access").querySelector("p").textContent =
    "Mapas que você pode acessar. Seleção compartilhada com Meta Pokemon e Gym Meta; o nível do Pokémon não libera regiões.";
  for (const id of ["hunt-max", "hunt-query"])
    $(id).addEventListener("input", render);
  $("hunt-reset").onclick = async () => {
    const button = $("hunt-reset");
    button.disabled = true;
    try {
      await send({ type: "hunt-reset" });
      await refresh();
      toast("Medições zeradas. O tempo da punição do jogo foi preservado.");
    } catch (e) {
      toast(e.message);
    } finally {
      button.disabled = false;
    }
  };
  function render() {
    const missingOpen = $("hunt-unmeasured")?.open || false;
    const context = getContext(),
      state = context.hunt || {},
      active = state.active,
      c = activeSpecies(active, catalog.creatures),
      now = Date.now(),
      setup = personalSetup(state, now);
    const linked =
      context.live?.connected &&
      context.live?.online &&
      now - context.live.lastSeen < 15000;
    const current = catalog.hunts.find((h) => h.slug === state.slug),
      regions = getAccessibleRegions(),
      max = Number($("hunt-max").value) || Infinity;
    $("hunt-live").textContent = !context.profileId
      ? "Abra esta aba pelo botão BDS dentro do jogo."
      : !linked
        ? "Aguardando conexão com os eventos do jogo. A medição precisa da aba do jogo aberta e do leitor conectado."
        : !active
          ? "Conectado. Deixe a barra do time visível e selecione seu Pokémon ativo."
          : !current
            ? "Pokémon identificado. Entre em uma hunt para começar a medição."
            : "Medindo ao vivo · o tempo entre os abates também entra no XP/h.";
    renderHTML(
      $("hunt-active"),
      active
        ? `${c ? sprite(c) : ""}<div><strong>${esc(c?.name || active.name)}</strong><small>Nv. ${fmt(active.level)} · ${esc(current?.name || "Fora de hunt")}${current ? " · " + REGIONS[current.region] : ""}</small></div>`
        : "",
    );
    const r = state.run ? runMetrics(state.run, now) : null;
    const itemText = (name, key) => {
      const g = setup.gear[key];
      const remaining =
        g.until > now
          ? ` · vence em ${Math.floor((g.until - now) / 86400000)}d ${Math.floor(((g.until - now) % 86400000) / 3600000)}h`
          : "";
      return `${name}: ${!g.known ? "inventário ainda não lido" : !g.present ? "ausente" : g.expired ? "vencido" : g.active === null ? "prazo não identificado" : g.active ? "ativo" : "sem efeito neste campo"}${remaining}${g.known && g.present && !g.expired && !g.confirmed ? " · aguardando confirmação no campo" : ""}`;
    };
    const l = setup.loadout;
    $("hunt-setup").textContent =
      (l
        ? `Exemplar desta conta · ATK ${fmt(l.current.atk)} · DEF ${fmt(l.current.def)} · Sp. ATK ${fmt(l.current.spa)} · Sp. DEF ${fmt(l.current.spd)} · VEL ${fmt(l.current.vel)}. TMs aprendidas: ${l.tms?.join(" + ") || (l.tms ? "nenhuma · golpes normais em 1 alvo" : "aguardando leitura")}. `
        : "Abra a equipe ou o inventário no jogo para ler os atributos e TMs do exemplar ativo. ") +
      itemText("Golden Bicycle", "bicycle") +
      ". " +
      itemText("Golden Lure Apricorn", "lure") +
      "." +
      (!setup.gear.bicycle.known
        ? " Abra o inventário no jogo para identificar os itens desta conta."
        : "");
    const geometry = current
      ? spawnGeometry(spawns.records[current.slug]?.spawns, current.region)
      : null;
    $("hunt-geometry").textContent = geometry
      ? `${spawnDescription(geometry, current.region)}. ${geometry.inferredGroups ? "Nightmare: composição dos grupos inferida por proximidade. " : ""}Distância geométrica; a rota real pode ser maior.`
      : "Entre em uma hunt com spawns conhecidos para analisar a distribuição.";
    const motion = respawnObservation(r),
      env = state.environment;
    $("hunt-movement").textContent =
      `Passo no campo: Pokémon ${fmt(env?.heroStepMs)} ms/tile · personagem ${fmt(env?.trainerStepMs)} ms/tile. Deslocamento observado: Pokémon ${fmt(motion.speed, 2)} tiles/s · personagem ${fmt(motion.trainerSpeed, 2)} tiles/s. Respawn por monstro: ${motion.seconds === null ? "coletando" : fmt(motion.seconds, 2) + "s"} (${motion.samples} retornos). Espera de onda: ${motion.waveSeconds === null ? "coletando" : fmt(motion.waveSeconds, 2) + "s"} (${motion.waveSamples} ondas).`;

    if (linked && r && (r.penaltyRemaining > 0 || r.penaltyFrozen))
      $("hunt-live").textContent += r.penaltyFrozen
        ? " Punição de entrada pausada pelo jogo; aguardando liberação."
        : r.penaltySource === "conservative"
          ? ` Entrada não observada: aguardando ${Math.ceil(r.penaltyRemaining)}s antes de calibrar o XP sem punição.`
          : ` Punição de entrada: −70% XP · ${Math.ceil(r.penaltyRemaining)}s restantes. Esse período não calibra as recomendações.`;
    renderHTML(
      $("hunt-metrics"),
      [
        [r?.xpHour, "XP/h recebido · inclui punição"],
        [r?.steady?.xpHour, "XP/h sem punição"],
        [r?.kills, "Abates nesta amostra"],
        [r ? duration(r.seconds) : "—", "Tempo observado"],
      ]
        .map(
          ([v, l]) =>
            `<div class="total"><b>${typeof v === "string" ? v : fmt(v)}</b><small>${l}</small></div>`,
        )
        .join(""),
    );
    const native = r?.native,
      lastNative = native?.last;
    const freshNative = linked && lastNative && now - lastNative.at < 15000;
    $("hunt-native").textContent = freshNative
      ? `Hunt Analyzer do jogo · ${fmt(lastNative.xpPerHour)} XP/h · ${fmt(lastNative.killsPerHour)} abates/h · ${fmt(lastNative.xpGained)} XP em ${duration(lastNative.seconds)}. ` +
        (native.check
          ? `Conferência no mesmo intervalo (${duration(native.check.seconds)}): jogo ${native.check.kills} abates, extensão ${native.check.localKills}. ${native.check.consistent ? "Contagem compatível." : "Divergência detectada: projeções suspensas. Reinicie as medições da extensão para conferir uma nova amostra."}`
          : "Coletando ao menos 30s e 5 abates em comum para conferir a leitura.") +
        " A sessão nativa pode incluir tempo anterior e XP diferente do Pokémon ativo."
      : "Abra o Hunt Analyzer do próprio jogo e deixe-o aberto para acompanhar a taxa oficial e conferir os abates. A extensão apenas observa as atualizações desse painel.";
    const observation = combatObservation(r);
    const moveRows = Object.values(r?.steady?.combat?.moves || {});
    $("hunt-combat").textContent = observation.total
      ? "Combate observado após a punição: " +
        duration(observation.total / 1000) +
        " · lutando " +
        fmt(observation.combat * 100) +
        "% · deslocando " +
        fmt(observation.travel * 100) +
        "% · esperando " +
        fmt(observation.wait * 100) +
        "%." +
        (observation.covered
          ? ""
          : " Coletando cobertura para calibrar os tempos.") +
        (moveRows.length
          ? " Alvos por evento de golpe: " +
            moveRows
              .map(
                (m) =>
                  m.name +
                  (l?.tms?.some((t) =>
                    c?.attacks?.some((a) => a.tm === t && a.name === m.name),
                  )
                    ? " [TM elemental] "
                    : " [normal] ") +
                  fmt(m.targets / m.batches, 1) +
                  " (máx. " +
                  m.maxTargets +
                  "; " +
                  m.batches +
                  " eventos" +
                  (m.batches < 5 ? ", coletando" : "") +
                  ")",
              )
              .join(" · ") +
            "."
          : "")
      : "Aguardando eventos do campo após a punição para medir ataques, deslocamento e espera.";
    const all = measuredHunts(state, regions, catalog.hunts, now).filter(
      (r) => r.hunt.level <= max,
    );
    const bySlug = new Map();
    for (const m of [...all].sort((a, b) => b.start - a.start)) {
      if (
        !bySlug.has(m.slug) &&
        m.comparable &&
        m.steady?.complete &&
        m.steady.kills >= 5
      )
        bySlug.set(m.slug, m);
    }
    const valid = [...bySlug.values()]
        .filter((m) => m.reliable)
        .sort((a, b) => b.steady.xpHour - a.steady.xpHour),
      best = valid[0];
    $("hunt-recommendation").textContent = best
      ? `Melhor XP/h medido sem punição de entrada: ${best.hunt.name} · ${fmt(best.steady.xpHour)} XP/h do Pokémon. Mudar de hunt aplica novamente 1 minuto de −70% XP.`
      : "Ainda não há uma amostra suficiente para recomendar por XP/h. Cace por pelo menos 2 minutos e 20 abates após a punição de entrada.";
    renderHTML(
      $("hunt-measured"),
      all.length
        ? all
            .slice(0, 12)
            .map(
              (m) =>
                `<article class="hunt-sample"><div><strong>${esc(m.hunt.name)}</strong><small>${REGIONS[m.hunt.region]} · Nv. ${m.hunt.level} · Pokémon Nv. ${m.levelMin}–${m.levelMax}</small><small>${duration(m.seconds)} · ${m.kills} abates · ${fmt(m.secondsKill, 1)}s/abate · ${fmt(m.xpKill, 1)} XP/abate</small><small>Sem punição: ${duration(m.steady?.seconds || 0)} · ${m.steady?.kills || 0} abates · ${fmt(m.steady?.xpHour)} XP/h</small><small>${!m.steady?.complete ? "Aguardando abates sem punição com XP do Pokémon identificado" : !m.comparable ? "Configuração ou nível diferente do atual · fora da recomendação" : m.reliable ? "Amostra de referência" : "Amostra sem punição pequena · medição em andamento"}</small></div><div class="hunt-rate"><b>${fmt(m.xpHour)}</b><small>XP/h recebido · inclui punição</small><small>Treinador: ${fmt(m.trainerHour)} XP/h</small></div></article>`,
            )
            .join("")
        : '<div class="empty">As hunts visitadas com o Pokémon ativo aparecerão aqui.</div>',
    );
    const reference = [...valid].sort(
      (a, b) => (b.end || now) - (a.end || now),
    )[0];
    const ref =
      reference && c && setup.ready
        ? profileFor(reference.hunt, c, active.level, setup.loadout)
        : null;
    const profiles =
      c && setup.ready
        ? catalog.hunts
            .filter(
              (h) =>
                regions.includes(h.region) &&
                h.level <= max &&
                h.name
                  .toLocaleLowerCase()
                  .includes($("hunt-query").value.trim().toLocaleLowerCase()) &&
                spawns.records[h.slug],
            )
            .map((h) => profileFor(h, c, active.level, setup.loadout))
            .filter(Boolean)
        : [];
    const projected = profiles
      .map((p) => ({
        ...p,
        estimate: reference
          ? projectPersonalHunt(ref, p, reference, bySlug.get(p.hunt.slug))
          : null,
      }))
      .filter((p) => p.estimate)
      .sort((a, b) => b.estimate.xpHour - a.estimate.xpHour);
    renderHTML(
      $("hunt-projections"),
      projected.length
        ? `<p class="hint">Referência: ${esc(reference.hunt.name)} · ${fmt(reference.steady.xpHour)} XP/h medido sem punição. Ordenado por XP/h. Valores medidos têm prioridade sobre o modelo; mapas sem dados ficam sem estimativa. Tempos calibrados na conta atual; bônus já incluídos. A taxa vale enquanto os itens indicados estiverem ativos.</p>` +
            projected
              .slice(0, 12)
              .map(
                (p, i) =>
                  `<article class="hunt-sample"><div><strong>${i + 1}. ${esc(p.hunt.name)}</strong><small>${REGIONS[p.hunt.region]} · Nv. ${p.hunt.level} · ${spawnDescription(p, p.hunt.region)}</small><small>${esc([...p.moves, ...(p.personal?.tmName ? [p.personal.tmName + " (TM)"] : [])].join(" / "))}</small><small>${p.estimate.measured ? "Taxa medida neste mapa" : "Estimativa para amostra curta · XP/abate e respawn medidos aqui"}${p.estimate.tmObserved ? "" : " · TM elemental sem amostra suficiente; sem ganho presumido"}</small><small>${fmt(p.estimate.xpKill, 1)} XP/abate · ${fmt(p.estimate.secondsKill, 2)}s/abate${p.estimate.measured ? "" : " · Faixa: " + fmt(p.estimate.low) + "–" + fmt(p.estimate.high) + " XP/h"}</small></div><div class="hunt-rate"><b>${p.estimate.measured ? "" : "~"}${fmt(p.estimate.xpHour)}</b><small>XP/h ${p.estimate.measured ? "medido" : "estimado"} após a punição</small><button data-species="${p.hunt.speciesIds[0]}" data-tab="battle">Ver alvo</button></div></article>`,
              )
              .join("")
        : `<div class="empty">${!c ? "Aguardando a identificação do Pokémon ativo." : !setup.ready ? "Abra o inventário/equipe no jogo para identificar atributos, TMs e bônus desta conta." : !reference ? "Colete uma amostra de referência para calibrar o XP/h das outras hunts." : "Os mapas deste filtro ainda não reúnem uma medição consistente de XP/abate, respawn e combate nesta configuração. Veja os mapas aguardando medição abaixo."}</div>`,
    );
    const missing = profiles.filter(
      (p) => !projected.some((q) => q.hunt.slug === p.hunt.slug),
    );
    if (missing.length)
      renderHTML(
        $("hunt-projections"),
        `<details id="hunt-unmeasured" class="meta-options" ${missingOpen ? "open" : ""}><summary>${missing.length} mapas sem estimativa confiável</summary><p>Visite o mapa com este exemplar e configuração para medir XP/abate e respawn após a punição. Sem esses dados, uma taxa numérica seria especulação. Nada é multiplicado por quatro em Kanto/Outland. Mostrando até 20 mapas; use o filtro de mapa para localizar outro.</p>${missing
          .slice(0, 20)
          .map(
            (p) =>
              `<article class="hunt-sample"><div><strong>${esc(p.hunt.name)}</strong><small>${REGIONS[p.hunt.region]} · ${spawnDescription(p, p.hunt.region)}</small><small>XP/h: aguardando medição suficiente e consistente neste mapa</small></div></article>`,
          )
          .join("")}</details>`,
        true,
      );
    if (current && !reference) {
      const g = spawnGeometry(
        spawns.records[current.slug]?.spawns,
        current.region,
      );
      if (g)
        renderHTML(
          $("hunt-projections"),
          `<p class="hint">${esc(current.name)}: ${spawnDescription(g, current.region)}.</p>`,
          true,
        );
    }
  }
  // The visible companion owns the refresh clock; no hidden per-view timer.
  return render;
}
