// Isolated content script: rendered game data and our floating research window.
(() => {
  const version = '0.9.10';
  if (globalThis.__bdsReader?.version === version) return;
  if (globalThis.__bdsReader === true)
    throw Error('Atualização do leitor: recarregue esta aba do jogo uma vez.');
  globalThis.__bdsReader?.stop?.();
  const api = globalThis.browser ?? chrome;
  const eligible =
    '.chat-link:not(.chat-link-item),.inv-slot.inv-poke,.phud-mon,.mkt2-card,.mkt2-trow';
  let active = false,
    observer,
    timer,
    dexTimer,
    last = '',
    lastDex = '',
    candidateDex = '',
    candidateAt = 0,
    host,
    root,
    pane,
    frame,
    drag,
    styled = false;
  const prefs = {
    compact: false,
    highlight: true,
    minIV: 160,
    clickMode: 'ctrl',
  };
  let liveChannel = null;
  let inventoryCounts = {};
  let lastLiveReply = 0;
  let barScale = 1,
    barKey = '',
    resizing = null,
    barEdited = false;
  const validBarScale = (value) =>
    typeof value === 'number' && Number.isFinite(value)
      ? Math.max(0.55, Math.min(2, value))
      : 1;
  function sizeBar() {
    if (!styled || !pane || pane.hidden || !pane.classList.contains('compact'))
      return;
    pane.style.setProperty('--bar-scale', barScale);
    const width = root.querySelector('.dragbar').getBoundingClientRect().width;
    // Keep a saved size usable when Zen makes this account's split view narrower.
    const available = Math.max(1, innerWidth - 14);
    const scale = width > available ? (barScale * available) / width : barScale;
    pane.style.setProperty('--bar-scale', scale);
    root
      .querySelector('.bar-resize')
      .setAttribute('aria-valuenow', Math.round(scale * 100));
    clamp();
  }
  function saveBarSize() {
    if (barKey) api.storage.local.set({ [barKey]: barScale }).catch(() => {});
  }
  function resetBarSize() {
    barEdited = true;
    barScale = 1;
    sizeBar();
    saveBarSize();
  }
  function viewportChanged() {
    sizeBar();
    clamp();
  }
  function updateBar() {
    let sizeChanged = false;
    for (const [key, label] of [
      ['ultra', 'Ultra'],
      ['potion', 'Potion'],
      ['pokemon', 'Poké'],
    ]) {
      const node = root?.querySelector('[data-inventory="' + key + '"]');
      if (node) {
        const text =
          label +
          ': ' +
          (Number.isSafeInteger(inventoryCounts[key])
            ? inventoryCounts[key].toLocaleString('pt-BR')
            : '—') +
          (key === 'pokemon' ? '/3.000' : '');
        if (node.textContent !== text) {
          sizeChanged ||= node.textContent.length !== text.length;
          node.textContent = text;
        }
        if (key === 'pokemon') {
          const count = inventoryCounts.pokemon;
          const known = Number.isSafeInteger(count);
          node.dataset.capacity = !known
            ? 'unknown'
            : count >= 3000
              ? 'full'
              : count >= 2700
                ? 'near'
                : 'normal';
          node.title = !known
            ? 'Abra o inventário do jogo uma vez para contar os Pokémon desta conta. Banco da família excluído.'
            : 'Pokémon desta conta, incluindo iniciais e anunciados no mercado, sem o banco da família. ' +
              (count >= 3000
                ? 'Limite de 3.000 atingido: libere vagas para continuar capturando.'
                : `Restam ${(3000 - count).toLocaleString('pt-BR')} vagas até o limite de 3.000.`);
          if (
            known &&
            ['pokemonTeam', 'pokemonListed', 'pokemonStarter'].every((key) =>
              Number.isSafeInteger(inventoryCounts[key]),
            )
          ) {
            const num = (value) => value.toLocaleString('pt-BR');
            node.title += `\nEquipe: ${num(inventoryCounts.pokemonTeam)} · Fora da equipe: ${num(count - inventoryCounts.pokemonTeam)}.`;
            node.title += `\nJá incluídos no total — Anunciados no mercado: ${num(inventoryCounts.pokemonListed)} · Pokémon iniciais: ${num(inventoryCounts.pokemonStarter)}. Também ocupam capacidade.`;
          }
        }
      }
    }
    const sound = root?.querySelector('.sound-unlock');
    if (sound) {
      const hidden = globalThis.__bdsAudio?.state() !== 'blocked';
      sizeChanged ||= sound.hidden !== hidden;
      sound.hidden = hidden;
    }
    if (
      sizeChanged &&
      styled &&
      !pane.hidden &&
      pane.classList.contains('compact')
    )
      sizeBar();
  }
  function liveMessage(e) {
    if (
      !active ||
      e.source !== window ||
      e.origin !== location.origin ||
      !liveChannel ||
      e.data?.bdsLive !== liveChannel
    )
      return;
    const d = e.data;
    if (
      !Number.isSafeInteger(d.seq) ||
      ![
        'link',
        'context',
        'kill',
        'capture',
        'dex-snapshot',
        'heartbeat',
        'hunt-penalty',
        'hunt-combat',
        'hunt-party',
        'hunt-gear',
        'hunt-environment',
      'hunt-native',
        'gym-snapshot',
        'team-snapshot',
        'inventory',
        'capture-iv',
        'capture-ready',
      ].includes(d.kind)
    )
      return;
    const channel = liveChannel;
    send({
      type: 'live-event',
      channel: liveChannel,
      seq: d.seq,
      at: d.at,
      kind: d.kind,
      payload: d.payload,
      audioState: globalThis.__bdsAudio?.state() || 'off',
    })
      .then((result) => {
        if (!active || liveChannel !== channel || !result) return;
        if (d.seq >= lastLiveReply) {
          lastLiveReply = d.seq;
          inventoryCounts = result.inventory || {};
        }
        for (const alert of result.alerts || []) {
          const played = globalThis.__bdsAudio?.play(alert.kind);
          status(
            alert.text +
              (played ? '' : ' · ative os sons pelo botão ♪ na barra'),
          );
        }
        updateBar();
      })
      .catch(() => {});
  }
  const send = async (m) => {
    const r = await api.runtime.sendMessage(m);
    if (!r?.ok) throw Error(r?.error || 'Extensão indisponível.');
    return r.data;
  };
  function tips() {
    return [...document.querySelectorAll('.inv-tip')]
      .filter((t) => {
        const s = getComputedStyle(t),
          r = t.getBoundingClientRect();
        return (
          s.display !== 'none' &&
          s.visibility !== 'hidden' &&
          +s.opacity !== 0 &&
          r.width &&
          r.height &&
          r.bottom > 0 &&
          r.top < innerHeight
        );
      })
      .map((t) => t.innerText?.slice(0, 6000))
      .filter(
        (t) =>
          t && /Qualidade|Quality/i.test(t) && /Nv|Nível|Level|Lv/i.test(t),
      );
  }
  function scan() {
    timer = null;
    if (!active || document.visibilityState !== 'visible') return;
    const a = tips();
    if (a.length !== 1 || a[0] === last) return;
    last = a[0];
    api.runtime.sendMessage({ type: 'tooltip', text: last }).catch(stop);
  }
  function scanDex() {
    dexTimer = null;
    if (!active || document.visibilityState !== 'visible') return;
    const value = globalThis.__bdsReadDex?.(document);
    if (!value?.ready) return;
    const sig = JSON.stringify(value.rows);
    if (sig === lastDex) return;
    if (candidateDex !== sig) {
      candidateDex = sig;
      candidateAt = Date.now();
    }
    if (Date.now() - candidateAt < 900) {
      dexTimer = setTimeout(scanDex, 1000);
      return;
    }
    send({ type: 'dex-visible', rows: value.rows })
      .then(() => {
        lastDex = sig;
      })
      .catch((e) => status(e.message));
  }
  function schedule() {
    if (!timer) timer = setTimeout(scan, 220);
    if (!dexTimer) dexTimer = setTimeout(scanDex, 1100);
  }
  function mutations(records) {
    // Animating HP bars, sprites and combat text are not tooltip/Dex changes.
    const selector = '.inv-tip,.dex-window';
    for (const r of records) {
      const target =
        r.target.nodeType === 1 ? r.target : r.target.parentElement;
      if (target?.closest(selector)) {
        schedule();
        return;
      }
      if (r.type === 'childList')
        for (const node of r.addedNodes) {
          if (
            node.nodeType === 1 &&
            (node.matches(selector) || node.querySelector(selector))
          ) {
            schedule();
            return;
          }
        }
    }
  }
  function panelVisibility() {
    frame?.contentWindow?.postMessage(
      {
        bdsPanelVisible: !!(
          active &&
          pane &&
          !pane.hidden &&
          !pane.classList.contains('compact') &&
          document.visibilityState === 'visible'
        ),
      },
      '*',
    );
  }
  function status(s) {
    const el = root?.querySelector('.status');
    if (el) el.textContent = s;
  }
  function clamp() {
    if (!pane || !styled) return;
    const r = pane.getBoundingClientRect();
    pane.style.left =
      Math.max(6, Math.min(r.left, innerWidth - r.width - 6)) + 'px';
    pane.style.top =
      Math.max(
        6,
        Math.min(r.top, innerHeight - Math.min(r.height, innerHeight) - 6),
      ) + 'px';
  }
  function compact(v) {
    pane.classList.toggle('compact', v);
    root.querySelector('.minimize').textContent = v ? '＋' : '−';
    root.querySelector('.minimize').title = v
      ? 'Abrir pesquisas'
      : 'Recolher pesquisas';
    if (v) sizeBar();
    clamp();
    panelVisibility();
  }
  function show() {
    pane.hidden = false;
    root.querySelector('.launcher').hidden = true;
    sizeBar();
    clamp();
    panelVisibility();
  }
  function preferences() {
    if (!root) return;
    pane.classList.toggle('dense', !!prefs.compact);
  }
  function element(tag, cls, text) {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (text) el.textContent = text;
    return el;
  }
  function library(query = '') {
    frame.src = api.runtime.getURL(
      'companion.html' + (query ? '?' + query : ''),
    );
  }
  function build() {
    host = element('div');
    host.id = 'bds-companion-overlay';
    root = host.attachShadow({ mode: 'closed' });
    const css = element('link');
    css.rel = 'stylesheet';
    css.href = api.runtime.getURL('overlay.css') + '?v=' + version;
    css.addEventListener('load', () => {
      styled = true;
      sizeBar();
      clamp();
    });
    root.append(css);
    const launcher = element('button', 'launcher', 'BDS · Poké');
    launcher.hidden = true;
    launcher.addEventListener('click', () => {
      show();
      compact(false);
    });
    root.append(launcher);
    pane = element('section', 'window');
    pane.setAttribute('aria-label', 'BDS Poké · pesquisas no jogo');
    const head = element('header', 'dragbar'),
      home = element('button', 'home', '⌕'),
      min = element('button', 'minimize', '＋'),
      close = element('button', '', '×');
    const counters = element('span', 'inventory-counts');
    for (const [key, title] of [
      ['ultra', 'Ultra Ball'],
      ['potion', 'Ultimate Potion'],
      ['pokemon', 'Pokémon desta conta (sem o banco da família)'],
    ]) {
      const value = element('span');
      value.dataset.inventory = key;
      value.title =
        title +
        ' no inventário · abra o inventário uma vez para iniciar a leitura';
      counters.append(value);
    }
    const sound = element('button', 'sound-unlock', '♪');
    sound.title = 'Ativar sons nesta aba';
    sound.setAttribute('aria-label', sound.title);
    sound.onclick = () => {
      globalThis.__bdsAudio?.resume();
      setTimeout(() => {
        globalThis.__bdsAudio?.play('capture');
        updateBar();
      }, 180);
    };
    home.title = 'Voltar às pesquisas';
    home.addEventListener('click', () => {
      library();
      show();
      compact(false);
    });
    min.title = 'Abrir pesquisas';
    min.addEventListener('click', () =>
      compact(!pane.classList.contains('compact')),
    );
    close.title = 'Recolher para o botão BDS';
    close.addEventListener('click', () => {
      pane.hidden = true;
      launcher.hidden = false;
      panelVisibility();
    });
    head.append(
      element('strong', '', 'BDS · Poké'),
      element('span', 'gesture', 'Pesquisar'),
      counters,
      sound,
      home,
      min,
      close,
    );
    pane.append(head);
    frame = element('iframe');
    frame.addEventListener('load', panelVisibility);
    frame.title = 'Pokédex, Pokelog e pesquisas';
    pane.append(frame);
    const msg = element(
      'div',
      'status',
      'Pesquise acima · Ctrl + clique analisa um Pokémon · arraste pela barra',
    );
    msg.setAttribute('role', 'status');
    pane.append(msg);
    const resize = element('div', 'bar-resize');
    resize.tabIndex = 0;
    resize.setAttribute('role', 'slider');
    resize.setAttribute('aria-label', 'Tamanho da barra');
    resize.setAttribute('aria-valuemin', '55');
    resize.setAttribute('aria-valuemax', '200');
    resize.title =
      'Arraste para aumentar ou diminuir a barra. Duplo clique restaura. Setas também ajustam.';
    resize.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      const r = pane.getBoundingClientRect();
      resizing = {
        id: e.pointerId,
        x: e.clientX,
        y: e.clientY,
        width: r.width,
        height: r.height,
        scale: Number(pane.style.getPropertyValue('--bar-scale')) || barScale,
      };
      barEdited = true;
      resize.setPointerCapture(e.pointerId);
      resize.focus({ preventScroll: true });
    });
    resize.addEventListener('pointermove', (e) => {
      if (!resizing || resizing.id !== e.pointerId) return;
      const dx = e.clientX - resizing.x,
        dy = e.clientY - resizing.y;
      const change =
        Math.abs(dx) >= Math.abs(dy)
          ? dx / resizing.width
          : dy / resizing.height;
      barScale = validBarScale(resizing.scale * (1 + change));
      sizeBar();
    });
    const finishResize = (e) => {
      if (!resizing || resizing.id !== e.pointerId) return;
      resizing = null;
      if (resize.hasPointerCapture(e.pointerId))
        resize.releasePointerCapture(e.pointerId);
      saveBarSize();
    };
    resize.addEventListener('pointerup', finishResize);
    resize.addEventListener('pointercancel', finishResize);
    resize.addEventListener('lostpointercapture', finishResize);
    resize.addEventListener('dblclick', resetBarSize);
    resize.addEventListener('keydown', (e) => {
      const direction = {
        ArrowLeft: -1,
        ArrowDown: -1,
        ArrowRight: 1,
        ArrowUp: 1,
      }[e.key];
      if (e.key === 'Home') {
        e.preventDefault();
        resetBarSize();
      } else if (direction) {
        e.preventDefault();
        barEdited = true;
        barScale = validBarScale(
          barScale + direction * (e.shiftKey ? 0.1 : 0.05),
        );
        sizeBar();
        saveBarSize();
      }
    });
    pane.append(resize);
    root.append(pane);
    updateBar();
    document.documentElement.append(host);
    pane.style.left = Math.max(6, innerWidth - 790) + 'px';
    pane.style.top = '85px';
    compact(true);
    library();
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      const r = pane.getBoundingClientRect();
      drag = { x: e.clientX - r.left, y: e.clientY - r.top };
      head.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    head.addEventListener('pointermove', (e) => {
      if (drag) {
        pane.style.left = e.clientX - drag.x + 'px';
        pane.style.top = e.clientY - drag.y + 'px';
        clamp();
      }
    });
    head.addEventListener('pointerup', () => {
      drag = null;
      api.storage.local
        .set({
          overlayPosition: { left: pane.style.left, top: pane.style.top },
        })
        .catch(() => {});
    });
    const builtPane = pane,
      savedBarKey = barKey;
    api.storage.local
      .get(['preferences', 'overlayPosition', savedBarKey])
      .then((d) => {
        if (pane !== builtPane || savedBarKey !== barKey) return;
        Object.assign(prefs, d.preferences || {});
        if (!barEdited) barScale = validBarScale(d[savedBarKey]);
        if (d.overlayPosition) {
          pane.style.left = d.overlayPosition.left;
          pane.style.top = d.overlayPosition.top;
        }
        preferences();
        sizeBar();
        clamp();
      })
      .catch(() => {});
  }
  async function inspect(e) {
    if (!active || e.button !== 0 || e.altKey || e.metaKey || e.shiftKey)
      return;
    const native =
      e.target instanceof Element
        ? e.target.closest('.dex-window .dex-cell')
        : null;
    if (native && e.ctrlKey) {
      const id = Number(
        native.querySelector('.dex-cell-no')?.textContent.replace(/\D/g, ''),
      );
      if (id) {
        e.preventDefault();
        e.stopImmediatePropagation();
        show();
        compact(false);
        library('species=' + id);
      }
      return;
    }
    const target =
      e.target instanceof Element ? e.target.closest(eligible) : null;
    if (!target) return;
    if (
      !e.ctrlKey &&
      !(
        prefs.clickMode === 'click' &&
        target.matches('.chat-link:not(.chat-link-item)')
      )
    )
      return;
    const a = tips();
    if (a.length !== 1) return;
    const clean = (s) => s.toLowerCase().replace(/[\[\]✨★☆\s]/gu, '');
    if (
      target.matches('.chat-link') &&
      !clean(target.textContent).includes(clean(a[0].split('\n')[0]))
    )
      return;
    e.preventDefault();
    e.stopImmediatePropagation();
    try {
      const { key } = await send({ type: 'analyze-visible', text: a[0] });
      if (!active) return;
      show();
      compact(false);
      library('selection=' + encodeURIComponent(key));
      const iv = Number(a[0].match(/\bIV\s*:?\s*(\d+)\s*\/\s*192/i)?.[1]);
      status(
        prefs.highlight && iv >= prefs.minIV
          ? `★ IV ${iv}/192 · atingiu seu filtro de ${prefs.minIV}`
          : 'Exemplar fixado · use Voltar à pesquisa para explorar o catálogo',
      );
    } catch (e) {
      status(e.message);
    }
  }
  function changes(c, area) {
    if (area === 'local' && c.preferences) {
      Object.assign(prefs, c.preferences.newValue || {});
      preferences();
    }
    if (area === 'local' && c.overlayReset && pane) {
      resetBarSize();
      pane.style.left = Math.max(6, innerWidth - 790) + 'px';
      pane.style.top = '85px';
      clamp();
    }
  }
  function stop() {
    if (liveChannel)
      window.postMessage(
        { bdsLiveControl: liveChannel, command: 'stop' },
        location.origin,
      );
    window.removeEventListener('message', liveMessage);
    liveChannel = null;
    active = false;
    observer?.disconnect();
    clearTimeout(timer);
    clearTimeout(dexTimer);
    timer = dexTimer = null;
    document.removeEventListener('pointerover', schedule);
    document.removeEventListener('visibilitychange', schedule);
    document.removeEventListener('visibilitychange', panelVisibility);
    document.removeEventListener('click', inspect, true);
    window.removeEventListener('resize', viewportChanged);
    api.storage.onChanged.removeListener(changes);
    globalThis.__bdsAudio?.configure({});
    host?.remove();
    host = root = pane = frame = null;
    resizing = drag = null;
    barScale = 1;
    barEdited = false;
    styled = false;
  }
  function start(channel, notifications = {}, profileId = 'default') {
    const key = 'overlayBarScale:' + profileId;
    if (active && key !== barKey) stop();
    barKey = key;
    globalThis.__bdsAudio?.configure(notifications);
    if (liveChannel !== channel) {
      inventoryCounts = {};
      lastLiveReply = 0;
    }
    if (active) {
      liveChannel = channel;
      return;
    }
    active = true;
    liveChannel = channel;
    window.addEventListener('message', liveMessage);
    last = lastDex = candidateDex = '';
    build();
    observer = new MutationObserver(mutations);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'title'],
    });
    document.addEventListener('pointerover', schedule);
    document.addEventListener('visibilitychange', schedule);
    document.addEventListener('visibilitychange', panelVisibility);
    document.addEventListener('click', inspect, true);
    window.addEventListener('resize', viewportChanged);
    api.storage.onChanged.addListener(changes);
    schedule();
  }
  const onMessage = (m, s, reply) => {
    if (s.id !== api.runtime.id) return;
    if (m.type === 'reader-start') {
      start(m.liveChannel, m.notifications, m.profileId);
      reply({ active, version });
    }
    if (m.type === 'reader-stop') {
      stop();
      reply({ active, version });
    }
    if (m.type === 'reader-status') reply({ active, version });
    if (m.type === 'notification-configure' && active) {
      globalThis.__bdsAudio?.configure(m.settings);
      updateBar();
      reply({ audioState: globalThis.__bdsAudio?.state() });
    }
    if (m.type === 'notification-test' && active) {
      globalThis.__bdsAudio.test(m.kind, m.settings).then((result) => {
        updateBar();
        reply(result);
      });
      return true;
    }
    if (m.type === 'overlay-open') {
      if (active) {
        show();
        compact(false);
        if (m.view) library('view=' + encodeURIComponent(m.view));
      }
      reply({ active, version });
    }
    if (m.type === 'read-progress')
      reply(globalThis.__bdsReadDex?.(document) || null);
    if (m.type === 'reset-progress') {
      lastDex = candidateDex = '';
      reply({ ok: true });
    }
  };
  api.runtime.onMessage.addListener(onMessage);
  globalThis.__bdsReader = {
    version,
    stop() {
      stop();
      globalThis.__bdsAudio?.stop();
      api.runtime.onMessage.removeListener(onMessage);
    },
  };
})();
