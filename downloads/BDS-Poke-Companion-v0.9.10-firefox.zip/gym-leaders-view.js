import { renderHTML } from './render-html.js';
import { GYMS, inferLeader } from './gym-leaders.js';
import { LABELS, normalize, findSpecies } from './core.js';
import { sprite } from './sprites.js';
import { setupGymSimulation } from './gym-simulation-view.js';
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c],
    );
const fmt = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const date = (n) =>
  n ? new Date(n).toLocaleString('pt-BR') : 'Data não informada';
const range = (a, b) => (a === b ? fmt(a) : `${fmt(a)}–${fmt(b)}`);
export function setupGymLeaders(catalog, getContext, chart) {
  const cache = new Map();
  let signature = '',
    initialized = false;
  renderHTML(
    $('leaders'),
    `<h1>Gym Leader</h1><p class="meta-intro">Abra <b>Ginásios</b> no jogo para registrar os 18 postos. Reabra para atualizar os líderes e suas equipes.</p><div id="leaders-sync" class="hint" role="status"></div><div class="filters"><label>Região<select id="leaders-region"><option value="">Todas · 18 ginásios</option><option value="kanto">Kanto · 8</option><option value="johto">Johto · 10</option></select></label><label>Tipo<select id="leaders-type"><option value="">Todos</option>${GYMS.map((g) => `<option value="${g.type}">${g.type}</option>`).join('')}</select></label><label class="leader-search">Buscar líder, ginásio ou Pokémon<input id="leaders-search" type="search" placeholder="Ex.: Rock, Glaceon"></label></div><div id="leaders-list"></div><details class="meta-options"><summary>Sobre os registros e as estimativas</summary><p>Os registros persistem neste navegador e são compartilhados entre suas contas. O horário informa a última leitura; mudanças feitas no servidor depois dela só aparecem quando o jogo carregar os ginásios novamente. Se o posto ficar vago, preservamos o último jogador registrado.</p><p>A partir do nível 15, cruzamos os cinco atributos, o nível e a base da espécie com a fórmula usada no analisador. Todos os atributos precisam admitir uma mesma qualidade. Faixas significam que mais de uma combinação é possível; não são IVs oficiais.</p><p>O HP total exibido no ginásio é de combate. Sem o atributo HP original e os modificadores, seu IV fica indeterminado. Helds e outros bônus também podem impedir a dedução dos demais IVs; nesse caso, preservamos os atributos e explicamos por que não há estimativa.</p><p><a href="https://poke.idleworld.online/pokepedia/systems/power" target="_blank" rel="noopener">Fórmula de atributos</a> · <a href="https://poke.idleworld.online/pokepedia/helds" target="_blank" rel="noopener">Helds em ginásios</a></p></details>`,
  );
  const simulator = document.createElement('section');
  $('leaders-sync').before(simulator);
  const renderSimulation = setupGymSimulation(
    simulator,
    catalog,
    chart,
    getContext,
  );
  function estimate(p, c) {
    const key = JSON.stringify(p);
    if (!cache.has(key)) {
      if (cache.size > 300) cache.clear();
      cache.set(key, inferLeader(p, c));
    }
    const r = cache.get(key);
    if (!r.valid) return `<p class="leader-estimate-note">${esc(r.reason)}</p>`;
    return `<div class="leader-estimate"><b>Qualidade estimada: ${fmt(r.qualityRange[0], 8)}–${fmt(r.qualityRange[1], 8)}</b><small>Modelo sem bônus · IV total possível: ${range(r.total.min, r.total.max)} /192 · HP indeterminado</small>${['hp', 'atk', 'def', 'spa', 'spd', 'vel'].map((k) => `<div class="leader-iv"><span>${LABELS[k]}</span><meter min="1" max="32" value="${r.ivs[k].min}" aria-label="${LABELS[k]} ${r.ivs[k].unknown ? 'indeterminado' : range(r.ivs[k].min, r.ivs[k].max)}"></meter><strong title="${r.ivs[k].values.join(', ')}">${r.ivs[k].unknown ? '?' : range(r.ivs[k].min, r.ivs[k].max)} /32</strong></div>`).join('')}${r.qualityIntervals.length > 1 ? '<small>Há intervalos separados de qualidade possíveis. A faixa acima mostra os limites.</small>' : ''}</div>`;
  }
  function pokemon(p, i) {
    const c =
      catalog.creatures.find((c) => c.pokeId === p.speciesId) ||
      findSpecies(catalog.creatures, p.name);
    return `<article class="leader-mon" data-leader-slot="${i}"><div class="leader-mon-head">${sprite(c || { pokeId: p.speciesId, name: p.name }, { shiny: p.shiny })}<div><h3>${esc(p.name)}${p.shiny ? ' ✨' : ''}</h3><small>Nv. ${fmt(p.level)} · HP de combate ${fmt(p.maxHp)}</small></div>${c ? `<button data-species="${c.pokeId}" data-level="${p.level}" data-tab="battle">Espécie</button>` : ''}</div><div class="leader-stats">${[
      ['atk', 'ATK'],
      ['def', 'DEF'],
      ['spa', 'SP.ATK'],
      ['spd', 'SP.DEF'],
      ['vel', 'VEL'],
    ]
      .map(
        ([k, label]) =>
          `<span><small>${label}</small><b>${fmt(p.current[k])}</b></span>`,
      )
      .join(
        '',
      )}</div><details class="leader-ivs"><summary>Qualidade e IVs · ${p.level < 15 ? 'mínimo Nv. 15' : 'estimativa'}</summary>${estimate(p, c)}</details>${p.moves.length ? `<details class="leader-moves"><summary>Golpes registrados · ${p.moves.length}</summary>${p.moves.map((m) => `<p><b>${esc(m.name)}</b><small>${esc(m.type)} · ${m.category === 'SPECIAL' ? 'Especial' : m.category === 'STATUS' ? 'Status' : 'Físico'} · Poder ${fmt(m.power)}</small></p>`).join('')}</details>` : ''}</article>`;
  }
  function render() {
    renderSimulation();
    const data = getContext().gymLeaders || { records: {} },
      records = data.records || {},
      region = $('leaders-region').value,
      type = $('leaders-type').value,
      q = normalize($('leaders-search').value);
    const sig = JSON.stringify([data, region, type, q]);
    if (sig === signature) return;
    signature = sig;
    const open = new Set(
      [...document.querySelectorAll('#leaders-list>.leader-gym[open]')].map(
        (e) => e.dataset.gym,
      ),
    );
    const count = Object.values(records).filter((r) => r.lastPlayer).length;
    $('leaders-sync').textContent =
      `${count}/18 com jogador registrado · ${Object.keys(records).length}/18 lidos.${data.updatedAt ? ' Última leitura: ' + date(data.updatedAt) + '. Registros salvos neste navegador.' : ' Aguardando a abertura de Ginásios no jogo.'}`;
    const list = GYMS.filter(
      (g) =>
        (!region || g.region === region) &&
        (!type || g.type === type) &&
        (!q ||
          normalize(
            [
              g.city,
              g.type,
              records[g.id]?.lastPlayer?.name,
              ...(records[g.id]?.lastPlayer?.team || []).map((p) => p.name),
            ].join(' '),
          ).includes(q)),
    );
    const first = list.find((g) => records[g.id]?.lastPlayer)?.id;
    renderHTML(
      $('leaders-list'),
      list
        .map((g) => {
          const r = records[g.id],
            p = r?.lastPlayer;
          return `<details class="leader-gym" data-gym="${g.id}" ${open.has(g.id) || (!initialized && g.id === first) ? 'open' : ''}><summary><span><strong>${g.type} GYM — ${esc(p?.name || (r ? 'Posto vago' : 'Sem leitura'))}</strong><small>${g.city} · ${g.region === 'kanto' ? 'Kanto' : 'Johto'}${p ? ' · ' + (p.team ? p.team.length + ' Pokémon' : 'Equipe não informada') : ''}</small></span><span class="badge">${r?.vacant ? (p ? 'Último jogador registrado' : 'Vago') : p ? 'Líder na última leitura' : 'Aguardando'}</span></summary>${p ? `<div class="leader-record"><p class="hunt-note">${p.sinceAt ? 'Conquistado em ' + date(p.sinceAt) : 'Data da conquista não informada'} · ${fmt(p.defenses)} defesas<br>${p.team ? 'Equipe observada em ' + date(p.teamObservedAt ?? p.observedAt) : 'Equipe ainda não recebida'}${r.vacant ? '<br>Posto vago na leitura mais recente; equipe do último jogador preservada.' : ''}</p><div class="leader-team">${p.team ? p.team.map(pokemon).join('') : '<p>O jogo ainda não forneceu a equipe deste líder. Reabra Ginásios para atualizar.</p>'}</div></div>` : `<p class="leader-record">${r ? 'Nenhum jogador registrado para este ginásio. A equipe do NPC não substitui um líder jogador.' : 'Abra Ginásios no jogo para registrar o jogador que ocupa este posto.'}</p>`}</details>`;
        })
        .join('') ||
        '<div class="empty">Nenhum ginásio com estes filtros.</div>',
    );
    for (const details of $('leaders-list').querySelectorAll('.leader-gym')) {
      const record = records[details.dataset.gym];
      if (record?.vacant || !record?.lastPlayer?.team?.length) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = 'Simular contra esta equipe';
      button.className = 'leader-simulate';
      button.addEventListener('click', () =>
        renderSimulation.selectGym(details.dataset.gym),
      );
      details.querySelector('.leader-record').prepend(button);
    }
    if (first) initialized = true;
  }
  for (const id of ['leaders-region', 'leaders-type', 'leaders-search'])
    $(id).addEventListener('input', render);
  return render;
}
