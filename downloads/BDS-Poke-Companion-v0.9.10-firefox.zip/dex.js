import { STATS, baseStats, stat, normalize } from './core.js';

// A reference is deliberately synthetic; it must never enter the saved collection.
export function referenceRecord(species) {
  const bases = baseStats(species);
  return {
    name: species.name,
    speciesId: species.pokeId,
    level: 100,
    quality: 1,
    precision: null,
    total: 96,
    current: Object.fromEntries(
      STATS.map((k) => [k, stat(bases[k], 16, 100, 1, k)]),
    ),
    reference: true,
  };
}
export function cleanDexRows(input) {
  if (!Array.isArray(input) || input.length > 1000)
    throw Error('Leitura de Pokédex inválida.');
  const rows = {};
  for (const r of input) {
    if (
      !Number.isInteger(r?.id) ||
      r.id < 1 ||
      r.id > 1000000 ||
      typeof r.caught !== 'boolean' ||
      typeof r.complete !== 'boolean'
    )
      continue;
    const kills =
      Number.isSafeInteger(r.kills) && r.kills >= 0 ? r.kills : null;
    const threshold =
      Number.isInteger(r.threshold) && r.threshold > 0 && r.threshold <= 1000000
        ? r.threshold
        : null;
    rows[r.id] = {
      id: r.id,
      caught: r.caught,
      complete: r.complete,
      kills,
      threshold,
      atLeast: r.atLeast === true,
    };
  }
  return rows;
}
export function speciesLocations(hunts) {
  const map = new Map();
  for (const h of hunts)
    for (const id of h.speciesIds) {
      if (!map.has(id)) map.set(id, []);
      map.get(id).push(h);
    }
  return map;
}
export function filterDex(creatures, locations, progress = {}, filters = {}) {
  const q = normalize(filters.query).replace(/^#/, ''),
    known = Object.values(progress);
  const list = creatures.filter((c) => {
    const p = progress[c.pokeId],
      loc = locations.get(c.pokeId) || [];
    if (q && !normalize(c.name).includes(q) && !String(c.pokeId).includes(q))
      return false;
    if (filters.type && ![c.type1, c.type2].includes(filters.type))
      return false;
    if (filters.region && !loc.some((h) => h.region === filters.region))
      return false;
    if (filters.minLevel || filters.maxLevel) {
      if (
        !loc.some(
          (h) =>
            (!filters.region || h.region === filters.region) &&
            (!filters.minLevel || h.level >= filters.minLevel) &&
            (!filters.maxLevel || h.level <= filters.maxLevel),
        )
      )
        return false;
    }
    if (
      (filters.caught === 'yes' && p?.caught !== true) ||
      (filters.caught === 'no' && p?.caught !== false) ||
      (filters.caught === 'unknown' && p)
    )
      return false;
    if (
      (filters.log === 'yes' && p?.complete !== true) ||
      (filters.log === 'no' && p?.complete !== false) ||
      (filters.log === 'unknown' && p)
    )
      return false;
    return true;
  });
  list.sort((a, b) =>
    filters.sort === 'name'
      ? a.name.localeCompare(b.name)
      : filters.sort === 'kills'
        ? (progress[b.pokeId]?.kills ?? -1) -
            (progress[a.pokeId]?.kills ?? -1) || a.pokeId - b.pokeId
        : a.pokeId - b.pokeId,
  );
  return {
    list,
    totals: {
      known: known.length,
      caught: known.filter((p) => p.caught).length,
      complete: known.filter((p) => p.complete).length,
      incomplete: known.filter((p) => !p.complete).length,
    },
  };
}
