import { EXP, baseStats, stat } from './core.js';

export const GYMS = [
  ['pewter', 'Pewter', 'ROCK'],
  ['cerulean', 'Cerulean', 'WATER'],
  ['vermilion', 'Vermilion', 'ELECTRIC'],
  ['celadon', 'Celadon', 'GRASS'],
  ['fuchsia', 'Fuchsia', 'POISON'],
  ['saffron', 'Saffron', 'PSYCHIC'],
  ['cinnabar', 'Cinnabar', 'FIRE'],
  ['viridian', 'Viridian', 'GROUND'],
  ['violet', 'Violet', 'FLYING'],
  ['azalea', 'Azalea', 'BUG'],
  ['goldenrod', 'Goldenrod', 'NORMAL'],
  ['ecruteak', 'Ecruteak', 'GHOST'],
  ['cianwood', 'Cianwood', 'FIGHTING'],
  ['olivine', 'Olivine', 'STEEL'],
  ['mahogany', 'Mahogany', 'ICE'],
  ['blackthorn', 'Blackthorn', 'DRAGON'],
  ['spikemuth', 'Spikemuth', 'DARK'],
  ['laverre', 'Laverre', 'FAIRY'],
].map(([id, city, type], i) => ({
  id,
  city,
  type,
  region: i < 8 ? 'kanto' : 'johto',
  order: i + 1,
}));
const text = (v, n = 100) =>
  typeof v === 'string' ? v.trim().slice(0, n) : '';
const integer = (v, max = 1e9) =>
  Number.isSafeInteger(v) && v >= 0 && v <= max ? v : null;
function member(p) {
  if (!p || !text(p.name) || !integer(p.level, 1000000)) return null;
  const current = Object.fromEntries(
    ['atk', 'def', 'spa', 'spd', 'vel'].map((k) => [
      k,
      integer(p.current?.[k]),
    ]),
  );
  return {
    speciesId: integer(p.speciesId, 1000000),
    name: text(p.name),
    level: p.level,
    shiny: p.shiny === true,
    maxHp: integer(p.maxHp),
    current,
    moves: Array.isArray(p.moves)
      ? p.moves
          .slice(0, 12)
          .filter((m) => text(m?.name))
          .map((m) => ({
            name: text(m.name),
            type: text(m.type, 20),
            category: text(m.category, 20),
            power: integer(m.power, 100000),
          }))
      : [],
  };
}
export function cleanGymSnapshot(payload, now = Date.now()) {
  if (
    !Array.isArray(payload?.rows) ||
    payload.rows.length > 18 ||
    !Number.isFinite(payload.observedAt) ||
    payload.observedAt > now + 1000 ||
    now - payload.observedAt > 600000
  )
    return [];
  const seen = new Set();
  return payload.rows.flatMap((row) => {
    const gym = GYMS.find((g) => g.id === row?.id);
    if (!gym || seen.has(gym.id) || typeof row.isNpc !== 'boolean') return [];
    if (!row.isNpc && !text(row.name)) return [];
    seen.add(gym.id);
    const since =
      typeof row.sinceAt === 'string' ? Date.parse(row.sinceAt) : NaN;
    const team =
      Array.isArray(row.team) && row.team.length <= 6
        ? row.team.map(member)
        : null;
    return [
      {
        ...gym,
        isNpc: row.isNpc,
        name: row.isNpc ? null : text(row.name),
        sinceAt: Number.isFinite(since) ? new Date(since).toISOString() : null,
        defenses: integer(row.defenses, 1000000),
        team: team?.length && team.every(Boolean) ? team : null,
        observedAt: payload.observedAt,
      },
    ];
  });
}
export function mergeGymLeaders(previous = { records: {} }, rows) {
  const records = { ...previous.records };
  let changed = false;
  for (const row of rows) {
    const old = records[row.id];
    if (old && row.observedAt <= old.observedAt) continue;
    const last = old?.lastPlayer;
    // Another account can finish an older HTTP request after a newer conquest.
    if (
      !row.isNpc &&
      last?.sinceAt &&
      row.sinceAt &&
      Date.parse(row.sinceAt) < Date.parse(last.sinceAt)
    )
      continue;
    let lastPlayer = last || null;
    if (!row.isNpc) {
      const same =
        last?.name === row.name &&
        (!row.sinceAt || !last.sinceAt || row.sinceAt === last.sinceAt);
      lastPlayer = {
        name: row.name,
        sinceAt: row.sinceAt || (same ? last.sinceAt : null),
        defenses: row.defenses,
        team: row.team || (same ? last.team : null),
        teamObservedAt: row.team
          ? row.observedAt
          : same
            ? (last.teamObservedAt ?? last.observedAt)
            : null,
        observedAt: row.observedAt,
      };
    }
    records[row.id] = {
      id: row.id,
      observedAt: row.observedAt,
      vacant: row.isNpc,
      lastPlayer,
    };
    changed = true;
  }
  return changed
    ? {
        schema: 1,
        records,
        updatedAt: Math.max(...Object.values(records).map((r) => r.observedAt)),
      }
    : previous;
}

// Invert the existing rounding model without assuming a quality or an IV total.
// Sweep all transitions: each accepted interval shares ONE quality across stats.
// Combat maxHp is deliberately excluded: it is not the underlying HP attribute.
export function inferLeader(member, species) {
  const keys = ['atk', 'def', 'spa', 'spd', 'vel'],
    bases = species ? baseStats(species) : null;
  const invalid = (reason) => ({ valid: false, reason });
  if (!bases || keys.some((k) => !Number.isFinite(bases[k]) || bases[k] <= 0))
    return invalid('Espécie sem atributos base confirmados no catálogo.');
  if (
    !Number.isInteger(member.level) ||
    member.level < 1 ||
    keys.some(
      (k) => !Number.isInteger(member.current?.[k]) || member.current[k] < 0,
    )
  )
    return invalid('Faltam nível ou atributos para calcular as faixas.');
  if (member.level < 15)
    return {
      ...invalid(
        'Estimativas disponíveis a partir do nível 15. Neste nível, o arredondamento não permite uma leitura confiável.',
      ),
      lowLevel: true,
    };
  const cuts = new Set([0]);
  for (const k of keys)
    for (let iv = 1; iv <= 32; iv++)
      for (const delta of [-0.5, 0.5])
        cuts.add(
          (Math.max(0, member.current[k] + delta) /
            (((bases[k] + 2 * iv) * member.level) / 100)) **
            (1 / EXP[k]),
        );
  const sorted = [...cuts].sort((a, b) => a - b),
    union = Object.fromEntries(keys.map((k) => [k, new Set()])),
    ranges = [];
  let totalMin = Infinity,
    totalMax = -Infinity;
  for (let i = 0; i < sorted.length - 1; i++) {
    const lo = sorted[i],
      hi = sorted[i + 1],
      q = (lo + hi) / 2;
    if (!Number.isFinite(q) || q <= 0 || lo === hi) continue;
    const lists = keys.map((k) =>
      Array.from({ length: 32 }, (_, i) => i + 1).filter(
        (iv) => stat(bases[k], iv, member.level, q, k) === member.current[k],
      ),
    );
    if (lists.some((list) => !list.length)) continue;
    const last = ranges.at(-1);
    if (last && last[1] === lo) last[1] = hi;
    else ranges.push([lo, hi]);
    lists.forEach((list, i) => list.forEach((iv) => union[keys[i]].add(iv)));
    totalMin = Math.min(
      totalMin,
      1 + lists.reduce((sum, list) => sum + list[0], 0),
    );
    totalMax = Math.max(
      totalMax,
      32 + lists.reduce((sum, list) => sum + list.at(-1), 0),
    );
  }
  if (!ranges.length)
    return invalid(
      'Os atributos de combate não fecham com o modelo sem bônus. Qualidade e IVs não podem ser deduzidos com segurança; helds, bônus ou a forma do Pokémon podem alterar esses números.',
    );
  const ivs = Object.fromEntries(
    keys.map((k) => {
      const values = [...union[k]].sort((a, b) => a - b);
      return [
        k,
        {
          min: values[0],
          max: values.at(-1),
          values,
          exact: values.length === 1,
        },
      ];
    }),
  );
  ivs.hp = { min: 1, max: 32, values: [], exact: false, unknown: true };
  return {
    valid: true,
    qualityRange: [ranges[0][0], ranges.at(-1)[1]],
    qualityIntervals: ranges,
    ivs,
    total: { min: totalMin, max: totalMax },
    conditional: true,
  };
}
