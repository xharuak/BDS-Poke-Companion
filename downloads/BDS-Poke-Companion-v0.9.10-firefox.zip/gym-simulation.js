import { availableMoves, multiplier, pokemonTypes, TYPES } from './battle.js';
import { findSpecies } from './core.js';

const keys = ['atk', 'def', 'spa', 'spd', 'vel'];
const int = (n, min = 0, max = 1e9) =>
  Number.isSafeInteger(n) && n >= min && n <= max;
const text = (s, max = 100) =>
  typeof s === 'string' ? s.trim().slice(0, max) : '';
export function cleanTeamSnapshot(payload, now = Date.now()) {
  if (
    !payload ||
    !Number.isFinite(payload.observedAt) ||
    payload.observedAt > now + 1000 ||
    now - payload.observedAt > 600000
  )
    return null;
  if (!Array.isArray(payload.members) || payload.members.length > 6)
    return null;
  const seen = new Set();
  const members = payload.members.map((p) => {
    if (
      !p ||
      !text(p.id) ||
      seen.has(p.id) ||
      !text(p.name) ||
      !int(p.level, 1, 1000000)
    )
      return null;
    seen.add(p.id);
    return {
      id: text(p.id),
      speciesId: int(p.speciesId, 1, 1000000) ? p.speciesId : null,
      name: text(p.name),
      level: p.level,
      shiny: p.shiny === true,
      types: Array.isArray(p.types)
        ? [...new Set(p.types.filter((t) => TYPES[t]))].slice(0, 2)
        : [],
      maxHp: int(p.maxHp, 1) ? p.maxHp : null,
      hpSource: p.hpSource === 'observed' ? 'observed' : 'derived',
      current: Object.fromEntries(
        keys.map((k) => [k, int(p.current?.[k]) ? p.current[k] : null]),
      ),
      moves: cleanMoves(p.moves),
    };
  });
  if (members.some((p) => !p)) return null;
  return { observedAt: payload.observedAt, members };
}
function cleanMoves(moves) {
  return Array.isArray(moves)
    ? moves
        .slice(0, 12)
        .filter((m) => m && text(m.name))
        .map((m) => ({
          name: text(m.name),
          type: text(m.type, 20),
          category: text(m.category, 20),
          power: int(m.power, 0, 100000) ? m.power : null,
        }))
    : [];
}
export function simulationMember(member, creatures) {
  const c =
    creatures.find((c) => c.pokeId === member.speciesId) ||
    findSpecies(creatures, member.name);
  const observedMoves = cleanMoves(member.moves);
  return {
    ...member,
    speciesId: c?.pokeId || member.speciesId,
    types: member.types?.length ? member.types : c ? pokemonTypes(c) : [],
    current: { ...member.current },
    moves: observedMoves.length
      ? observedMoves
      : c
        ? availableMoves(c, member.level).map((m) => ({ ...m }))
        : [],
    movesSource: observedMoves.length ? 'observed' : 'catalog',
  };
}
export function validateBattle(team, opponents, gymType, free = false) {
  const errors = [];
  for (const [label, members] of [
    ['Sua equipe', team],
    ['Equipe do ginásio', opponents],
  ]) {
    if (!Array.isArray(members) || !members.length || members.length > 6) {
      errors.push(`${label}: é necessário ter de 1 a 6 Pokémon.`);
      continue;
    }
    for (const p of members) {
      if (
        !int(p.level, 1, 1000000) ||
        !int(p.maxHp, 1) ||
        keys.some((k) => !int(p.current?.[k], 1))
      )
        errors.push(
          `${p.name}: preencha nível, HP máximo e os cinco atributos com inteiros positivos.`,
        );
      if (!p.types?.length || p.types.some((t) => !TYPES[t]))
        errors.push(`${p.name}: tipagem não identificada.`);
      if (
        !p.moves?.some(
          (m) =>
            ['PHYSICAL', 'SPECIAL'].includes(m.category) &&
            int(m.power, 1, 100000) &&
            TYPES[m.type],
        )
      )
        errors.push(`${p.name}: nenhum golpe de dano disponível para simular.`);
    }
  }
  if (!free && team?.length) {
    if (team.some((p) => !p.types?.includes(gymType)))
      errors.push(
        `Para disputar a liderança, todos os seus Pokémon precisam ser do tipo ${TYPES[gymType] || gymType}. Troque a equipe no jogo ou escolha Comparação livre.`,
      );
    const distinct = new Set(
      team.map((p) => `${p.speciesId || p.name}:${!!p.shiny}`),
    );
    if (distinct.size !== team.length)
      errors.push(
        'A disputa de liderança não aceita a mesma espécie repetida na mesma forma normal/shiny.',
      );
    if (team.some((p) => p.speciesId === 132 || /ditto/i.test(p.name)))
      errors.push('Ditto não participa deste modelo de disputa de liderança.');
  }
  return [...new Set(errors)];
}

// Explicit approximation, NOT the private game-server formula. This level-based
// damage model, 85–100% roll, turn order and AI are hypotheses disclosed in the UI.
export function matchup(attacker, defender, chart) {
  return attacker.moves
    .filter(
      (m) =>
        ['PHYSICAL', 'SPECIAL'].includes(m.category) &&
        m.power > 0 &&
        TYPES[m.type],
    )
    .map((move) => {
      const special = move.category === 'SPECIAL';
      const effectiveness = multiplier(chart, move.type, defender.types, false);
      const stab = attacker.types.includes(move.type) ? 1.5 : 1;
      const attack = attacker.current[special ? 'spa' : 'atk'];
      const defense = defender.current[special ? 'spd' : 'def'];
      const damage =
        effectiveness === null || effectiveness === 0
          ? 0
          : ((((2 * attacker.level) / 5 + 2) * move.power * attack) /
              defense /
              50 +
              2) *
            stab *
            effectiveness;
      return {
        name: move.name,
        type: move.type,
        category: move.category,
        power: move.power,
        effectiveness,
        stab,
        damage,
      };
    })
    .sort(
      (a, b) =>
        b.damage - a.damage ||
        b.power - a.power ||
        a.name.localeCompare(b.name),
    )[0];
}
function random(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let n = state;
    n = Math.imul(n ^ (n >>> 15), n | 1);
    n ^= n + Math.imul(n ^ (n >>> 7), n | 61);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}
function seedFor(value) {
  let n = 2166136261;
  for (const c of JSON.stringify(value))
    n = Math.imul(n ^ c.charCodeAt(0), 16777619);
  return n >>> 0;
}
function duel(team, opponents, matrix, enemyFactor, rng, trace = false) {
  let a = 0,
    b = 0,
    hpA = team[0].maxHp,
    hpB = opponents[0].maxHp,
    round = 0;
  const events = [];
  while (a < team.length && b < opponents.length && round < 1200) {
    round++;
    const x = team[a],
      y = opponents[b],
      pair = matrix[a][b];
    if (!pair.ours.damage && !pair.theirs.damage)
      return { outcome: 'draw', rounds: round, events, reason: 'immunity' };
    const first =
      x.current.vel === y.current.vel
        ? rng() < 0.5
        : x.current.vel > y.current.vel;
    for (const ours of first ? [true, false] : [false, true]) {
      const move = ours ? pair.ours : pair.theirs;
      const damage = move.damage
        ? Math.max(
            1,
            Math.floor(
              move.damage * (0.85 + 0.15 * rng()) * (ours ? 1 : enemyFactor),
            ),
          )
        : 0;
      const remaining = Math.max(0, (ours ? hpB : hpA) - damage);
      if (trace && events.length < 60)
        events.push({
          round,
          ours,
          attacker: ours ? x.name : y.name,
          defender: ours ? y.name : x.name,
          move: move.name,
          damage,
          remaining,
        });
      if (ours) hpB = remaining;
      else hpA = remaining;
      // The Pokémon replacing a fainted one enters on the next round. The survivor
      // keeps its remaining HP; no full heal or free retaliation after a knockout.
      if (remaining === 0) {
        if (ours) {
          b++;
          hpB = opponents[b]?.maxHp || 0;
        } else {
          a++;
          hpA = team[a]?.maxHp || 0;
        }
        break;
      }
    }
  }
  return {
    outcome:
      b === opponents.length ? 'win' : a === team.length ? 'loss' : 'draw',
    rounds: round,
    events,
    reason: round >= 1200 ? 'limit' : null,
  };
}
export function simulateGym({
  team,
  opponents,
  chart,
  gymType,
  free = false,
  trials = 2000,
}) {
  const errors = validateBattle(team, opponents, gymType, free);
  if (errors.length) return { errors };
  if (!Number.isInteger(trials) || trials < 100 || trials > 5000)
    return { errors: ['Quantidade de simulações inválida.'] };
  if (
    !chart ||
    [...team, ...opponents].some(
      (p) =>
        p.types.some((t) => !chart[t]) ||
        p.moves.some((m) => m.power > 0 && !chart[m.type]),
    )
  )
    return { errors: ['Tabela de tipos incompleta.'] };
  const matrix = team.map((x) =>
    opponents.map((y) => ({
      ours: matchup(x, y, chart),
      theirs: matchup(y, x, chart),
    })),
  );
  const seed = seedFor([team, opponents]),
    scenarios = [];
  let example;
  for (const [key, label, factor] of [
    ['baseline', 'Referência', 1],
    ['favorable', 'Rival causa 15% menos dano', 0.85],
    ['adverse', 'Rival causa 15% mais dano', 1.15],
  ]) {
    const rng = random(seed),
      counts = { win: 0, loss: 0, draw: 0 },
      n = key === 'baseline' ? trials : Math.min(trials, 500);
    let rounds = 0,
      first;
    for (let i = 0; i < n; i++) {
      const battle = duel(
        team,
        opponents,
        matrix,
        factor,
        rng,
        i === 0 && key === 'baseline',
      );
      counts[battle.outcome]++;
      rounds += battle.rounds;
      if (!i) first = battle;
    }
    if (key === 'baseline') example = first;
    scenarios.push({
      key,
      label,
      factor,
      trials: n,
      counts,
      win: (counts.win / n) * 100,
      loss: (counts.loss / n) * 100,
      draw: (counts.draw / n) * 100,
      meanRounds: rounds / n,
    });
  }
  return { errors: [], scenarios, example, matrix, seed };
}
