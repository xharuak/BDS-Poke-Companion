import { normalize } from './core.js';
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
let catalog = { items: {}, assets: {} },
  names = new Map(),
  pending;
export function loadItemSprites() {
  if (!pending)
    pending = fetch('data/item-sprites.json')
      .then((r) => {
        if (!r.ok) throw Error('Ícones indisponíveis');
        return r.json();
      })
      .then((data) => {
        catalog = data;
        names = new Map(
          Object.entries(data.items).map(([id, item]) => [
            normalize(item.name),
            { ...item, id },
          ]),
        );
      })
      .catch(() => {});
  return pending;
}
export function itemSprite(item, { eager = false } = {}) {
  const name = typeof item === 'string' ? item : item?.name || 'Item';
  const entry =
    item?.id && catalog.items[item.id]
      ? { ...catalog.items[item.id], id: item.id }
      : names.get(normalize(name));
  const asset = entry && catalog.assets[entry.asset];
  if (!asset)
    return `<span class="item-sprite item-sprite-missing" role="img" aria-label="Imagem indisponível: ${esc(name)}" title="Imagem deste item indisponível"><span class="item-sprite-fallback">?</span></span>`;
  const note = entry.generic
    ? 'Ícone genérico no catálogo oficial'
    : 'Sprite oficial do item';
  return `<span class="item-sprite${entry.generic ? ' item-sprite-generic' : ''}" data-item-id="${esc(entry.id)}" title="${esc(name)} · ${note}"><img src="${esc(asset.file)}" alt="${esc(name)}${entry.generic ? ' (ícone genérico)' : ''}" loading="${eager ? 'eager' : 'lazy'}" decoding="async" draggable="false"><span class="item-sprite-fallback" hidden>?</span></span>`;
}
if (typeof document !== 'undefined')
  document.addEventListener(
    'error',
    (e) => {
      if (e.target.tagName !== 'IMG') return;
      const wrap = e.target.closest('.item-sprite');
      if (!wrap) return;
      e.target.hidden = true;
      wrap.classList.add('item-sprite-missing');
      wrap.querySelector('.item-sprite-fallback').hidden = false;
      wrap.setAttribute('role', 'img');
      wrap.setAttribute('aria-label', 'Imagem indisponível: ' + e.target.alt);
      wrap.title = 'Imagem deste item indisponível';
    },
    true,
  );
