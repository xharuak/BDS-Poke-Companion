import { STATS, baseStats, stat } from './core.js';
import { availableMoves, multiplier, pokemonTypes, TYPES } from './battle.js';
import { compareOffense } from './meta.js';
import {
  ACCESS_REGIONS,
  captureRegionIndex,
  captureRegionsFor,
  acquisitionRoutesFor,
  validAccessRegions,
  isCaptureExcluded,
} from './availability.js';

export const GYM_SCENARIOS = {
  baseline: { label: 'Atributos de referência', short: 'Referência', mod: {} },
  special_wall: {
    label: 'Rival com Def. Especial ×2',
    short: 'Def. Esp. ×2',
    mod: { spd: 2 },
  },
  physical_wall: {
    label: 'Rival com Defesa ×2',
    short: 'Defesa ×2',
    mod: { def: 2 },
  },
  endurance: { label: 'Rival com HP ×1,5', short: 'HP ×1,5', mod: { hp: 1.5 } },
};
export const mean = (xs) =>
  xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0;
export function gymPool(
  creatures,
  type,
  includeLegendary = false,
  availability = null,
) {
  return creatures
    .filter(
      (c) =>
        c.pokeId > 0 &&
        c.pokeId < 10000 &&
        c.pokeId !== 132 &&
        !isCaptureExcluded(c) &&
        (!availability ||
          acquisitionRoutesFor(c, availability.index, availability.regions)
            .length) &&
        pokemonTypes(c).includes(type) &&
        (includeLegendary || c.rarity !== 'LEGENDARY') &&
        STATS.every(
          (k) => Number.isFinite(baseStats(c)[k]) && baseStats(c)[k] > 0,
        ),
    )
    .sort(compareOffense);
}
export function gymStats(c, level, quality = 1, mod = {}) {
  const b = baseStats(c);
  return Object.fromEntries(
    STATS.map((k) => [
      k,
      Math.max(1, stat(b[k], 16, level, quality, k) * (mod[k] ?? 1)),
    ]),
  );
}

// Relative per-hit model, not a reconstructed server damage formula or AI.
// PvP uses the published base chart here; hunt amplification is NOT applied.
export function gymMoves(c, opponent, stats, opponentStats, level, chart) {
  return availableMoves(c, level)
    .map((move) => {
      const mult = multiplier(chart, move.type, pokemonTypes(opponent), false);
      if (mult === null) return null;
      const special = move.category === 'SPECIAL',
        attackKey = special ? 'spa' : 'atk',
        defenseKey = special ? 'spd' : 'def';
      const attack = stats[attackKey],
        defense = Math.max(1, opponentStats[defenseKey]),
        stab = pokemonTypes(c).includes(move.type) ? 1.5 : 1;
      return {
        move,
        multiplier: mult,
        stab,
        attack,
        defense,
        attackKey,
        defenseKey,
        hit: ((move.power * attack) / defense) * stab * mult,
      };
    })
    .filter(Boolean)
    .sort(
      (a, b) =>
        b.hit - a.hit ||
        b.move.power - a.move.power ||
        a.move.name.localeCompare(b.move.name),
    );
}
export function gymDuel({
  c,
  opponent,
  level,
  opponentLevel,
  quality = 1,
  opponentQuality = 1,
  scenario = 'baseline',
  chart,
}) {
  const stats = gymStats(c, level, quality),
    opponentStats = gymStats(
      opponent,
      opponentLevel,
      opponentQuality,
      GYM_SCENARIOS[scenario].mod,
    );
  const moves = gymMoves(c, opponent, stats, opponentStats, level, chart),
    reply = gymMoves(opponent, c, opponentStats, stats, opponentLevel, chart);
  const outgoing = (moves[0]?.hit ?? 0) / opponentStats.hp,
    incoming = (reply[0]?.hit ?? 0) / stats.hp;
  const score = outgoing + incoming ? outgoing / (outgoing + incoming) : 0.5;
  return {
    c,
    opponent,
    stats,
    opponentStats,
    moves,
    reply,
    outgoing,
    incoming,
    score,
    ratio: incoming ? outgoing / incoming : null,
    blocked: !outgoing && !incoming,
  };
}

export function projectGym({
  creatures,
  hunts = [],
  chart,
  type = 'ICE',
  opponentType = 'ICE',
  mode = 'leadership',
  level = 100,
  opponentLevel = 100,
  quality = 1,
  opponentQuality = 1,
  includeLegendary = false,
  opponentIds = null,
  accessibleRegions = ACCESS_REGIONS,
}) {
  const invalid = (message) => ({
    error: message,
    team: [],
    opponents: [],
    rows: [],
  });
  if (!TYPES[type] || !TYPES[opponentType])
    return invalid('Escolha uma tipagem válida para cada equipe.');
  if (!['leadership', 'free'].includes(mode))
    return invalid('Modo de confronto inválido.');
  if (mode === 'leadership' && type !== opponentType)
    return invalid(
      'Na liderança, as duas equipes devem ter o tipo do ginásio. Use confronto livre para outros tipos.',
    );
  if (
    [level, opponentLevel].some(
      (n) => !Number.isSafeInteger(n) || n < 1 || n > 100000,
    )
  )
    return invalid('Informe níveis inteiros de 1 a 100.000.');
  if (
    [quality, opponentQuality].some(
      (n) => !Number.isFinite(n) || n < 0.1 || n > 5,
    )
  )
    return invalid('Informe qualidades entre 0,1 e 5.');
  if (!validAccessRegions(accessibleRegions) || !accessibleRegions.length)
    return invalid('Marque pelo menos uma região acessível.');
  const index = captureRegionIndex(creatures, hunts),
    availability = { index, regions: accessibleRegions };
  const pool = gymPool(creatures, type, includeLegendary, availability).filter(
    (c) => availableMoves(c, level).length,
  );
  const enemyPool = gymPool(
    creatures,
    opponentType,
    includeLegendary,
    availability,
  ).filter((c) => availableMoves(c, opponentLevel).length);
  if (!pool.length || !enemyPool.length)
    return invalid(
      'Nenhuma espécie disponível por captura, evolução ou NPC com golpes liberados para esses filtros.',
    );
  let opponents;
  if (opponentIds !== null) {
    if (
      !Array.isArray(opponentIds) ||
      opponentIds.length < 1 ||
      opponentIds.length > 6 ||
      new Set(opponentIds).size !== opponentIds.length
    )
      return invalid('Escolha de um a seis adversários diferentes.');
    opponents = opponentIds.map((id) => enemyPool.find((c) => c.pokeId === id));
    if (opponents.some((c) => !c))
      return invalid(
        'Há um rival sem obtenção confirmada ou incompatível com o tipo, nível ou regiões acessíveis.',
      );
  } else opponents = enemyPool.slice(0, 6);
  const rows = pool.map((c) => {
    const scenarios = Object.fromEntries(
      Object.keys(GYM_SCENARIOS).map((scenario) => [
        scenario,
        opponents.map((opponent) =>
          gymDuel({
            c,
            opponent,
            level,
            opponentLevel,
            quality,
            opponentQuality,
            scenario,
            chart,
          }),
        ),
      ]),
    );
    const scores = Object.values(scenarios)
      .flat()
      .map((d) => d.score);
    return {
      c,
      scenarios,
      scores,
      captureRegions: captureRegionsFor(c, index, accessibleRegions),
      acquisitionRoutes: acquisitionRoutesFor(c, index, accessibleRegions),
      average: mean(scores),
      worst: Math.min(...scores),
    };
  });
  // Greedy complementary coverage across all opponent/scenario pairs. Same team
  // is evaluated in each scenario. This is not a globally optimal 6v6 solution.
  const team = [],
    best = Array(opponents.length * Object.keys(GYM_SCENARIOS).length).fill(0),
    remaining = [...rows];
  while (team.length < 6 && remaining.length) {
    for (const row of remaining)
      row.gain = mean(row.scores.map((s, i) => Math.max(best[i], s) - best[i]));
    remaining.sort(
      (a, b) =>
        b.gain - a.gain ||
        b.average - a.average ||
        b.worst - a.worst ||
        compareOffense(a.c, b.c),
    );
    const pick = remaining.shift();
    team.push(pick);
    pick.scores.forEach((s, i) => (best[i] = Math.max(best[i], s)));
  }
  const summaries = Object.fromEntries(
    Object.keys(GYM_SCENARIOS).map((key) => {
      const bestByOpponent = opponents.map((_, i) =>
        Math.max(...team.map((r) => r.scenarios[key][i].score)),
      );
      return [
        key,
        {
          covered: bestByOpponent.filter((n) => n > 0.5 + 1e-9).length,
          total: opponents.length,
          average: mean(bestByOpponent),
        },
      ];
    }),
  );
  return {
    team,
    opponents,
    rows,
    summaries,
    level,
    opponentLevel,
    quality,
    opponentQuality,
    type,
    opponentType,
    mode,
  };
}
