import { renderHTML } from './render-html.js';
import { captureRegionIndex } from './availability.js';
import {
  setupAccessRegions,
  getAccessibleRegions,
  acquisitionSummary,
} from './access-view.js';
import { GYM_SCENARIOS, gymPool, projectGym } from './gym.js';
import { availableMoves, TYPES, REGIONS } from './battle.js';
import { sprite } from './sprites.js';
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c],
    );
const fmt = (n, d = 1) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const category = (m) => (m.category === 'SPECIAL' ? 'Especial' : 'Físico');
const label = (d) =>
  d.blocked
    ? 'Sem impacto'
    : d.score > 0.5 + 1e-9
      ? 'Favorável'
      : d.score < 0.5 - 1e-9
        ? 'Desfavorável'
        : 'Equilibrado';
const tone = (d) =>
  d.blocked || Math.abs(d.score - 0.5) < 1e-9
    ? 'even'
    : d.score > 0.5
      ? 'good'
      : 'weak';
const ratio = (d) =>
  d.blocked
    ? '—'
    : d.incoming === 0
      ? 'sem resposta'
      : Math.round(d.ratio * 100) === 100 && Math.abs(d.score - 0.5) > 1e-9
        ? d.ratio < 1
          ? '<1×'
          : '>1×'
        : fmt(d.ratio, 2) + '×';
export function setupGym(catalog, chart, evidence) {
  const options = Object.entries(TYPES)
    .map(([v, n]) => `<option value="${v}">${n}</option>`)
    .join('');
  for (const id of ['gym-type', 'gym-enemy-type']) {
    renderHTML($(id), options);
    $(id).value = 'ICE';
  }
  renderHTML(
    $('gym-sources'),
    evidence.sources
      .map(
        (s) =>
          `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.label)} ↗</a>`,
      )
      .join(' · '),
  );
  $('gym-checked').textContent = evidence.checkedAt
    .split('-')
    .reverse()
    .join('/');
  const captureIndex = captureRegionIndex(catalog.creatures, catalog.hunts);
  let result,
    scenario = 'baseline',
    selected = null,
    timer;
  function controls() {
    return {
      creatures: catalog.creatures,
      hunts: catalog.hunts,
      accessibleRegions: getAccessibleRegions(),
      chart,
      type: $('gym-type').value,
      opponentType: $('gym-enemy-type').value,
      mode: $('gym-mode').value,
      level: Number($('gym-level').value),
      opponentLevel: Number($('gym-enemy-level').value),
      quality: Number($('gym-quality').value),
      opponentQuality: Number($('gym-enemy-quality').value),
    };
  }
  function roster(reset = false) {
    const settings = controls(),
      pool = gymPool(catalog.creatures, settings.opponentType, false, {
        index: captureIndex,
        regions: settings.accessibleRegions,
      }).filter((c) => availableMoves(c, settings.opponentLevel).length);
    const previous = reset
      ? []
      : [...document.querySelectorAll('.gym-enemy')].map((e) => e.value);
    renderHTML(
      $('gym-roster'),
      Array.from(
        { length: 6 },
        (_, i) =>
          `<label>Rival ${i + 1}<select class="gym-enemy" aria-label="Rival ${i + 1}"><option value="">Sem Pokémon</option>${pool.map((c) => `<option value="${c.pokeId}">${esc(c.name)}</option>`).join('')}</select></label>`,
      ).join(''),
    );
    document.querySelectorAll('.gym-enemy').forEach((el, i) => {
      el.value = previous.length
        ? previous[i] || ''
        : String(pool[i]?.pokeId ?? '');
      el.addEventListener('change', render);
    });
  }
  function render() {
    const settings = controls();
    result = projectGym({
      ...settings,
      opponentIds: [...document.querySelectorAll('.gym-enemy')]
        .filter((e) => e.value)
        .map((e) => Number(e.value)),
    });
    $('gym-summary').textContent =
      result.error ||
      `${TYPES[result.type]} × ${TYPES[result.opponentType]} · ${result.team.length} integrantes sugeridos entre ${result.rows.length} espécies · ${result.opponents.length} rivais · 4 cenários. Equipe sugerida para estes filtros, não lida do ginásio.`;
    $('gym-output').hidden = !!result.error;
    if (result.error) {
      $('gym-team').replaceChildren();
      $('gym-matrix').replaceChildren();
      $('gym-duel').replaceChildren();
      return;
    }
    selected = null;
    renderHTML(
      $('gym-team'),
      result.team
        .map(
          (r, i) =>
            `<article class="gym-member" data-gym-id="${r.c.pokeId}"><span class="meta-rank">${i + 1}</span>${sprite(r.c)}<div><button class="meta-name" data-species="${r.c.pokeId}" data-tab="battle" data-level="${result.level}">${esc(r.c.name)}</button><small>${i ? 'Complemento da equipe' : 'Primeira escolha do modelo'} · ${r.scores.filter((s) => s > 0.5 + 1e-9).length}/${r.scores.length} confrontos favoráveis</small><small class="capture-location">Obtenção: ${esc(acquisitionSummary(r.acquisitionRoutes))}</small></div></article>`,
        )
        .join(''),
    );
    renderScenario();
  }
  function renderScenario() {
    if (!result?.team.length) return;
    renderHTML(
      $('gym-scenarios'),
      Object.entries(GYM_SCENARIOS)
        .map(
          ([key, s]) =>
            `<button data-scenario="${key}" class="${key === scenario ? 'active' : ''}" aria-pressed="${key === scenario}"><b>${s.short}</b><small>${result.summaries[key].covered}/${result.opponents.length} rivais com resposta favorável</small></button>`,
        )
        .join(''),
    );
    $('gym-scenario-note').textContent =
      GYM_SCENARIOS[scenario].label +
      '. A equipe sugerida permanece a mesma nos quatro cenários; os modificadores são hipóteses, não bônus reais do adversário.';
    renderHTML(
      $('gym-matrix'),
      `<table><caption>Relação de pressão enviada / recebida (não é multiplicador de tipo). Clique para comparar golpes. “Favorável” não garante vitória.</caption><thead><tr><th scope="col">Sua equipe</th>${result.opponents.map((c) => `<th scope="col">${esc(c.name)}</th>`).join('')}</tr></thead><tbody>${result.team.map((r) => `<tr><th scope="row">${esc(r.c.name)}</th>${r.scenarios[scenario].map((d) => `<td><button class="gym-cell ${tone(d)}" data-duel="${r.c.pokeId}:${d.opponent.pokeId}" aria-label="${esc(r.c.name)} contra ${esc(d.opponent.name)}: ${label(d)}"><b>${ratio(d)}</b><span>${label(d)}</span><small>${esc(d.moves[0]?.move.name || 'Sem golpe')}</small></button></td>`).join('')}</tr>`).join('')}</tbody></table>`,
    );
    if (!selected)
      selected = [result.team[0].c.pokeId, result.opponents[0].pokeId];
    renderDuel();
  }
  function renderDuel() {
    const row = result.team.find((r) => r.c.pokeId === selected[0]),
      duel = row?.scenarios[scenario].find(
        (d) => d.opponent.pokeId === selected[1],
      );
    if (!duel) return;
    document
      .querySelectorAll('[data-duel]')
      .forEach((e) =>
        e.classList.toggle('selected', e.dataset.duel === selected.join(':')),
      );
    const best = duel.moves[0],
      reply = duel.reply[0];
    const tableMoves = duel.moves
      .map(
        (m) =>
          `<tr${m === best ? ' class="best"' : ''}><th scope="row">${esc(m.move.name)}${m === best ? ' <span class="badge good">Melhor impacto</span>' : ''}<small>Aprende no Nv. ${m.move.learnLevel}</small></th><td>${TYPES[m.move.type]}<small>${category(m.move)}</small></td><td>${fmt(m.move.power, 0)}</td><td>${fmt(m.attack)} / ${fmt(m.defense)}<small>${m.attackKey === 'spa' ? 'Atq. Esp. / Def. Esp.' : 'Ataque / Defesa'}</small></td><td>${fmt(m.stab)}× / ${fmt(m.multiplier, 2)}×</td><td><b>${fmt(m.hit)}</b></td></tr>`,
      )
      .join('');
    renderHTML(
      $('gym-duel'),
      `<div class="gym-duel-head"><div>${sprite(duel.c)}<h3>${esc(duel.c.name)} <small>Nv. ${result.level} · Q ${fmt(result.quality, 3)}</small></h3></div><span>×</span><div>${sprite(duel.opponent)}<h3>${esc(duel.opponent.name)} <small>Nv. ${result.opponentLevel} · Q ${fmt(result.opponentQuality, 3)}</small></h3></div></div>
   <p class="hint"><b>${best ? esc(best.move.name) : 'Sem golpe'}</b>${best ? ' · ' + TYPES[best.move.type] + ' · ' + category(best.move) : ''} tem o maior impacto estimado neste confronto. ${best && best.move.type !== result.type ? 'A cobertura por outro tipo supera os golpes de ' + TYPES[result.type] + ' disponíveis.' : ''} Tipo “Normal” e categoria “Físico” são informações diferentes.</p>
   <div class="gym-pressure"><span>Pressão enviada <b>${fmt(duel.outgoing, 3)}</b></span><span>Pressão recebida <b>${fmt(duel.incoming, 3)}</b></span><span>Relação <b>${ratio(duel)}</b></span></div>
   <p class="hint">Resposta mais forte do rival: ${reply ? `${esc(reply.move.name)} · ${TYPES[reply.move.type]} · ${category(reply.move)} · índice ${fmt(reply.hit)}` : 'nenhum golpe natural liberado'}. HP de referência: ${fmt(duel.stats.hp)} × ${fmt(duel.opponentStats.hp)}. Velocidade: ${fmt(duel.stats.vel)} × ${fmt(duel.opponentStats.vel)}; não determina a ordem nesta projeção.</p>
   <div class="gym-scroll"><table class="gym-moves"><caption>Todos os golpes naturais liberados · comparação por golpe</caption><thead><tr><th>Golpe</th><th>Tipo / categoria</th><th>Poder</th><th>Atributo / defesa</th><th>STAB / tipo</th><th>Índice</th></tr></thead><tbody>${tableMoves}</tbody></table></div>
   <p class="gym-footnote">Índice = poder × atributo ofensivo ÷ defesa correspondente × STAB × tipo. Pressão = índice ÷ HP do alvo. Relação = pressão enviada ÷ recebida. Não são dano em HP, DPS, chance de vitória ou turnos até nocautear.</p>`,
    );
  }
  $('gym-scenarios').addEventListener('click', (e) => {
    const b = e.target.closest('[data-scenario]');
    if (b) {
      scenario = b.dataset.scenario;
      renderScenario();
    }
  });
  $('gym-matrix').addEventListener('click', (e) => {
    const b = e.target.closest('[data-duel]');
    if (b) {
      selected = b.dataset.duel.split(':').map(Number);
      renderDuel();
      $('gym-duel').scrollIntoView({ block: 'start', behavior: 'smooth' });
    }
  });
  function syncTypes(reset = true) {
    const leadership = $('gym-mode').value === 'leadership';
    $('gym-enemy-type').disabled = leadership;
    if (leadership) $('gym-enemy-type').value = $('gym-type').value;
    roster(reset);
    render();
  }
  for (const id of ['gym-mode', 'gym-type', 'gym-enemy-type'])
    $(id).addEventListener('change', () => syncTypes());
  for (const id of [
    'gym-level',
    'gym-quality',
    'gym-enemy-quality',
    'gym-enemy-level',
  ])
    $(id).addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (id === 'gym-enemy-level') roster(true);
        render();
      }, 150);
    });
  $('gym-reset-roster').onclick = () => {
    roster(true);
    render();
  };
  $('gym-enemy-type').disabled = true;
  roster(true);
  setupAccessRegions('gym-access', () => {
    roster(true);
    render();
  });
  return render;
}
