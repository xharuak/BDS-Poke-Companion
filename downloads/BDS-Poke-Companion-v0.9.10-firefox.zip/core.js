export const STATS = ['hp', 'atk', 'def', 'spa', 'spd', 'vel'];
export const LABELS = {
  hp: 'HP',
  atk: 'Ataque',
  def: 'Defesa',
  spa: 'Atq. especial',
  spd: 'Def. especial',
  vel: 'Velocidade',
};
export const EXP = {
  hp: 0.95,
  atk: 0.8,
  def: 0.8,
  spa: 0.8,
  spd: 0.8,
  vel: 0.95,
};
export const normalize = (s) =>
  String(s ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
export const num = (value) => {
  const s = String(value ?? '').trim();
  return s && /^\d+(?:[.,]\d+)?$/.test(s) ? Number(s.replace(',', '.')) : null;
};
export const integer = (s) => {
  s = String(s ?? '').trim();
  return /^(?:\d+|\d{1,3}(?:[.,\s]\d{3})+)$/.test(s)
    ? Number(s.replace(/[.,\s]/g, ''))
    : null;
};
export function stat(base, iv, level, quality, key) {
  return Math.round((((base + 2 * iv) * level) / 100) * quality ** EXP[key]);
}
export function qualityLabel(q) {
  return q < 1
    ? 'Fraca'
    : q < 1.1
      ? 'Comum'
      : q < 1.3
        ? 'Incomum'
        : q < 1.5
          ? 'Rara'
          : q < 1.7
            ? 'Épica'
            : q < 2
              ? 'Lendária'
              : q < 3
                ? 'Mítica'
                : q < 4
                  ? 'Ancestral'
                  : 'Divina';
}

// Dynamic programming constrains each stat by the TOTAL printed in the tooltip.
function sums(lists) {
  let acc = new Set([0]);
  for (const list of lists) {
    const next = new Set();
    for (const a of acc) for (const b of list) next.add(a + b);
    acc = next;
  }
  return acc;
}
export function estimate({
  bases,
  current,
  level,
  quality,
  precision = 3,
  total = null,
}) {
  if (
    !Number.isInteger(level) ||
    level < 1 ||
    !Number.isFinite(quality) ||
    quality <= 0 ||
    quality > 100
  )
    throw new Error(
      'Informe nível inteiro positivo e qualidade numérica válida.',
    );
  if (![null, 0, 1, 2, 3, 4].includes(precision))
    throw new Error('Precisão da qualidade inválida.');
  for (const k of STATS)
    if (
      !Number.isFinite(bases[k]) ||
      bases[k] <= 0 ||
      !Number.isInteger(current[k]) ||
      current[k] < 0
    )
      throw new Error(
        'Preencha os seis atributos base e os seis atributos atuais inteiros.',
      );
  if (total !== null && (!Number.isInteger(total) || total < 6 || total > 192))
    throw new Error('O IV total deve ser um inteiro entre 6 e 192.');
  const half = precision === null ? 0 : 0.5 * 10 ** -precision;
  const qLo = Math.max(Number.EPSILON, quality - half),
    qHi = quality + half;
  // One shared quality applies to all stats. Sweep every rounding transition;
  // testing only the independent marginal intervals would invent combinations.
  const cuts = new Set([qLo, qHi]);
  if (half)
    for (const k of STATS)
      for (let g = 1; g <= 32; g++)
        for (const delta of [-0.5, 0.5]) {
          const bound =
            (current[k] + delta) / (((bases[k] + 2 * g) * level) / 100);
          if (bound > 0) {
            const q = bound ** (1 / EXP[k]);
            if (q > qLo && q < qHi) cuts.add(q);
          }
        }
  const sorted = [...cuts].sort((a, b) => a - b);
  const samples = half
    ? sorted.slice(0, -1).map((q, i) => (q + sorted[i + 1]) / 2)
    : [quality];
  const union = Object.fromEntries(STATS.map((k) => [k, new Set()]));
  const totals = new Set();
  for (const q of samples) {
    const lists = STATS.map((k) =>
      Array.from({ length: 32 }, (_, i) => i + 1).filter(
        (g) => stat(bases[k], g, level, q, k) === current[k],
      ),
    );
    if (lists.some((a) => !a.length)) continue;
    const possible = sums(lists);
    if (total !== null && !possible.has(total)) continue;
    for (const n of possible) if (total === null || n === total) totals.add(n);
    lists.forEach((list, i) => {
      const other =
        total === null ? null : sums(lists.filter((_, j) => i !== j));
      for (const g of list)
        if (!other || other.has(total - g)) union[STATS[i]].add(g);
    });
  }
  if (!totals.size)
    return {
      valid: false,
      reason:
        'Os dados não fecham com o modelo. Confira espécie/forma, nível, qualidade, HP máximo, IV total e bônus de held, boost ou clã. Nenhum IV foi forçado para 0 ou 32.',
    };
  const ivs = Object.fromEntries(
    STATS.map((k) => {
      const values = [...union[k]].sort((a, b) => a - b);
      return [
        k,
        {
          min: values[0],
          max: values.at(-1),
          values,
          exact: values.length === 1,
        },
      ];
    }),
  );
  const power100 = {
    min:
      STATS.reduce((n, k) => n + stat(bases[k], ivs[k].min, 100, qLo, k), 0) *
      qLo,
    max:
      STATS.reduce((n, k) => n + stat(bases[k], ivs[k].max, 100, qHi, k), 0) *
      qHi,
  };
  return {
    valid: true,
    ivs,
    total: { min: Math.min(...totals), max: Math.max(...totals) },
    unique: STATS.every((k) => ivs[k].exact),
    power: STATS.reduce((n, k) => n + current[k], 0) * quality,
    power100,
    qualityRange: [qLo, qHi],
  };
}

export function parseTooltip(text) {
  if (typeof text !== 'string' || text.length > 6000) return null;
  const lines = text
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  const level = integer(
    text.match(/(?:\bNv\.?|\bNível|\bLevel|\bLv\.?)\s*:?\s*([\d.,]+)/i)?.[1],
  );
  const qualityText = text.match(
    /(?:Qualidade|Quality|Calidad)[^\n]*?(?:×|x)\s*(\d+(?:[.,]\d+)?)/i,
  )?.[1];
  const quality = num(qualityText);
  if (!lines[0] || !level || !quality) return null;
  const current = {};
  const aliases = {
    hp: 'HP',
    atk: 'Atk|Attack|Ataque',
    def: 'Def|Defense|Defesa',
    spa: 'SpA|SpAtk|Sp\\.?\\s*Atk',
    spd: 'SpD|SpDef|Sp\\.?\\s*Def',
    vel: 'Vel|Spe|Speed|Velocidade',
  };
  for (const [k, a] of Object.entries(aliases)) {
    const match = text.match(
      new RegExp(
        `(?:^|[\\s|])(?:${a})\\s*:?\\s*([\\d.,]+)(?:\\s*\\/\\s*([\\d.,]+))?`,
        'i',
      ),
    );
    current[k] = integer(k === 'hp' && match?.[2] ? match[2] : match?.[1]);
  }
  const totalMatch = text.match(/\bIV\s*:?\s*(\d+)\s*\/\s*192/i);
  const decimals = qualityText.split(/[.,]/)[1]?.length;
  const power = integer(text.match(/(?:Poder|Power)\s*:?\s*([\d.,]+)/i)?.[1]);
  return {
    name: lines[0]
      .replace(/[✨★☆]/gu, '')
      .trim()
      .slice(0, 100),
    level,
    quality,
    precision: decimals ? Math.min(4, decimals) : 0,
    total: totalMatch ? Number(totalMatch[1]) : null,
    current,
    observedPower: power,
    shiny: /✨|\bshiny\b/i.test(text),
    source: 'tooltip visível',
    capturedAt: new Date().toISOString(),
  };
}

export function findSpecies(creatures, name) {
  const n = normalize(name).replace(/^shiny\s+/, '');
  const matches = creatures.filter((c) => normalize(c.name) === n);
  if (matches.length < 2) return matches[0] || null;
  // A hunt can have a separate entry with the same name (e.g. Orre Ralts).
  // Resolve only when every duplicate explicitly captures into the same entry.
  // Names, Dex ranges and array order alone must never merge distinct forms.
  const captured = matches.filter(
    (c) =>
      Number.isSafeInteger(c.pokeId) &&
      c.pokeId > 0 &&
      (!Object.hasOwn(c, 'captureBase') || c.captureBase === c.pokeId) &&
      matches.every(
        (other) =>
          other === c ||
          (other.pokeId !== c.pokeId && other.captureBase === c.pokeId),
      ),
  );
  return captured.length === 1 ? captured[0] : null;
}
export function baseStats(c) {
  return {
    hp: c.baseHp,
    atk: c.baseAtk,
    def: c.baseDef,
    spa: c.baseSpAtk,
    spd: c.baseSpDef,
    vel: c.baseSpeed,
  };
}
// A partial visible tooltip is still useful for species research and observed totals.
// Keep strict validation in estimate(), but do not let it blank the whole analyzer.
export function estimateObserved(record, bases) {
  const missing = STATS.filter(
    (k) => !Number.isInteger(record?.current?.[k]) || record.current[k] < 0,
  );
  if (missing.length)
    return {
      valid: false,
      reason: `Leitura parcial: faltam ${missing.map((k) => LABELS[k]).join(', ')}. Passe o mouse novamente para reler. Batalha, Progressão e Drops continuam disponíveis.`,
    };
  try {
    return estimate({ ...record, bases });
  } catch (error) {
    return { valid: false, reason: error.message };
  }
}
export function huntRates({
  minutes,
  xp,
  gold,
  costs,
  kills = 0,
  remaining = null,
}) {
  if (
    ![minutes, xp, gold, costs, kills].every(Number.isFinite) ||
    minutes <= 0 ||
    [xp, gold, costs, kills].some((n) => n < 0)
  )
    throw new Error('Use duração positiva e ganhos/custos não negativos.');
  return {
    xpH: (xp * 60) / minutes,
    goldH: ((gold - costs) * 60) / minutes,
    net: gold - costs,
    killsH: (kills * 60) / minutes,
    etaMinutes:
      Number.isFinite(remaining) && remaining >= 0 && xp > 0
        ? (remaining / xp) * minutes
        : null,
  };
}
export function addProfile(profiles, name) {
  if (profiles.length >= 4)
    throw new Error('Limite de quatro fichas atingido.');
  return [
    ...profiles,
    {
      id: crypto.randomUUID(),
      name: String(name).trim().slice(0, 40) || `Conta ${profiles.length + 1}`,
      notes: '',
      records: [],
      sessions: [],
    },
  ];
}
export function validBackup(data) {
  if (
    data?.schema !== 'bds-poke-v1' ||
    !Array.isArray(data.profiles) ||
    !data.profiles.length ||
    data.profiles.length > 4
  )
    throw new Error('Backup inválido: são permitidas de uma a quatro fichas.');
  const ids = new Set();
  const profiles = data.profiles.map((p) => {
    if (
      typeof p.id !== 'string' ||
      ids.has(p.id) ||
      p.id.length > 100 ||
      !Array.isArray(p.records) ||
      !Array.isArray(p.sessions)
    )
      throw new Error('Ficha inválida no backup.');
    ids.add(p.id);
    const records = p.records.slice(-100).map((r) => {
      if (
        !Number.isInteger(r.speciesId) ||
        !Number.isInteger(r.level) ||
        r.level < 1 ||
        !Number.isFinite(r.quality) ||
        r.quality <= 0 ||
        !STATS.every(
          (k) => Number.isInteger(r.current?.[k]) && r.current[k] >= 0,
        ) ||
        ![null, 0, 1, 2, 3, 4].includes(r.precision) ||
        !(
          r.total === null ||
          (Number.isInteger(r.total) && r.total >= 6 && r.total <= 192)
        )
      )
        throw new Error('Exemplar inválido no backup.');
      return {
        id: String(r.id).slice(0, 100),
        speciesId: r.speciesId,
        name: String(r.name).slice(0, 100),
        level: r.level,
        quality: r.quality,
        precision: r.precision,
        total: r.total,
        observedPower:
          Number.isFinite(r.observedPower) && r.observedPower >= 0
            ? r.observedPower
            : null,
        shiny: r.shiny === true,
        current: Object.fromEntries(STATS.map((k) => [k, r.current[k]])),
        source: String(r.source || 'backup').slice(0, 100),
        capturedAt: String(r.capturedAt || '').slice(0, 40),
      };
    });
    const sessions = p.sessions.slice(-100).map((s) => {
      huntRates(s);
      return {
        id: String(s.id).slice(0, 100),
        target: String(s.target).slice(0, 100),
        date: String(s.date).slice(0, 40),
        minutes: s.minutes,
        xp: s.xp,
        gold: s.gold,
        costs: s.costs,
        kills: s.kills,
        remaining: null,
      };
    });
    return {
      id: p.id,
      name: String(p.name).slice(0, 40),
      notes: String(p.notes || '').slice(0, 2000),
      records,
      sessions,
    };
  });
  return {
    schema: 'bds-poke-v1',
    profiles,
    favorites: Array.isArray(data.favorites)
      ? data.favorites.filter((x) => typeof x === 'string').slice(0, 500)
      : [],
    active: profiles.some((p) => p.id === data.active)
      ? data.active
      : profiles[0].id,
  };
}
