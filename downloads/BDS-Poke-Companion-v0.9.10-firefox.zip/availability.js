// Capture availability is independent of rarity and combat strength.
// Explicit exclusions supplied by the player; no filter can re-enable them.
export const UNAVAILABLE_SPECIES = Object.freeze([
  144, 145, 146, 150, 151, 243, 244, 245, 249, 250, 251,
]);
export const ACCESS_REGIONS = Object.freeze([
  'kanto',
  'outland',
  'orre',
  'nightmare',
]);
export const DEFAULT_ACCESS_REGIONS = Object.freeze([
  'kanto',
  'outland',
  'orre',
]);
// NPC acquisition confirmed by the player on 2026-10-14. Keep it separate
// from map locations: these entries do not assert a hunt or an NPC location.
// Only forms with combat data in this game's catalog are included.
export const NPC_FAMILIES = Object.freeze([
  Object.freeze({
    baseId: 133,
    ids: Object.freeze([133, 134, 135, 136, 196, 197, 470, 471, 700]),
  }),
  Object.freeze({ baseId: 137, ids: Object.freeze([137, 233]) }),
]);
const excluded = new Set(UNAVAILABLE_SPECIES);
export const isCaptureExcluded = (c) => excluded.has(c?.pokeId);
export const validAccessRegions = (regions) =>
  Array.isArray(regions) && regions.every((r) => ACCESS_REGIONS.includes(r));

export function captureRegionIndex(creatures, hunts) {
  const byId = new Map(creatures.map((c) => [c.pokeId, c])),
    index = new Map();
  for (const h of hunts) {
    if (!ACCESS_REGIONS.includes(h.region)) continue;
    for (const id of h.speciesIds || []) {
      const wild = byId.get(id);
      if (!wild) continue;
      // The official captureBase field links wild variants to the captured form.
      // Do not strip prefixes or guess a region from a name, Dex number or level.
      const target = Object.hasOwn(wild, 'captureBase')
        ? wild.captureBase
        : wild.pokeId;
      if (
        !Number.isSafeInteger(target) ||
        target <= 0 ||
        target >= 10000 ||
        !byId.has(target) ||
        excluded.has(target)
      )
        continue;
      if (!index.has(target)) index.set(target, new Map());
      index
        .get(target)
        .set(h.region, {
          region: h.region,
          path: [target],
          names: [byId.get(target).name],
          kind: 'capture',
        });
    }
  }
  // Propagate only explicit catalog evolution edges. A route to an evolved
  // species does not claim that it can be captured directly in that region.
  const queue = [...index].flatMap(([id, regions]) =>
    [...regions.values()].map((route) => ({ id, route })),
  );
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const { id, route } = queue[cursor],
      next = byId.get(id)?.evolvesToId;
    if (
      !Number.isSafeInteger(next) ||
      next <= 0 ||
      next >= 10000 ||
      !byId.has(next) ||
      excluded.has(next) ||
      route.path.includes(next)
    )
      continue;
    const path = [...route.path, next],
      old = index.get(next)?.get(route.region);
    if (old && old.path.length <= path.length) continue;
    const evolved = {
      region: route.region,
      path,
      names: [...route.names, byId.get(next).name],
      kind: 'evolution',
    };
    if (!index.has(next)) index.set(next, new Map());
    index.get(next).set(route.region, evolved);
    queue.push({ id: next, route: evolved });
  }
  for (const family of NPC_FAMILIES) {
    for (const id of family.ids) {
      if (!byId.has(id) || excluded.has(id)) continue;
      if (!index.has(id)) index.set(id, new Map());
      index
        .get(id)
        .set('npc', {
          region: null,
          path: [id],
          names: [byId.get(id).name],
          kind: 'npc',
          family: byId.get(family.baseId)?.name || byId.get(id).name,
          source: 'player-confirmed',
          confirmedAt: '2026-10-14',
        });
    }
  }
  return index;
}
export function captureRegionsFor(
  c,
  index,
  accessibleRegions = ACCESS_REGIONS,
) {
  if (isCaptureExcluded(c) || !validAccessRegions(accessibleRegions)) return [];
  return ACCESS_REGIONS.filter(
    (r) => accessibleRegions.includes(r) && index.get(c.pokeId)?.has(r),
  );
}
export function acquisitionRoutesFor(
  c,
  index,
  accessibleRegions = ACCESS_REGIONS,
) {
  if (
    isCaptureExcluded(c) ||
    !validAccessRegions(accessibleRegions) ||
    !accessibleRegions.length
  )
    return [];
  const routes = captureRegionsFor(c, index, accessibleRegions).map((r) =>
      index.get(c.pokeId).get(r),
    ),
    npc = index.get(c.pokeId)?.get('npc');
  return npc ? [npc, ...routes] : routes;
}
