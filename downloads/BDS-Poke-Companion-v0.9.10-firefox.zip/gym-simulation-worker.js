import { simulateGym } from './gym-simulation.js';
self.onmessage = ({ data }) => {
  try {
    self.postMessage(simulateGym(data));
  } catch {
    self.postMessage({
      errors: [
        'Não foi possível concluir a simulação. Confira os atributos e tente novamente.',
      ],
    });
  }
};
