import { requireAccess } from './access-gate.js';
const api = globalThis.browser ?? chrome;
const status = document.getElementById('status'),
  open = document.getElementById('open'),
  all = document.getElementById('all');
const origin = 'https://poke.idleworld.online/*';
async function activate(e) {
  const currentOnly = e.currentTarget === open;
  open.disabled = all.disabled = true;
  try {
    // Firefox hides URLs until host access is granted. Request it in the click gesture first.
    if (!(await api.permissions.request({ origins: [origin] })))
      throw Error('Autorize o acesso ao site do jogo para ativar o BDS.');
    let message = { type: 'launch-all' };
    if (currentOnly) {
      const tabs = await api.tabs.query({ active: true, currentWindow: true });
      const tab = tabs.find((t) => {
        try {
          const u = new URL(t.url);
          return (
            u.origin === 'https://poke.idleworld.online' &&
            u.pathname === '/play'
          );
        } catch {
          return false;
        }
      });
      if (!tab)
        throw Error('Selecione o jogo ou use “Ativar nas contas abertas”.');
      message = { type: 'launch', tabId: tab.id };
    }
    status.textContent = 'Ativando…';
    const r = await api.runtime.sendMessage(message);
    if (!r?.ok) throw Error(r?.error || 'Não foi possível ativar.');
    if (currentOnly) {
      window.close();
      return;
    }
    const { count, results } = r.data;
    const failed = results.filter((r) => !r.active);
    status.textContent = count
      ? `${count} conta${count === 1 ? '' : 's'} ativa${count === 1 ? '' : 's'}. Use + na barra BDS de cada jogo. Próximas aberturas serão ativadas automaticamente.`
      : 'Nenhuma conta ativada. Abra o jogo neste workspace do Zen e tente novamente.';
    if (failed.length)
      status.textContent +=
        ' ' + [...new Set(failed.map((r) => r.error))].join(' ');
  } catch (e) {
    status.textContent = e.message;
  } finally {
    open.disabled = all.disabled = false;
  }
}
if (await requireAccess()) {
  open.addEventListener('click', activate);
  all.addEventListener('click', activate);
}
