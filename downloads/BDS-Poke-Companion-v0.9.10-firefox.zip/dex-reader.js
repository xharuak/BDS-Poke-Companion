// Read the game's rendered Pokédex only. No network, credentials or React state.
(() => {
  const number = (s) => {
    const m = String(s ?? '').match(/[\d][\d., ]*/);
    return m ? Number(m[0].replace(/\D/g, '')) : null;
  };
  const progress = (s) => {
    const m = String(s ?? '').match(/([\d.,]+)\s*\/\s*([\d.,]+)/);
    return m ? { kills: number(m[1]), threshold: number(m[2]) } : {};
  };
  globalThis.__bdsReadDex = (doc) => {
    const win = doc.querySelector('.dex-window');
    if (
      !win ||
      win.getClientRects().length === 0 ||
      getComputedStyle(win).visibility === 'hidden'
    )
      return null;
    const cells = [...win.querySelectorAll('.dex-cell')];
    const rows = cells
      .map((cell) => {
        const p = progress(cell.querySelector('.dex-badge-lock')?.title);
        return {
          id: number(cell.querySelector('.dex-cell-no')?.textContent),
          caught: cell.classList.contains('caught'),
          complete: !cell.classList.contains('locked'),
          kills: p.kills ?? null,
          threshold: p.threshold ?? null,
          atLeast: false,
        };
      })
      .filter((r) => r.id > 0);
    // Before the asynchronous game response the grid contains placeholder zeros.
    // A positive indicator in the account totals or rows proves real data arrived.
    const totals = [...win.querySelectorAll('.dex-strip .stk-stat b')].map(
      (e) => number(e.childNodes[0]?.textContent),
    );
    const ready =
      totals[0] > 0 ||
      totals[3] > 0 ||
      rows.some((r) => r.caught || r.complete || r.kills > 0);
    const thresholds = [
      ...new Set(rows.map((r) => r.threshold).filter(Boolean)),
    ];
    if (thresholds.length === 1)
      for (const row of rows)
        if (row.complete) {
          row.threshold = thresholds[0];
          row.kills = thresholds[0];
          row.atLeast = true;
        }
    const detail = win.querySelector('.dex-detail');
    if (detail) {
      const p = progress(
          detail.querySelector('.dex-unlock-kills')?.textContent,
        ),
        id = number(detail.querySelector('.dex-detail-no')?.textContent);
      const caught = detail.querySelector('.dex-caught-tag.yes') !== null;
      if (id && p.threshold && p.kills != null)
        rows.push({
          id,
          caught,
          complete: p.kills >= p.threshold,
          kills: p.kills,
          threshold: p.threshold,
          atLeast: p.kills >= p.threshold,
        });
    }
    return {
      rows,
      ready: ready || rows.some((r) => r.caught || r.complete || r.kills > 0),
    };
  };
})();
