import { renderHTML } from './render-html.js';
import {
  setupAccessRegions,
  getAccessibleRegions,
  acquisitionSummary,
} from './access-view.js';
import { sprite } from './sprites.js';
import { rankMeta, META_GOALS } from './meta.js';
import { TYPES, REGIONS, pokemonTypes } from './battle.js';
const $ = (id) => document.getElementById(id),
  esc = (x) =>
    String(x ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c],
    );
const fmt = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const axisNames = { farm: 'Upar', damage: 'Dano', bulk: 'Resistência' };
export function setupMeta(catalog, chart, evidence) {
  renderHTML(
    $('meta-type'),
    '<option value="">Todos os tipos</option>' +
      Object.entries(TYPES)
        .map(([v, n]) => `<option value="${v}">${n}</option>`)
        .join(''),
  );
  $('meta-type').value = 'ICE';
  renderHTML(
    $('meta-goal'),
    Object.entries(META_GOALS)
      .map(([v, g]) => `<option value="${v}">${g.label}</option>`)
      .join(''),
  );
  function huntRange() {
    const access = getAccessibleRegions(),
      levels = catalog.hunts
        .filter(
          (h) =>
            access.includes(h.region) &&
            (!$('meta-region').value || h.region === $('meta-region').value),
        )
        .map((h) => h.level);
    $('meta-min').value = levels.length ? Math.min(...levels) : 1;
    $('meta-max').value = levels.length ? Math.max(...levels) : 1;
  }
  function huntRegions() {
    const access = getAccessibleRegions(),
      previous = $('meta-region').value;
    renderHTML(
      $('meta-region'),
      access
        .map((v) => `<option value="${v}">${REGIONS[v]}</option>`)
        .join('') + '<option value="">Todos os mapas acessíveis</option>',
    );
    $('meta-region').value =
      previous && access.includes(previous) ? previous : access[0] || '';
    huntRange();
  }
  huntRegions();
  renderHTML(
    $('meta-sources'),
    evidence.sources
      .map(
        (s) =>
          `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.label)} ↗</a>`,
      )
      .join(' · '),
  );
  $('meta-date').textContent = evidence.checkedAt
    .split('-')
    .reverse()
    .join('/');
  let timer;
  function render() {
    const effect = $('meta-effect').value,
      level = Number($('meta-level').value),
      unconfirmed = $('meta-candidates').checked;
    $('meta-status').hidden = !effect;
    $('meta-status-label').textContent =
      effect === 'BURN' ? 'Burn / Queimadura' : 'Poison / Veneno';
    const result = rankMeta({
      creatures: catalog.creatures,
      hunts: catalog.hunts,
      chart,
      evidence,
      type: $('meta-type').value,
      effect,
      includeCandidates: unconfirmed,
      level,
      region: $('meta-region').value,
      minHunt: Number($('meta-min').value),
      maxHunt: Number($('meta-max').value),
      goal: $('meta-goal').value,
      accessibleRegions: getAccessibleRegions(),
    });
    const prefix =
      effect && unconfirmed ? 'Candidatos para investigar' : 'Recomendações';
    $('meta-summary').textContent =
      result.error ||
      `${prefix}: ${result.rows.length} de ${result.total} espécies comparáveis · ${result.targetCount} hunts · Pokémon no Nv. ${fmt(level)}${result.skipped ? ' · ' + result.skipped + ' espécies sem dados suficientes para este nível' : ''}.`;
    renderHTML(
      $('meta-results'),
      result.rows
        .map((r, i) => {
          const strongest =
              META_GOALS[result.goal].axis ||
              Object.keys(axisNames).sort((a, b) => r.axes[b] - r.axes[a])[0],
            main = r.opportunities[0];
          const warnings = Object.entries(TYPES)
            .filter(
              ([t]) =>
                chart[t] &&
                pokemonTypes(r.c).reduce((n, k) => n * (chart[t][k] ?? 1), 1) >
                  1,
            )
            .map(([, label]) => label);
          return `<article class="meta-card" data-meta-id="${r.c.pokeId}"><div class="meta-card-head"><span class="meta-rank">${i + 1}</span>${sprite(r.c)}<div><button class="meta-name" data-species="${r.c.pokeId}" data-level="${level}">${esc(r.c.name)}</button><small>#${r.c.pokeId} · ${pokemonTypes(
            r.c,
          )
            .map((t) => TYPES[t])
            .join(
              ' / ',
            )}${r.c.rarity === 'LEGENDARY' ? ' · Lendário (obtenção a confirmar)' : ''}</small></div><div class="meta-score"><b>${fmt(r.score, 1)}</b><small>maior ataque base</small></div></div>
    <div class="meta-axes">${Object.entries(axisNames)
      .map(
        ([k, n]) =>
          `<span>${n}<b>${fmt(r.axes[k], 0)}</b><progress max="100" value="${r.axes[k]}" aria-label="${n}: ${fmt(r.axes[k])} de 100"></progress></span>`,
      )
      .join('')}</div>
    <p class="meta-reason">Análise em destaque: ${axisNames[strongest].toLowerCase()}. Tem golpe favorável em ${r.coverage} de ${r.targetCount} hunts avaliadas.</p>
    ${main ? `<div class="meta-hunt"><small>MELHOR OPORTUNIDADE ESTIMADA</small><b>${esc(main.name)} <span>· ${REGIONS[main.region]} · hunt Nv. ${fmt(main.level)}</span></b><span>${esc(main.limiting.sustained.move.name)} · ${TYPES[main.limiting.sustained.move.type]} · ${fmt(main.limiting.sustained.multiplier, 2)}× · recarga ${fmt(main.limiting.sustained.move.cooldownMs / 1000, 1)}s</span><small>${fmt(main.limiting.target.experience)} XP base por abate${main.targets.length > 1 ? ' · resultado conservador do grupo' : ''} · golpe liberado no Nv. ${main.limiting.sustained.move.learnLevel}</small></div>` : '<p class="hint">Sem recarga ou XP suficiente para estimar oportunidades de up.</p>'}
    <p class="capture-location">Obtenção: ${esc(acquisitionSummary(r.acquisitionRoutes))}</p><div class="meta-statline"><span>Poder de referência <b>${fmt(r.power)}</b></span><span>Velocidade <b>${fmt(r.stats.vel)}</b></span><span>${r.moves.length} golpes liberados</span></div>
    ${effect ? `<div class="meta-effect-note ${r.status.verified.length ? 'verified' : ''}"><b>${r.status.verified.length ? 'Aplicação documentada' : 'Aplicação NÃO confirmada'}</b><span>${esc((r.status.verified.length ? r.status.verified.map((x) => x.move) : r.status.candidates).map((m) => m.name + ' (Nv. ' + m.learnLevel + ')').join(' · '))}</span><small>${r.status.verified.length ? 'Efeito sem bônus inventado no índice.' : 'São golpes de ' + (effect === 'BURN' ? 'Fogo' : 'Veneno') + ' para investigar. A tipagem não comprova o status.'}</small></div>` : ''}
    <details class="meta-detail"><summary>Por que entrou na lista?</summary><p>Ordem por maior ataque base <b>${r.offense[0]}</b>. Desempates, nesta ordem: Defesa ${r.offense[1]}, Def. Especial ${r.offense[2]}, HP ${r.offense[3]}, outro ataque ${r.offense[4]}. A análise escolhida não troca essa prioridade.</p><p>Fraquezas de tipo: ${warnings.join(', ') || 'nenhuma registrada'}. Isso não representa imunidade ou resistência a Poison/Burn.</p><div class="meta-moves">${r.moves.map((m) => `<span>${esc(m.name)} <small>· Nv. ${m.learnLevel} · poder ${m.power} · ${fmt(m.cooldownMs / 1000, 1)}s</small></span>`).join('')}</div>${r.missingCooldown ? '<p>Golpes sem recarga não entram no índice de up.</p>' : ''}<p>Outras oportunidades: ${
      r.opportunities
        .slice(1)
        .map((h) => esc(h.name) + ' (Nv. ' + fmt(h.level) + ')')
        .join(' · ') || 'nenhuma na faixa selecionada'
    }.</p></details>
    <div class="meta-actions"><button data-species="${r.c.pokeId}" data-level="${level}" data-tab="battle">Batalha e golpes</button><button data-species="${r.c.pokeId}" data-level="${level}" data-tab="progress">Ver progressão</button></div></article>`;
        })
        .join('') ||
        `<div class="empty">${result.error ? esc(result.error) : effect && !unconfirmed ? 'Nenhum aplicador de ' + (effect === 'BURN' ? 'Burn' : 'Poison') + ' confirmado nas fontes verificadas. Ative “Ver candidatos por golpes” acima para investigar, sem atribuir um efeito que os dados não confirmam.' : 'Nenhuma espécie elegível com estes filtros. Tente outro tipo, nível ou efeito.'}</div>`,
    );
  }
  for (const id of [
    'meta-type',
    'meta-effect',
    'meta-level',
    'meta-goal',
    'meta-min',
    'meta-max',
    'meta-candidates',
  ])
    $(id).addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(render, 120);
    });
  $('meta-region').addEventListener('change', () => {
    huntRange();
    render();
  });
  setupAccessRegions('meta-access', () => {
    huntRegions();
    render();
  });
  return render;
}
