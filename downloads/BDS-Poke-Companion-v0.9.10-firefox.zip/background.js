import { ACCESS_CONFIG } from './access-config.js';
import { createAccessClient } from './access-client.js';
import {
  parseTooltip,
  findSpecies,
  estimateObserved,
  baseStats,
  addProfile,
} from './core.js';
import { cleanDexRows } from './dex.js';
import { installLiveBridge } from './live-bridge.js';
import {
  updateDexEvent,
  nativeDexSnapshot,
  rememberDexEvent,
} from './live-progress.js';
import { huntEvent, resetHunt } from './hunt.js';
import { cleanGymSnapshot, mergeGymLeaders } from './gym-leaders.js';
import { cleanTeamSnapshot } from './gym-simulation.js';
import {
  notificationSettings,
  inventoryUpdate,
  notificationsFor,
} from './notifications.js';
const api = globalThis.browser ?? chrome;
const access = createAccessClient({
  config: ACCESS_CONFIG,
  storage: api.storage.session,
});
const isAccess = (s) =>
  s.url?.split(/[?#]/)[0] === api.runtime.getURL('access.html');
async function stopReaders() {
  const { bindings = {} } = await api.storage.session.get('bindings');
  for (const id of Object.keys(bindings))
    await api.tabs
      .sendMessage(Number(id), { type: 'reader-stop' })
      .catch(() => {});
  await api.storage.session.set({
    bindings: {},
    liveStreams: {},
    huntStates: {},
    latest: {},
    dexProgress: {},
    selections: {},
  });
}
async function requireLicense() {
  const state = await access.status();
  if (!state.allowed) {
    await stopReaders();
    throw Error(
      state.message ||
        'Entre na conta BDS e confira sua liberação pelo botão da extensão.',
    );
  }
  return state;
}
const GAME = 'https://poke.idleworld.online';
const isGame = (url) => {
  try {
    const u = new URL(url);
    return u.origin === GAME && u.pathname === '/play';
  } catch {
    return false;
  }
};
if (api.sidePanel)
  api.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: false })
    .catch(() => {});

// Serializes association writes and received tooltip writes across tabs.
let queue = Promise.resolve();
const isPanel = (s) =>
  s.url?.split(/[?#]/)[0] === api.runtime.getURL('panel.html');
const isAnalyzer = (s) =>
  s.url?.split(/[?#]/)[0] === api.runtime.getURL('analyzer.html');
const isCompanion = (s) =>
  s.url?.split(/[?#]/)[0] === api.runtime.getURL('companion.html');
const isPopup = (s) =>
  s.url?.split(/[?#]/)[0] === api.runtime.getURL('launcher.html');
let catalogPromise;
const liveCatalog = () =>
  (catalogPromise ??= fetch(api.runtime.getURL('data/hunts.json')).then((r) =>
    r.json(),
  ));
async function inject(details) {
  const results = await api.scripting.executeScript(details);
  const failure = results?.find((r) => r.error);
  if (failure) throw Error(failure.error.message || String(failure.error));
  return results;
}
async function startLive(tabId, profileId) {
  const { liveStreams = {}, huntStates = {} } = await api.storage.session.get([
    'liveStreams',
    'huntStates',
  ]);
  const channel = crypto.randomUUID();
  liveStreams[profileId] = { channel, seq: 0, recent: [], tabId };
  delete huntStates[profileId];
  await api.storage.session.set({ liveStreams, huntStates });
  const { notificationPreferences = {} } = await api.storage.local.get(
    'notificationPreferences',
  );
  await api.tabs.sendMessage(
    tabId,
    {
      type: 'reader-start',
      profileId,
      liveChannel: channel,
      notifications: notificationSettings(notificationPreferences[profileId]),
    },
    { frameId: 0 },
  );
  try {
    await inject({
      target: { tabId },
      world: 'MAIN',
      func: installLiveBridge,
      args: [channel],
    });
  } catch (error) {
    liveStreams[profileId].error = error.message;
    await api.storage.session.set({ liveStreams });
  }
}
async function clearLive(profileId) {
  const { liveStreams = {}, huntStates = {} } = await api.storage.session.get([
    'liveStreams',
    'huntStates',
  ]);
  delete liveStreams[profileId];
  delete huntStates[profileId];
  await api.storage.session.set({ liveStreams, huntStates });
}
async function receiveLive(m, sender) {
  const profileId = await bound(sender);
  if (!profileId) throw Error('Leitor não vinculado.');
  const {
    liveStreams = {},
    dexProgress = {},
    huntStates = {},
  } = await api.storage.session.get([
    'liveStreams',
    'dexProgress',
    'huntStates',
  ]);
  const stream = liveStreams[profileId];
  if (
    !stream ||
    stream.channel !== m.channel ||
    stream.tabId !== sender.tab.id ||
    !Number.isSafeInteger(m.seq) ||
    m.seq <= stream.seq
  )
    return;
  if (
    ![
      'link',
      'context',
      'kill',
      'capture',
      'dex-snapshot',
      'heartbeat',
      'hunt-penalty',
      'hunt-combat',
      'hunt-party',
      'hunt-gear',
      'hunt-environment',
      'hunt-native',
      'gym-snapshot',
      'team-snapshot',
      'inventory',
      'capture-iv',
      'capture-ready',
    ].includes(m.kind) ||
    !m.payload ||
    JSON.stringify(m.payload).length > 200000
  )
    return;
  if (!Number.isFinite(m.at) || Math.abs(Date.now() - m.at) > 60000) return;
  if (
    m.kind === 'context' &&
    typeof m.payload.huntSlug !== 'string' &&
    m.payload.huntSlug !== null
  )
    return;
  if (
    m.kind === 'context' &&
    m.payload.active &&
    (!Number.isInteger(m.payload.active.level) ||
      m.payload.active.level < 1 ||
      typeof m.payload.active.capId !== 'string')
  )
    return;
  if (
    m.kind === 'hunt-penalty' &&
    (!Number.isSafeInteger(m.payload.until) ||
      m.payload.until < 0 ||
      typeof m.payload.frozen !== 'boolean')
  )
    return;
  const { creatures } = await liveCatalog(),
    event = { seq: m.seq, at: m.at, kind: m.kind, payload: m.payload };
  const gap =
    (stream.lastSeen && m.at - stream.lastSeen > 15000) ||
    (m.kind === 'link' &&
      stream.online &&
      (!m.payload.connected || !m.payload.online));
  if (gap && dexProgress[profileId]) {
    const p = dexProgress[profileId];
    dexProgress[profileId] = {
      ...p,
      gap: true,
      rows: Object.fromEntries(
        Object.entries(p.rows).map(([id, r]) => [
          id,
          { ...r, atLeast: r.kills !== null || r.atLeast },
        ]),
      ),
    };
  }
  stream.seq = m.seq;
  stream.lastSeen = m.at;
  if (['off', 'ready', 'blocked'].includes(m.audioState))
    stream.audioState = m.audioState;
  if (m.kind === 'inventory')
    stream.inventory = inventoryUpdate(stream.inventory, m.payload);
  if (m.kind === 'team-snapshot')
    stream.team = cleanTeamSnapshot(m.payload, m.at);
  if (m.kind === 'capture-ready')
    stream.captureReady = m.payload.ready === true;
  let alerts = [];
  if (m.kind === 'kill' || m.kind === 'capture-iv') {
    const { notificationPreferences = {} } = await api.storage.local.get(
      'notificationPreferences',
    );
    const seen = stream.notifiedCaptures || [];
    if (m.kind !== 'capture-iv' || !seen.includes(m.payload.id)) {
      alerts = notificationsFor(event, notificationPreferences[profileId]);
      if (m.kind === 'capture-iv' && typeof m.payload.id === 'string')
        stream.notifiedCaptures = [...seen, m.payload.id].slice(-4096);
    }
    if (alerts.length) stream.lastNotification = { ...alerts.at(-1), at: m.at };
  }
  if (m.kind === 'gym-snapshot') {
    const rows = cleanGymSnapshot(m.payload, m.at);
    if (rows.length) {
      const { gymLeaders } = await api.storage.local.get('gymLeaders');
      const next = mergeGymLeaders(gymLeaders, rows);
      if (next !== gymLeaders)
        await api.storage.local.set({ gymLeaders: next });
    }
  }
  if (m.kind === 'link') {
    stream.connected = m.payload.connected === true;
    stream.online = m.payload.online === true;
    if (!stream.connected || !stream.online) stream.team = null;
    stream.error =
      typeof m.payload.error === 'string'
        ? m.payload.error.slice(0, 160)
        : null;
  }
  if (m.kind === 'kill' || m.kind === 'capture') {
    stream.lastEventAt = m.at;
    stream.lastEventKind = m.kind;
    rememberDexEvent(stream, event);
    const updated = updateDexEvent(dexProgress[profileId], event, creatures);
    if (updated) dexProgress[profileId] = updated;
  }
  if (
    m.kind === 'dex-snapshot' &&
    m.payload.snapshotSeq >= (stream.clearSeq || 0)
  ) {
    const previous = dexProgress[profileId];
    const next = nativeDexSnapshot(
      m.payload,
      creatures,
      previous,
      sender.tab.id,
      stream.recent,
    );
    if (m.payload.snapshotSeq < (stream.recentFloorSeq || 0)) {
      next.gap = true;
      for (const row of Object.values(next.rows))
        if (row.kills !== null) row.atLeast = true;
    }
    // Lifetime progress cannot go backwards because an HTTP response arrived late.
    for (const [id, r] of Object.entries(next.rows)) {
      const p = previous?.rows?.[id];
      if (p) {
        r.kills = Math.max(r.kills ?? 0, p.kills ?? 0);
        r.caught ||= p.caught;
        r.complete ||= p.complete;
      }
    }
    dexProgress[profileId] = next;
    stream.recent = [];
  }
  huntStates[profileId] = huntEvent(huntStates[profileId], event, creatures);
  // Heartbeats maintain elapsed time without rewriting the entire Pokédex.
  const changed = { liveStreams, huntStates };
  if (gap || ['kill', 'capture', 'dex-snapshot'].includes(m.kind))
    changed.dexProgress = dexProgress;
  await api.storage.session.set(changed);
  return { inventory: stream.inventory || {}, alerts };
}
async function companionContext(sender) {
  const [
    { bindings = {}, dexProgress = {}, liveStreams = {}, huntStates = {} },
    { gymLeaders, notificationPreferences = {} },
  ] = await Promise.all([
    api.storage.session.get([
      'bindings',
      'dexProgress',
      'liveStreams',
      'huntStates',
    ]),
    api.storage.local.get(['gymLeaders', 'notificationPreferences']),
  ]);
  const profileId = bindings[sender.tab?.id] || null;
  const live = liveStreams[profileId];
  return {
    profileId,
    notifications: notificationSettings(notificationPreferences[profileId]),
    inventory: live?.inventory || {},
    team: live?.team || null,
    captureReady: live?.captureReady === true,
    audioState: live?.audioState || 'blocked',
    lastNotification: live?.lastNotification || null,
    progress: profileId ? dexProgress[profileId] || null : null,
    live: live
      ? {
          connected: live.connected,
          online: live.online,
          lastSeen: live.lastSeen,
          error: live.error,
          lastEventAt: live.lastEventAt,
          lastEventKind: live.lastEventKind,
        }
      : null,
    hunt: huntStates[profileId] || null,
    gymLeaders: gymLeaders || { records: {} },
  };
}
async function mergeProgress(profileId, tabId, rows) {
  const clean = cleanDexRows(rows);
  const { dexProgress = {} } = await api.storage.session.get('dexProgress');
  if (
    dexProgress[profileId]?.source === 'native' ||
    dexProgress[profileId]?.live
  )
    return { count: Object.keys(dexProgress[profileId].rows).length };
  const previous =
    dexProgress[profileId]?.tabId === tabId ? dexProgress[profileId].rows : {};
  for (const r of Object.values(clean)) {
    const p = previous?.[r.id];
    if (r.kills === null && p?.complete === r.complete && p?.kills != null) {
      r.kills = p.kills;
      r.threshold = p.threshold;
      r.atLeast = p.atLeast;
    }
  }
  dexProgress[profileId] = {
    tabId,
    rows: { ...previous, ...clean },
    revision: (dexProgress[profileId]?.revision || 0) + 1,
    updatedAt: new Date().toISOString(),
  };
  await api.storage.session.set({ dexProgress });
  return { count: Object.keys(clean).length };
}
async function bindTab(profileId, tabId) {
  await requireLicense();
  const { workspace } = await api.storage.local.get('workspace');
  if (!workspace?.profiles.some((p) => p.id === profileId))
    throw Error('Selecione uma ficha válida.');
  const tab = await api.tabs.get(tabId);
  if (!isGame(tab.url)) throw Error('Selecione uma aba do jogo em /play.');
  const {
    bindings = {},
    latest = {},
    dexProgress = {},
  } = await api.storage.session.get(['bindings', 'latest', 'dexProgress']);
  for (const [id, p] of Object.entries(bindings))
    if (p === profileId && Number(id) !== tab.id) {
      await api.tabs
        .sendMessage(Number(id), { type: 'reader-stop' })
        .catch(() => {});
      delete bindings[id];
    }
  if (bindings[tab.id]) {
    await api.tabs.sendMessage(tab.id, { type: 'reader-stop' }).catch(() => {});
    if (bindings[tab.id] !== profileId) {
      delete latest[bindings[tab.id]];
      delete dexProgress[bindings[tab.id]];
      await clearLive(bindings[tab.id]);
    }
  }
  delete latest[profileId];
  delete dexProgress[profileId];
  await inject({
    target: { tabId: tab.id },
    files: ['dex-reader.js', 'reader.js', 'notification-audio.js'],
  });
  bindings[tab.id] = profileId;
  await api.storage.session.set({ bindings, latest, dexProgress });
  await startLive(tab.id, profileId);
  return { active: true };
}
async function activateTab(tab, { expand = false } = {}) {
  await requireLicense();
  if (!isGame(tab.url)) throw Error('Abra a aba do Poke Idle World primeiro.');
  let {
    workspace,
    containers = {},
    profileContainers = {},
  } = await api.storage.local.get([
    'workspace',
    'containers',
    'profileContainers',
  ]);
  if (!workspace) {
    const profiles = addProfile([], 'Conta 1');
    workspace = {
      schema: 'bds-poke-v1',
      profiles,
      active: profiles[0].id,
      favorites: [],
    };
    await api.storage.local.set({ workspace });
  }
  const {
    bindings = {},
    latest = {},
    dexProgress = {},
  } = await api.storage.session.get(['bindings', 'latest', 'dexProgress']);
  // Closed or navigated-away tabs must not reserve all four slots indefinitely.
  for (const [id, p] of Object.entries(bindings)) {
    const old = await api.tabs.get(Number(id)).catch(() => null);
    if (
      !old ||
      !isGame(old.url) ||
      !workspace.profiles.some((x) => x.id === p)
    ) {
      delete bindings[id];
      delete latest[p];
      delete dexProgress[p];
      await clearLive(p);
    }
  }
  await api.storage.session.set({ bindings, latest, dexProgress });
  const used = new Set(
    Object.entries(bindings)
      .filter(([id]) => Number(id) !== tab.id)
      .map(([, p]) => p),
  );
  const isolated =
    tab.cookieStoreId &&
    tab.cookieStoreId !== 'firefox-default' &&
    tab.cookieStoreId !== 'firefox-private';
  const slot = isolated
    ? Object.keys(containers).find((k) => containers[k] === tab.cookieStoreId)
    : null;
  const preferred = isolated
    ? profileContainers[tab.cookieStoreId] ||
      workspace.profiles[Number(slot?.replace('slot-', ''))]?.id
    : null;
  let p =
    workspace.profiles.find((p) => p.id === bindings[tab.id]) ||
    workspace.profiles.find((p) => p.id === preferred && !used.has(p.id)) ||
    workspace.profiles.find((p) => !used.has(p.id));
  if (!p) {
    workspace.profiles = addProfile(
      workspace.profiles,
      'Conta ' + (workspace.profiles.length + 1),
    );
    p = workspace.profiles.at(-1);
    await api.storage.local.set({ workspace });
  }
  if (isolated) {
    profileContainers[tab.cookieStoreId] = p.id;
    await api.storage.local.set({ profileContainers });
  }
  const status =
    bindings[tab.id] === p.id
      ? await api.tabs
          .sendMessage(tab.id, { type: 'reader-status' }, { frameId: 0 })
          .catch(() => null)
      : null;
  if (!status?.active || status.version !== '0.9.10')
    await bindTab(p.id, tab.id);
  else {
    const { liveStreams = {} } = await api.storage.session.get('liveStreams');
    if (
      !liveStreams[p.id]?.lastSeen ||
      Date.now() - liveStreams[p.id].lastSeen > 15000 ||
      liveStreams[p.id].error
    )
      await startLive(tab.id, p.id);
  }
  if (expand)
    await api.tabs.sendMessage(
      tab.id,
      { type: 'overlay-open' },
      { frameId: 0 },
    );
  return { tabId: tab.id, profileId: p.id, name: p.name, active: true };
}
async function activateOpenTabs() {
  const tabs = (await api.tabs.query({ url: GAME + '/play*' }))
    .filter((t) => isGame(t.url))
    .sort((a, b) => a.windowId - b.windowId || a.index - b.index);
  const results = [];
  for (const tab of tabs) {
    try {
      results.push(await activateTab(tab));
    } catch (error) {
      results.push({ tabId: tab.id, active: false, error: error.message });
    }
  }
  return { results, count: results.filter((r) => r.active).length };
}
async function bound(sender) {
  const { bindings = {} } = await api.storage.session.get('bindings');
  return sender.tab && sender.frameId === 0 && isGame(sender.url)
    ? bindings[sender.tab.id]
    : null;
}
async function storeSelection(record, profileId) {
  const key = crypto.randomUUID(),
    { selections = {} } = await api.storage.session.get('selections');
  const kept = Object.fromEntries(Object.entries(selections).slice(-19));
  kept[key] = { record: { ...record, id: crypto.randomUUID() }, profileId };
  await api.storage.session.set({ selections: kept });
  return key;
}
async function accountStatus(sender) {
  const { workspace } = await api.storage.local.get('workspace');
  const { bindings = {}, latest = {} } = await api.storage.session.get([
    'bindings',
    'latest',
  ]);
  const profiles = await Promise.all(
    (workspace?.profiles || []).slice(0, 4).map(async (p) => {
      const tabId = Number(
        Object.keys(bindings).find((id) => bindings[id] === p.id),
      );
      const tab = tabId ? await api.tabs.get(tabId).catch(() => null) : null;
      return {
        id: p.id,
        name: p.name,
        tabId: tab && isGame(tab.url) ? tabId : null,
        current: tabId === sender.tab?.id,
        last: latest[p.id]
          ? {
              name: latest[p.id].name,
              level: latest[p.id].level,
              total: latest[p.id].total,
            }
          : null,
      };
    }),
  );
  return profiles;
}
async function dispatch(m, sender) {
  if (sender.id !== api.runtime.id) throw new Error('Origem inválida.');
  if (!m || typeof m.type !== 'string') throw new Error('Mensagem inválida.');
  if (m.type.startsWith('access-')) {
    if (
      m.type === 'access-status' &&
      (isAccess(sender) ||
        isPanel(sender) ||
        isCompanion(sender) ||
        isAnalyzer(sender) ||
        isPopup(sender))
    )
      return access.status(isAccess(sender) && m.force === true);
    if (!isAccess(sender))
      throw Error('Abra Minha conta BDS para gerenciar o acesso.');
    if (m.type === 'access-signin') return access.signIn(m.email, m.password);
    if (m.type === 'access-signup')
      return access.signUp(m.email, m.password, m.name);
    if (m.type === 'access-resend') return access.resend();
    if (m.type === 'access-reset') return access.reset(m.email);
    if (m.type === 'access-logout') {
      await stopReaders();
      return access.logout();
    }
    if (m.type === 'access-claim') return access.claimOwner();
    if (m.type === 'access-users') return access.list(m.pageToken);
    if (m.type === 'access-manage')
      return access.manage(m.uid, m.status, m.days);
    throw Error('Operação de acesso inválida.');
  }
  await requireLicense();
  if (m.type === 'live-event') return receiveLive(m, sender);
  if (m.type === 'notification-save' || m.type === 'notification-test') {
    if (!isCompanion(sender)) throw Error('Comando restrito às pesquisas.');
    const c = await companionContext(sender);
    if (!c.profileId)
      throw Error('Abra Notificações pelo menu BDS na aba do jogo.');
    const { notificationPreferences = {} } = await api.storage.local.get(
      'notificationPreferences',
    );
    if (m.type === 'notification-save') {
      if (
        !m.settings ||
        !Number.isInteger(m.settings.minIV) ||
        m.settings.minIV < 0 ||
        m.settings.minIV > 192
      )
        throw Error('Informe um IV inteiro entre 0 e 192.');
      const settings = notificationSettings(m.settings);
      notificationPreferences[c.profileId] = settings;
      await api.storage.local.set({ notificationPreferences });
      await api.tabs.sendMessage(
        sender.tab.id,
        { type: 'notification-configure', settings },
        { frameId: 0 },
      );
      return settings;
    }
    if (!['capture', 'bronze', 'pheromone'].includes(m.kind))
      throw Error('Som inválido.');
    return api.tabs.sendMessage(
      sender.tab.id,
      {
        type: 'notification-test',
        kind: m.kind,
        settings: notificationSettings(notificationPreferences[c.profileId]),
      },
      { frameId: 0 },
    );
  }
  if (m.type === 'hunt-reset') {
    if (!isCompanion(sender)) throw Error('Comando restrito às pesquisas.');
    const c = await companionContext(sender);
    if (!c.profileId) throw Error('Abra pelo jogo.');
    const { huntStates = {} } = await api.storage.session.get('huntStates');
    const { creatures } = await liveCatalog();
    huntStates[c.profileId] = resetHunt(
      huntStates[c.profileId],
      Date.now(),
      creatures,
    );
    await api.storage.session.set({ huntStates });
    return;
  }
  if (m.type === 'launch-all') {
    if (!isPopup(sender)) throw Error('Abra pelo botão da extensão.');
    if (!(await api.permissions.contains({ origins: [GAME + '/*'] })))
      throw Error('Autorize o acesso ao site do jogo pelo botão da extensão.');
    await api.storage.local.set({ autoActivate: true });
    return activateOpenTabs();
  }
  if (m.type === 'launch') {
    if (!isPopup(sender)) throw Error('Abra pelo botão da extensão.');
    const tab = await api.tabs.get(m.tabId);
    if (!isGame(tab.url))
      throw Error('Abra a aba do Poke Idle World primeiro.');
    return activateTab(tab, { expand: true });
  }
  if (
    m.type === 'companion-context' ||
    m.type === 'dex-scan' ||
    m.type === 'dex-clear'
  ) {
    if (!isCompanion(sender)) throw Error('Comando restrito às pesquisas.');
    const context = await companionContext(sender);
    if (m.type === 'companion-context') return context;
    if (!context.profileId)
      throw Error('Abra as pesquisas pelo botão BDS na aba do jogo.');
    if (m.type === 'dex-clear') {
      const { dexProgress = {}, liveStreams = {} } =
        await api.storage.session.get(['dexProgress', 'liveStreams']);
      delete dexProgress[context.profileId];
      if (liveStreams[context.profileId]) {
        liveStreams[context.profileId].clearSeq =
          liveStreams[context.profileId].seq + 1;
        liveStreams[context.profileId].recent = [];
      }
      await api.storage.session.set({ dexProgress, liveStreams });
      await api.tabs
        .sendMessage(sender.tab.id, { type: 'reset-progress' })
        .catch(() => {});
      return;
    }
    if (
      context.progress?.source === 'native' &&
      !context.progress.gap &&
      context.live?.online
    )
      return {
        message:
          'Pokédex sincronizada. Abates e capturas continuam atualizando ao vivo.',
      };
    const snapshot = await api.tabs.sendMessage(sender.tab.id, {
      type: 'read-progress',
    });
    if (!snapshot?.ready)
      throw Error(
        'Abra a Pokédex do jogo e aguarde os dados. Uma lista ainda zerada não confirma o carregamento.',
      );
    const result = await mergeProgress(
      context.profileId,
      sender.tab.id,
      snapshot.rows,
    );
    return { message: `${result.count} registros lidos da Pokédex aberta.` };
  }
  if (m.type === 'dex-visible') {
    const profileId = await bound(sender);
    if (!profileId) throw Error('Leitor não vinculado.');
    return mergeProgress(profileId, sender.tab.id, m.rows);
  }
  if (m.type === 'accounts-status' || m.type === 'focus-account') {
    if (!isPanel(sender) && !(await bound(sender)))
      throw new Error('Vincule esta aba pelo painel.');
    const profiles = await accountStatus(sender);
    if (m.type === 'accounts-status') return profiles;
    const p = profiles.find((p) => p.id === m.profileId);
    if (!p?.tabId)
      throw new Error('Vincule uma aba do jogo a esta conta em Minhas contas.');
    const tab = await api.tabs.update(p.tabId, { active: true });
    if (Number.isInteger(tab?.windowId))
      await api.windows.update(tab.windowId, { focused: true });
    const change = async () => {
      const { workspace } = await api.storage.local.get('workspace');
      if (workspace?.profiles.some((x) => x.id === p.id)) {
        workspace.active = p.id;
        await api.storage.local.set({ workspace });
      }
    };
    if (globalThis.navigator?.locks)
      await navigator.locks.request('bds-workspace', change);
    else await change();
    return { profileId: p.id, tabId: p.tabId };
  }
  if (m.type === 'analyze-visible') {
    const profileId = await bound(sender);
    if (!profileId) throw new Error('Leitor não vinculado.');
    const record = parseTooltip(m.text);
    if (!record) throw new Error('Tooltip incompleto.');
    return { key: await storeSelection(record, profileId) };
  }
  if (m.type === 'selection-create') {
    if (!isPanel(sender) && !isCompanion(sender))
      throw new Error('Comando restrito ao painel.');
    if (isCompanion(sender)) {
      const c = await companionContext(sender);
      if (!c.profileId) throw Error('Abra a pesquisa na aba vinculada.');
      m = { ...m, profileId: c.profileId };
    }
    const { workspace } = await api.storage.local.get('workspace');
    if (!workspace?.profiles.some((p) => p.id === m.profileId))
      throw new Error('Conta inválida.');
    return { key: await storeSelection(m.record, m.profileId) };
  }
  if (m.type === 'selection-get' || m.type === 'selection-save') {
    if (!isAnalyzer(sender)) throw new Error('Comando restrito ao analisador.');
    const { selections = {} } = await api.storage.session.get('selections');
    const selection = selections[m.key];
    if (!selection)
      throw new Error('Esta leitura expirou. Selecione o Pokémon novamente.');
    const { workspace } = await api.storage.local.get('workspace');
    const p = workspace?.profiles.find((p) => p.id === selection.profileId);
    if (!p) throw new Error('A conta de origem não está mais disponível.');
    if (m.type === 'selection-get')
      return { ...selection, profileName: p.name };
    const { creatures } = await (
      await fetch(api.runtime.getURL('data/hunts.json'))
    ).json();
    const c = findSpecies(creatures, selection.record.name);
    if (
      !c ||
      /ditto/i.test(c.name) ||
      !estimateObserved(selection.record, baseStats(c)).valid
    )
      throw new Error(
        'A leitura não permite salvar IVs individuais. Confira no formulário manual.',
      );
    const record = { ...selection.record, speciesId: c.pokeId };
    // A read-modify-write through the same Web Lock as panel writes prevents a lost collection update.
    const save = async () => {
      const { workspace: w } = await api.storage.local.get('workspace');
      const target = w.profiles.find((p) => p.id === selection.profileId);
      if (!target) throw new Error('Conta removida.');
      target.records = [
        ...target.records.filter((r) => r.id !== record.id),
        record,
      ].slice(-100);
      await api.storage.local.set({ workspace: w });
    };
    if (globalThis.navigator?.locks)
      await navigator.locks.request('bds-workspace', save);
    else await save();
    return { saved: true };
  }
  if (m.type === 'tooltip') {
    if (!sender.tab || !isGame(sender.url) || sender.frameId !== 0) return;
    const { bindings = {} } = await api.storage.session.get('bindings');
    const profileId = bindings[sender.tab.id];
    if (!profileId) return;
    const data = parseTooltip(m.text);
    if (data) {
      const { latest = {} } = await api.storage.session.get('latest');
      latest[profileId] = { ...data, tabId: sender.tab.id, profileId };
      await api.storage.session.set({ latest });
    }
    return;
  }
  // Privileged commands only originate in our own panel, never a content script.
  if (!isPanel(sender)) throw new Error('Comando restrito ao painel.');
  if (m.type === 'bind') {
    return bindTab(m.profileId, m.tabId);
  }
  if (m.type === 'unbind') {
    const {
      bindings = {},
      latest = {},
      dexProgress = {},
    } = await api.storage.session.get(['bindings', 'latest', 'dexProgress']);
    for (const [id, p] of Object.entries(bindings))
      if (p === m.profileId) {
        await api.tabs
          .sendMessage(Number(id), { type: 'reader-stop' })
          .catch(() => {});
        delete bindings[id];
      }
    delete latest[m.profileId];
    delete dexProgress[m.profileId];
    await clearLive(m.profileId);
    await api.storage.session.set({ bindings, latest, dexProgress });
    return { active: false };
  }
  if (m.type === 'overlay-open') {
    const { bindings = {} } = await api.storage.session.get('bindings');
    const id = Number(
      Object.keys(bindings).find((id) => bindings[id] === m.profileId),
    );
    if (!id)
      throw new Error('Ative a leitura e vincule a aba do jogo primeiro.');
    await api.tabs.sendMessage(id, { type: 'overlay-open' });
    await api.tabs.update(id, { active: true });
    return;
  }
  if (m.type === 'container-open') {
    if (!api.contextualIdentities)
      throw new Error(
        'Contas isoladas estão disponíveis na edição Firefox. No Chrome/Edge, use perfis de navegador distintos ou seu cliente atual.',
      );
    const { workspace, containers = {} } = await api.storage.local.get([
      'workspace',
      'containers',
    ]);
    const p = workspace?.profiles.find((p) => p.id === m.profileId);
    if (!p || workspace.profiles.length > 4) throw new Error('Ficha inválida.');
    const slot = 'slot-' + workspace.profiles.findIndex((x) => x.id === p.id);
    let identity = containers[slot]
      ? await api.contextualIdentities.get(containers[slot]).catch(() => null)
      : null;
    if (!identity) {
      const colors = api.contextualIdentities.getSupportedColors
        ? await api.contextualIdentities.getSupportedColors()
        : ['blue', 'orange', 'green', 'purple'];
      identity = await api.contextualIdentities.create({
        name: `BDS · ${p.name}`,
        color:
          colors[
            workspace.profiles.findIndex((x) => x.id === p.id) % colors.length
          ],
        icon: 'circle',
      });
      containers[slot] = identity.cookieStoreId;
      await api.storage.local.set({ containers });
    }
    const existing = (
      await api.tabs.query({ cookieStoreId: identity.cookieStoreId })
    ).find((t) => isGame(t.url));
    if (existing) {
      await api.tabs.update(existing.id, { active: true });
      return;
    }
    await api.tabs.create({
      url: `${GAME}/play`,
      cookieStoreId: identity.cookieStoreId,
    });
  }
}
api.runtime.onMessage.addListener((m, sender, reply) => {
  queue = queue.catch(() => {}).then(() => dispatch(m, sender));
  queue.then(
    (data) => reply({ ok: true, data }),
    (error) => reply({ ok: false, error: error.message }),
  );
  return true;
});
api.tabs.onRemoved.addListener((id) => {
  queue = queue
    .catch(() => {})
    .then(async () => {
      const {
        bindings = {},
        latest = {},
        dexProgress = {},
      } = await api.storage.session.get(['bindings', 'latest', 'dexProgress']);
      const p = bindings[id];
      delete bindings[id];
      if (p) {
        delete latest[p];
        delete dexProgress[p];
        await clearLive(p);
      }
      await api.storage.session.set({ bindings, latest, dexProgress });
    });
});
// Restore only a tab the user explicitly bound in this browser session.
api.tabs.onUpdated?.addListener((id, change, tab) => {
  if (change.status !== 'complete') return;
  queue = queue
    .catch(() => {})
    .then(async () => {
      if (!(await access.status()).allowed) {
        await stopReaders();
        return;
      }
      const {
        bindings = {},
        latest = {},
        dexProgress = {},
      } = await api.storage.session.get(['bindings', 'latest', 'dexProgress']);
      if (!bindings[id]) {
        const { autoActivate } = await api.storage.local.get('autoActivate');
        if (autoActivate && isGame(tab.url))
          await activateTab(tab).catch(() => {});
        return;
      }
      if (!isGame(tab.url)) {
        await clearLive(bindings[id]);
        delete dexProgress[bindings[id]];
        delete latest[bindings[id]];
        delete bindings[id];
        await api.storage.session.set({ bindings, latest, dexProgress });
        return;
      }
      // Iframe navigation can also finish a tab load. Keep its existing session.
      const status = await api.tabs
        .sendMessage(id, { type: 'reader-status' }, { frameId: 0 })
        .catch(() => null);
      if (status?.active && status.version === '0.9.10') return;
      delete dexProgress[bindings[id]];
      await api.storage.session.set({ dexProgress });
      try {
        await inject({
          target: { tabId: id },
          files: ['dex-reader.js', 'reader.js', 'notification-audio.js'],
        });
        await startLive(id, bindings[id]);
      } catch {
        await clearLive(bindings[id]);
        delete latest[bindings[id]];
        delete bindings[id];
        await api.storage.session.set({ bindings, latest });
      }
    });
});
// Resume only after the user opted into activating their open game tabs.
queue = queue
  .catch(() => {})
  .then(async () => {
    const { autoActivate } = await api.storage.local.get('autoActivate');
    if (
      autoActivate &&
      (await api.permissions.contains({ origins: [GAME + '/*'] }))
    )
      await activateOpenTabs();
  })
  .catch(() => {});
