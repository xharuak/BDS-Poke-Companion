import { renderHTML } from './render-html.js';
import { evolutionFamily } from './evolution.js';
import { sprite } from './sprites.js';
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
export function renderEvolution(host, selected, creatures, data) {
  const f = evolutionFamily(selected, creatures, data),
    name = (id) => f.nodes.find((n) => n.id === id)?.name || `#${id}`;
  const before = f.before.map((e) => name(e.from)).join(' / '),
    after = f.after.map((e) => name(e.to)).join(' / ');
  const summary = f.id
    ? `${before ? 'Evolui de ' + before + '.' : 'Início da linhagem cadastrada.'} ${after ? 'Evolui para ' + after + '.' : f.known ? 'Não possui outra evolução nesta linhagem.' : 'Próxima evolução não informada.'}`
    : 'Não há uma linha evolutiva confirmada para esta forma no catálogo.';
  const label = (e) =>
    e.kind === 'game'
      ? 'Jogo' + (e.level ? ' · Nv. ' + e.level + ' no catálogo' : '')
      : e.kind === 'eevee'
        ? 'Eevee · pedras especiais'
        : 'Referência · requisito no jogo não confirmado';
  renderHTML(
    host,
    `<details class="lineage" open><summary><strong>Linha evolutiva</strong><span>${esc(summary)}</span></summary>${f.id !== selected.pokeId && f.base ? `<p class="muted">Linhagem da espécie capturável ${esc(f.base.name)}. Não confirma evolução direta da variante ${esc(selected.name)}.</p>` : ''}<div class="evolution-stages">${f.stages
      .map(
        (stage, i) =>
          `<div class="evolution-stage"><small>${i === 0 ? 'Origem' : 'Evolução ' + i}</small>${stage
            .map((n) => {
              const incoming = f.edges.filter((e) => e.to === n.id);
              const inner = `${n.catalog ? sprite(n.catalog) : '<span class="evolution-missing">?</span>'}<strong>${esc(n.name)}</strong>${n.id === f.id ? '<small>Selecionado</small>' : ''}${!n.catalog ? '<small>Fora do catálogo do jogo</small>' : ''}${incoming.map((e) => `<small>${esc(name(e.from))} →<br>${esc(label(e))}</small>`).join('')}`;
              return n.catalog
                ? `<a class="evolution-node ${n.id === f.id ? 'selected' : ''}" href="analyzer.html?embedded=1&species=${n.id}" aria-label="Analisar ${esc(n.name)}" ${n.id === f.id ? 'aria-current="true"' : ''}>${inner}</a>`
                : `<div class="evolution-node absent">${inner}</div>`;
            })
            .join('')}</div>`,
      )
      .join(
        '',
      )}</div><p class="lineage-note">Relações marcadas “Jogo” vêm da Pokepedia. “Referência” completa a genealogia, mas não confirma que a evolução esteja liberada aqui. Não altera os candidatos de Meta/Gym. Níveis são os exibidos no catálogo; confirme nível, pedras e demais requisitos no botão Evoluir do jogo.</p><div class="lineage-sources"><a href="https://poke.idleworld.online/pokepedia/systems/evolution" target="_blank" rel="noopener">Evolução no jogo ↗</a> · <a href="https://pokeapi.co/docs/v2#pokemon-species" target="_blank" rel="noopener">Genealogia PokéAPI ↗</a></div></details>`,
  );
}
