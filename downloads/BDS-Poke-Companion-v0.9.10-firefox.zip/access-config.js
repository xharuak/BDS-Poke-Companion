// Public Firebase Web configuration. Never put service-account or admin keys here.
// A missing configuration blocks access; it never enables an unrestricted mode.
export const ACCESS_CONFIG = Object.freeze({
  projectId: 'bds-poke',
  apiKey: 'AIzaSyDTouL7IBcYP2HQfddC_0HBtV5-QNDLS5E',
});
export const OWNER_EMAIL = 'fernando.petta@gmail.com';
