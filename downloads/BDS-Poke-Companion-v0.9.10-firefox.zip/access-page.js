import { renderHTML } from './render-html.js';
const api = globalThis.browser ?? chrome,
  $ = (id) => document.getElementById(id);
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
let current,
  mode = 'login',
  users = [],
  nextPage = null,
  working = false;
const labels = {
  pending: 'Aguardando aprovação',
  active: 'Liberado',
  expired: 'Expirado',
  blocked: 'Bloqueado',
};
async function send(action, data = {}) {
  const r = await api.runtime.sendMessage({
    type: 'access-' + action,
    ...data,
  });
  if (!r?.ok) throw Error(r?.error || 'A extensão não respondeu.');
  return r.data;
}
function notice(message) {
  $('access-message').textContent = message;
  $('access-message').hidden = !message;
}
async function action(fn) {
  if (working) return;
  working = true;
  document.querySelectorAll('button').forEach((b) => (b.disabled = true));
  try {
    await fn();
  } catch (e) {
    notice(e.message);
  } finally {
    working = false;
    document.querySelectorAll('button').forEach((b) => (b.disabled = false));
  }
}
function account() {
  $('administration').hidden = !current.owner || !current.allowed;
  if (current.phase === 'configuration') {
    renderHTML(
      $('account'),
      '<div class="access-card"><h1>Serviço em preparação</h1><p>O proprietário ainda precisa conectar o Firebase e publicar as regras de acesso. Esta edição não libera o uso sem essa configuração.</p><p>Consulte o arquivo <b>CONFIGURAR-ACESSO.txt</b> que acompanha a extensão.</p></div>',
    );
    return;
  }
  if (current.phase === 'signed-out') {
    const signup = mode === 'register',
      reset = mode === 'reset';
    renderHTML(
      $('account'),
      `<div class="access-card"><h1>${signup ? 'Criar conta BDS' : reset ? 'Recuperar senha' : 'Entrar no BDS'}</h1><p>${signup ? 'Confirme seu e-mail e aguarde a liberação do proprietário.' : reset ? 'Enviaremos as instruções para o e-mail informado.' : 'Use seu e-mail e a senha do BDS.'}</p><form id="credentials">${signup ? '<label>Nome<input name="displayName" maxlength="80" autocomplete="name" required></label>' : ''}<label>E-mail<input name="email" type="email" autocomplete="username" maxlength="254" required></label>${!reset ? `<label>Senha<input name="password" type="password" autocomplete="${signup ? 'new-password' : 'current-password'}" ${signup ? 'minlength="12"' : ''} maxlength="128" required></label>` : ''}${signup ? '<small>Pelo menos 12 caracteres. A confirmação será enviada pelo Firebase.</small>' : ''}<button class="access-primary" type="submit">${signup ? 'Criar conta e enviar confirmação' : reset ? 'Enviar recuperação' : 'Entrar'}</button></form><div class="access-actions">${mode !== 'login' ? '<button data-mode="login">Já tenho conta</button>' : ''}${!signup ? '<button data-mode="register">Criar conta</button>' : ''}${!reset ? '<button data-mode="reset">Esqueci minha senha</button>' : ''}</div></div>`,
    );
    $('credentials').onsubmit = (e) => {
      e.preventDefault();
      const data = new FormData(e.currentTarget),
        email = data.get('email'),
        password = data.get('password'),
        name = data.get('displayName');
      if (e.currentTarget.elements.password)
        e.currentTarget.elements.password.value = '';
      action(async () => {
        if (reset) {
          await send('reset', { email });
          notice(
            'Se houver uma conta com esse e-mail, você receberá as instruções. Confira também o spam.',
          );
          return;
        }
        current = await send(signup ? 'signup' : 'signin', {
          email,
          password,
          name,
        });
        notice(
          signup ? 'Conta criada. Abra o e-mail e confirme seu endereço.' : '',
        );
        account();
        if (current.owner) await loadUsers();
      });
    };
    return;
  }
  const title = current.owner
    ? 'Conta proprietária'
    : current.phase === 'unverified'
      ? 'Confirme seu e-mail'
      : current.phase === 'owner-setup'
        ? 'Ativar sua conta proprietária'
        : current.phase === 'unavailable'
          ? 'Não foi possível conferir o acesso'
          : current.phase === 'active'
            ? 'Acesso liberado'
            : labels[current.phase] || 'Minha conta';
  const descriptions = {
    unverified:
      'Abra o link recebido no seu e-mail. Depois clique em “Já confirmei / Atualizar”.',
    pending:
      'Seu cadastro está confirmado. Aguarde a liberação pelo proprietário.',
    blocked: 'Seu acesso foi bloqueado pelo proprietário.',
    expired:
      'O prazo do seu acesso terminou. Solicite uma renovação ao proprietário.',
    'owner-setup':
      'Este e-mail confirmado é o reservado para o proprietário. A ativação vincula a propriedade permanentemente à sua identidade no Firebase.',
    active: current.owner
      ? 'Você é o único proprietário. Usuários não podem alterar sua conta nem conceder permissões.'
      : 'Você já pode ativar a extensão nas contas do jogo.',
  };
  renderHTML(
    $('account'),
    `<div class="access-card"><span class="access-owner">${esc(current.email)}</span><h1>${title}</h1><p>${esc(current.message || descriptions[current.phase] || 'Tente novamente em instantes.')}</p>${current.expiresAt ? `<p>Validade: <b>${new Date(current.expiresAt).toLocaleString('pt-BR')}</b></p>` : ''}<div class="access-actions">${current.phase === 'unverified' ? '<button id="resend">Reenviar confirmação</button>' : ''}${current.phase === 'owner-setup' ? '<button id="claim" class="access-primary">Ativar conta proprietária</button>' : ''}<button id="check">${current.phase === 'unverified' ? 'Já confirmei / Atualizar' : 'Atualizar acesso'}</button>${current.allowed ? '<a href="launcher.html">Abrir extensão</a>' : ''}<button id="logout">Sair da conta BDS</button></div></div>`,
  );
  $('check').onclick = () => action(refresh);
  $('logout').onclick = () =>
    action(async () => {
      current = await send('logout');
      mode = 'login';
      users = [];
      notice('Você saiu da conta BDS neste navegador.');
      account();
    });
  if ($('resend'))
    $('resend').onclick = () =>
      action(async () => {
        await send('resend');
        notice('Confirmação enviada. Confira a caixa de entrada e o spam.');
      });
  if ($('claim'))
    $('claim').onclick = () =>
      action(async () => {
        current = await send('claim');
        notice('Conta proprietária ativada.');
        account();
        await loadUsers();
      });
}
async function refresh() {
  current = await send('status', { force: true });
  account();
  if (current.owner && current.allowed) await loadUsers();
}
function renderUsers() {
  const q = $('user-search').value.toLowerCase(),
    filter = $('user-status').value;
  const shown = users.filter((u) => {
    const status =
      u.status === 'active' &&
      u.expiresAt &&
      Date.parse(u.expiresAt) <= Date.now()
        ? 'expired'
        : u.status;
    return (
      (!q || (u.email + ' ' + u.name).toLowerCase().includes(q)) &&
      (!filter || status === filter)
    );
  });
  renderHTML(
    $('users'),
    shown
      .map((u) => {
        const phase =
          u.status === 'active' &&
          u.expiresAt &&
          Date.parse(u.expiresAt) <= Date.now()
            ? 'expired'
            : u.status;
        return `<article class="access-user" data-uid="${esc(u.uid)}"><strong>${esc(u.name)}</strong><span>${esc(u.email)}</span><small>${labels[phase] || 'Aguardando'} · ${u.expiresAt ? 'até ' + new Date(u.expiresAt).toLocaleString('pt-BR') : 'sem data de expiração'}</small><div class="access-actions"><select aria-label="Prazo de acesso para ${esc(u.email)}"><option value="30">30 dias a partir de hoje</option><option value="7">7 dias a partir de hoje</option><option value="90">90 dias a partir de hoje</option><option value="365">365 dias a partir de hoje</option><option value="0">Sem vencimento</option></select><button data-status="active" class="access-primary">Liberar / renovar</button><button data-status="blocked">Bloquear</button></div></article>`;
      })
      .join('') ||
      '<p>Nenhum usuário nesta página. Cadastros aparecem aqui depois da confirmação de e-mail.</p>',
  );
  $('more-users').hidden = !nextPage;
}
async function loadUsers(pageToken = '') {
  const r = await send('users', { pageToken });
  users = r.users;
  nextPage = r.nextPageToken;
  renderUsers();
}
$('reload-users').onclick = () => action(() => loadUsers());
$('more-users').onclick = () => action(() => loadUsers(nextPage));
for (const id of ['user-search', 'user-status']) $(id).oninput = renderUsers;
document.addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.mode) {
    mode = b.dataset.mode;
    notice('');
    account();
  }
  if (b.dataset.status) {
    const row = b.closest('[data-uid]');
    action(async () => {
      await send('manage', {
        uid: row.dataset.uid,
        status: b.dataset.status,
        days: Number(row.querySelector('select').value),
      });
      notice(
        b.dataset.status === 'blocked'
          ? 'Acesso bloqueado.'
          : 'Acesso liberado / renovado.',
      );
      await loadUsers();
    });
  }
});
refresh().catch((e) => notice(e.message));

