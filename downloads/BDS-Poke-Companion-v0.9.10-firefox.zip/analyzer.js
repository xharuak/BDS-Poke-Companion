import { renderHTML } from './render-html.js';
import { requireAccess } from './access-gate.js';
import { renderEvolution } from './evolution-view.js';
import { loadItemSprites, itemSprite } from './item-sprites.js';
import { loadSprites, sprite } from './sprites.js';
import {
  STATS,
  LABELS,
  baseStats,
  estimateObserved,
  findSpecies,
  qualityLabel,
} from './core.js';
import { referenceRecord } from './dex.js';
import {
  TYPES,
  REGIONS,
  multiplier,
  pokemonTypes,
  rankHunts,
  availableMoves,
} from './battle.js';
const api = globalThis.browser?.runtime?.id
  ? browser
  : globalThis.chrome?.runtime?.id
    ? chrome
    : null;
const $ = (id) => document.getElementById(id);
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
const fmt = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const span = (lo, hi, d = 0) =>
  lo === hi ? fmt(lo, d) : `${fmt(lo, d)}–${fmt(hi, d)}`;
const chips = (c) =>
  pokemonTypes(c)
    .map(
      (t) =>
        `<span class="chip" data-type="${esc(t)}">${esc(TYPES[t] || t)}</span>`,
    )
    .join('');
let reference = false,
  analysisLevel = 1,
  fixedReference = false;
let catalog,
  items,
  chart,
  selected,
  record,
  result,
  region = 'kanto',
  selectionKey,
  profileName = 'Consulta ao catálogo';
function toast(s) {
  $('toast').textContent = s;
  $('toast').hidden = false;
  setTimeout(() => ($('toast').hidden = true), 4500);
}
async function send(data) {
  const r = await api.runtime.sendMessage(data);
  if (!r?.ok) throw new Error(r?.error || 'A extensão não respondeu.');
  return r.data;
}
function quality() {
  const total = record?.total,
    valid = result?.valid;
  $('metrics').hidden = !record;
  renderHTML(
    $('metrics'),
    [
      [
        total ?? (valid ? span(result.total.min, result.total.max) : '—'),
        'IV total / 192',
        total
          ? `${fmt((total / 192) * 100, 1)}% · ${reference ? 'modelo de referência' : 'observado'}`
          : valid
            ? 'faixa calculada'
            : 'abra um exemplar',
      ],
      [
        record ? `×${fmt(record.quality, 4)}` : '—',
        'Qualidade',
        record ? qualityLabel(record.quality) : 'depende do exemplar',
      ],
      [
        fmt(record?.observedPower ?? (valid ? result.power : null)),
        'Poder',
        reference
          ? 'calculado para o modelo'
          : record?.observedPower
            ? 'observado no tooltip'
            : 'calculado no nível atual',
      ],
      [
        record ? fmt(record.level) : '—',
        'Nível',
        reference
          ? 'nível de referência'
          : record
            ? 'exemplar selecionado'
            : 'selecione abaixo para a hunt',
      ],
    ]
      .map(
        ([n, l, d]) =>
          `<div class="metric"><small>${l}</small><strong>${n}</strong><small>${esc(d)}</small></div>`,
      )
      .join(''),
  );
  renderHTML(
    $('quality'),
    !record
      ? '<div class="empty">Esta é uma espécie do catálogo. Para avaliar um exemplar, passe o mouse sobre ele no jogo e use Ctrl + clique, ou preencha o Analisador de IVs no painel.</div>'
      : `<h2>Potencial do exemplar</h2><div class="notice ${valid ? 'ok' : ''}">${valid ? (result.unique ? 'IVs individuais determinados pelo modelo, sob as hipóteses informadas.' : 'Os números arredondados permitem mais de uma distribuição. As barras mostram o menor IV possível.') : `IV total e qualidade observados permanecem visíveis. ${esc(result?.reason || 'Não foi possível estimar os IVs individuais.')}`}</div>${valid ? STATS.map((k) => `<div class="stat-row"><span>${LABELS[k]}</span><meter min="0" max="32" value="${result.ivs[k].min}" aria-label="${LABELS[k]}: ${result.ivs[k].values.join(', ')}"></meter><strong>${span(result.ivs[k].min, result.ivs[k].max)} /32</strong><small>stat ${fmt(record.current[k])}</small></div>`).join('') + `<div class="box"><h3>Comparação no mesmo nível</h3><p>Power no nível 100: <strong>${span(result.power100.min, result.power100.max, 1)}</strong>.</p><small>Faixa conservadora, mantendo qualidade e IVs. Não representa dano por segundo.</small></div><details><summary>Precisão e valores possíveis</summary><p>Qualidade compartilhada pelos seis atributos: ${span(...result.qualityRange, 5)}. O IV total restringe as combinações.</p>${STATS.map((k) => `<p>${LABELS[k]}: ${result.ivs[k].values.join(', ')}</p>`).join('')}</details>` : ''}<p class="muted">IV mede potencial dentro da espécie. Qualidade multiplica os atributos. Não somamos as duas escalas em uma nota artificial. Tipos e golpes determinam em qual hunt o Pokémon funciona melhor.</p>`,
  );
  if (reference)
    renderHTML(
      $('quality'),
      `<h2>Modelo de comparação</h2><div class="notice ok">Referência padronizada: nível 100, qualidade 1,000 e IV 16/32 em cada atributo. Estes valores são simulados para comparar espécies; não representam um Pokémon da sua conta.</div>${STATS.map((k) => `<div class="stat-row"><span>${LABELS[k]}</span><meter min="0" max="32" value="16"></meter><strong>16 /32</strong><small>base ${fmt(baseStats(selected)[k])} · ${fmt(record.current[k])}</small></div>`).join('')}<div class="box"><h3>Explore esta espécie</h3><p>Em Batalha, consulte fraquezas e todos os golpes. Em Progressão, ajuste o nível e encontre alvos por mapa e efetividade. Em Drops, veja os itens desta espécie.</p></div>`,
    );
  $('save').disabled = reference || !valid || !selectionKey || !api;
  if (reference) $('save').hidden = true;
}
function battle() {
  const level = analysisLevel;
  const defenses = Object.keys(chart).map((t) => ({
    t,
    m: multiplier(chart, t, pokemonTypes(selected)),
  }));
  const group = (title, predicate, css = '') =>
    `<div class="box ${css}"><h3>${title}</h3><p>${
      defenses
        .filter(predicate)
        .map(({ t, m }) => `${TYPES[t]} ${fmt(m, 2)}×`)
        .join(' · ') || 'Nenhuma'
    }</p></div>`;
  renderHTML(
    $('battle'),
    `<h2>Forças e fraquezas na hunt</h2><div class="two-col">${group('Fraqueza dupla · 5,5×', (x) => x.m >= 5.5, 'danger')}${group('Fraquezas · 2,5×', (x) => x.m > 1 && x.m < 5.5, 'danger')}${group('Resistências', (x) => x.m > 0 && x.m < 1, 'resist')}${group('Imunidades', (x) => x.m === 0)}</div><div class="box"><h3>Ataques do próprio tipo</h3>${pokemonTypes(
      selected,
    )
      .map(
        (t) =>
          `<p><strong>${TYPES[t]}:</strong> ${Object.keys(chart)
            .filter((d) => multiplier(chart, t, [d]) > 1)
            .map((d) => TYPES[d])
            .join(' · ')} <small>(2,5× contra cada tipo isolado)</small></p>`,
      )
      .join(
        '',
      )}</div><h2>Golpes da espécie</h2><label class="move-level-label">Nível para consultar golpes<input id="battle-level" type="number" min="1" max="100000" value="${level}"></label><p id="move-level-summary">Golpes liberados no nível ${fmt(level)}. TMs dependem do disco e ficam fora do ranking de hunts.</p><div class="move-grid">${(selected.attacks || []).map((a) => `<div class="move ${a.learnLevel > level ? 'locked' : ''}"><div><strong>${esc(a.name)}</strong><small>${a.category === 'SPECIAL' ? 'Especial' : a.category === 'STATUS' ? 'Status' : 'Físico'} · Poder ${fmt(a.power)} · Nv. ${fmt(a.learnLevel)}</small><span class="chip" data-type="${esc(a.type)}">${esc(TYPES[a.type])}</span></div><span class="chip">${a.tm ? 'TM · confirmar na fonte' : a.learnLevel > level ? 'Bloqueado · Nv. ' + fmt(a.learnLevel) : 'Liberado'}</span></div>`).join('')}</div><p class="muted">Valores de TM acima são o registro bruto do catálogo, não confirmação de poder efetivo ou de TM aprendida. <a target="_blank" rel="noopener" href="https://poke.idleworld.online/pokepedia/tms">Regras de TM ↗</a></p>`,
  );
  $('battle-level').addEventListener('change', () => {
    const value = Number($('battle-level').value);
    if (!Number.isInteger(value) || value < 1 || value > 100000) return;
    analysisLevel = value;
    battle();
    if ($('attack-level')) {
      $('attack-level').value = value;
      huntList();
    }
  });
}
function progress() {
  renderHTML(
    $('progress'),
    `<h2>${esc(selected.name)} atacando os alvos da hunt</h2><p>Escolha entre simular o aprendizado por etapa e comparar hunts com o nível atual do seu Pokémon. Só entram golpes já liberados no nível usado.</p><div class="toolbar"><label>Modo de progressão<select id="level-mode"><option value="stage" ${reference && !fixedReference ? 'selected' : ''}>Por etapa · aprender ao subir</option><option value="fixed" ${reference && !fixedReference ? '' : 'selected'}>Nível fixo · meu Pokémon agora</option></select></label><label>Nível do Pokémon (modo fixo)<input id="attack-level" type="number" min="1" max="100000" value="${analysisLevel}"></label><label>Nível da conta até<input id="account-level" type="number" min="1" placeholder="Mostrar todos"></label><label>Efetividade<select id="exact-mult"><option value="">Todas</option><option value="0">0× · imune</option><option value="0.1666666667">0,17× · dupla resistência</option><option value="0.3333333333">0,33× · resistido</option><option value="1">1× · normal</option><option value="2.5">2,5× · efetivo</option><option value="5.5">5,5× · super efetivo</option></select></label><label>Tipo do golpe<select id="attack-type"><option value="">Melhor golpe disponível</option>${[...new Set((selected.attacks || []).filter((a) => !a.tm && a.power > 0).map((a) => a.type))].map((t) => `<option value="${t}">${TYPES[t]}</option>`).join('')}</select></label><label>Buscar alvo<input id="target-search" type="search" placeholder="Nome da hunt"></label></div><div id="level-context" class="notice ok" role="status"></div><div class="regions">${Object.entries(
      REGIONS,
    )
      .map(
        ([key, name]) =>
          `<button data-region="${key}" class="${region === key ? 'active' : ''}">${name}</button>`,
      )
      .join(
        '',
      )}</div><div id="hunt-list"></div><details><summary>Como o ranking é calculado</summary><p>Índice relativo por golpe = poder × STAB × efetividade × atributo de ataque ÷ defesa base do alvo. Usa o ataque observado somente no nível original; nos demais níveis usa a base da espécie. Ordena dentro de cada nível pelo índice mínimo entre os alvos da hunt. STAB é 1,5× e os multiplicadores seguem a Pokepedia.</p><p>Este índice não é dano final, XP/h, capacidade de sobreviver ou garantia de acesso ao mapa. Não inclui cooldown, densidade, HP, IV/qualidade do selvagem, bônus, debuffs ou toda a rotação de ataques. Confirme o resultado com o Hunt Analyzer do jogo. TMs e golpes de poder 600 estão excluídos.</p></details>`,
  );
  for (const id of [
    'level-mode',
    'attack-level',
    'account-level',
    'exact-mult',
    'attack-type',
    'target-search',
  ])
    $(id).addEventListener('input', () => {
      if (id === 'attack-level') {
        const value = Number($('attack-level').value);
        if (Number.isInteger(value) && value > 0 && value <= 100000) {
          analysisLevel = value;
          battle();
        }
      }
      huntList();
    });
  huntList();
}
function huntList() {
  const mode = $('level-mode').value,
    level = Number($('attack-level').value);
  $('attack-level').disabled = mode === 'stage';
  if (
    mode === 'fixed' &&
    (!Number.isInteger(level) || level < 1 || level > 100000)
  ) {
    renderHTML($('hunt-list'), '<p>Informe um nível válido.</p>');
    return;
  }
  const unlocked = availableMoves(selected, level);
  $('level-context').textContent =
    mode === 'stage'
      ? `Por etapa: simulamos ${selected.name} no nível indicado em cada grupo de hunt. Os golpes são liberados conforme esse nível; isso não indica o nível real do seu exemplar.`
      : `Nível fixo: ${selected.name} no Nv. ${fmt(level)} em todas as hunts. Golpes disponíveis: ${unlocked.map((a) => a.name).join(', ') || 'nenhum com dano'}. O nível da hunt não altera o nível do Pokémon.`;
  const rows = rankHunts({
    chart,
    attacker: selected,
    creatures: catalog.creatures,
    hunts: catalog.hunts,
    level,
    levelMode: mode,
    currentLevel: record?.level,
    current: record?.current,
    region,
    maxLevel: Number($('account-level').value) || 0,
    exactMultiplier:
      $('exact-mult').value === '' ? null : Number($('exact-mult').value),
    attackType: $('attack-type').value,
    query: $('target-search').value.trim(),
  });
  const groups = new Map();
  for (const r of rows) {
    if (!groups.has(r.level)) groups.set(r.level, []);
    groups.get(r.level).push(r);
  }
  renderHTML(
    $('hunt-list'),
    (region === 'catalog'
      ? '<div class="notice">Espécies sem marcador de hunt confirmado. O nível abaixo é do catálogo, não uma localização verificada.</div>'
      : '') +
      `<p class="source-tag">${rows.length} hunts · região ${REGIONS[region]} · ${region === 'catalog' ? 'local não confirmado' : 'dados oficiais de mapas'} · até 6 destaques por nível</p>` +
      [...groups]
        .map(
          ([level, list]) =>
            `<section class="hunt-group"><h3>Hunt · Nv. ${fmt(level)} <small>· ${list.length} alvos</small></h3><p class="attacker-level">${esc(selected.name)} ${mode === 'stage' ? 'simulado' : 'selecionado'} no Nv. ${fmt(list[0].attackerLevel)} · golpes até este nível</p>${list.map((h, i) => `${i === 6 ? `<details class="more-targets"><summary>Ver mais ${list.length - 6} alvos deste nível</summary>` : ''}<div class="hunt"><div><strong>${i + 1}. ${h.speciesIds.length === 1 ? `<a href="analyzer.html?embedded=1&species=${h.speciesIds[0]}&tab=drops" rel="noopener" title="Consultar drops deste alvo">${esc(h.name)}</a>` : esc(h.name)}</strong><small>${h.targets.map((t) => `${esc(t.c.name)} · ${fmt(t.c.experience)} XP base`).join(' / ')}</small></div><div>${h.targets.map((t) => `<strong>${esc(t.best.move.name)}</strong><small>${TYPES[t.best.move.type]} · aprende no Nv. ${fmt(t.best.move.learnLevel)} · Poder ${fmt(t.best.move.power)}${t.best.stab > 1 ? ' · STAB' : ''}${h.targets.length > 1 ? ' · ' + esc(t.c.name) : ''}</small>`).join('')}</div><span class="mult ${h.minMultiplier >= 2.5 ? 'strong' : h.minMultiplier < 1 ? 'weak' : ''}">${fmt(h.minMultiplier, 2)}×</span>${h.targets.length > 1 ? `<details><summary>Hunt com vários alvos · menor multiplicador em destaque</summary>${h.targets.map((t) => `<p>${esc(t.c.name)}: ${esc(t.best.move.name)} · ${fmt(t.best.multiplier, 2)}×</p>`).join('')}</details>` : ''}</div>`).join('')}${list.length > 6 ? '</details>' : ''}</section>`,
        )
        .join('') +
      (rows.length
        ? ''
        : '<div class="empty">Nenhum alvo com estes filtros e golpes liberados. Ajuste a efetividade ou aumente o nível.</div>'),
  );
}
function drops() {
  renderHTML(
    $('drops'),
    `<h2>O que ${esc(selected.name)} dropa?</h2><p>Drops base desta espécie selvagem. A qualidade do exemplar analisado não altera esta tabela.</p><label>Filtrar item<input id="drop-search" type="search" placeholder="Stone, orb, gem…"></label><div id="drop-list"></div>`,
  );
  const render = () => {
    const list = (selected.loot || []).filter((l) =>
      l.name.toLowerCase().includes($('drop-search').value.toLowerCase()),
    );
    renderHTML(
      $('drop-list'),
      `<div class="scroll"><table><thead><tr><th>Item</th><th>Chance base</th><th>Qtd.</th><th>NPC / un.</th></tr></thead><tbody>${list
        .map((l) => {
          const item = items.find(
            (i) => i.name.toLowerCase() === l.name.toLowerCase(),
          );
          return `<tr><td><span class="item-label">${itemSprite(item || l)}<span>${esc(l.name)}</span></span></td><td>${fmt(l.chance / 1000, 5)}%${l.chance === 0 ? ' · inativo' : ''}</td><td>${l.minCount}–${l.maxCount}</td><td>${fmt(item?.npcPrice)}</td></tr>`;
        })
        .join(
          '',
        )}</tbody></table></div><p class="muted">Chance base = valor do catálogo ÷ 1.000. Bônus de conta podem alterar a chance. Preços NPC não são preços de mercado.</p>`,
    );
  };
  $('drop-search').addEventListener('input', render);
  render();
}
async function init() {
  await Promise.all([loadSprites(), loadItemSprites()]);
  const [data, types, itemData, evolutionData] = await Promise.all(
    ['hunts', 'type-chart', 'items', 'evolutions'].map((n) =>
      fetch(`data/${n}.json`).then((r) => r.json()),
    ),
  );
  catalog = data;
  chart = types.chart;
  items = itemData.items;
  const params = new URLSearchParams(location.search);
  selectionKey = params.get('selection');
  if (selectionKey) {
    const value = api
      ? await send({ type: 'selection-get', key: selectionKey })
      : JSON.parse(
          sessionStorage.getItem('bds-selection-' + selectionKey) || 'null',
        );
    if (value) {
      record = value.record;
      profileName = value.profileName;
    }
  }
  selected = record
    ? findSpecies(catalog.creatures, record.name)
    : catalog.creatures.find((c) => c.pokeId === Number(params.get('species')));
  if (!selected)
    throw new Error(
      record
        ? `A forma “${record.name}” não foi identificada com segurança. Use o formulário manual para selecionar a forma exata.`
        : 'Selecione um Pokémon no catálogo ou no jogo.',
    );
  if (!record) {
    reference = true;
    record = referenceRecord(selected);
    profileName = 'Prévia da Pokédex · modelo de comparação';
  }
  if (record) {
    record.speciesId = selected.pokeId;
    result =
      !reference && /ditto/i.test(record.name)
        ? {
            valid: false,
            reason:
              'Ditto e transformações exigem regras próprias; não inferimos IVs individuais pelas bases de outra forma.',
          }
        : estimateObserved(record, baseStats(selected));
  }
  renderHTML(
    $('identity'),
    `<div class="portrait">${sprite(selected, { shiny: !!record?.shiny, eager: true })}</div><div><span class="eyebrow">${esc(profileName)} · #${selected.pokeId}</span><h1>${esc(record?.name || selected.name)}${record?.shiny ? ' ✨' : ''}</h1><div class="chips">${chips(selected)}<span class="chip">${reference ? 'Modelo de referência' : 'Exemplar observado'}</span></div></div>`,
  );
  const requestedLevel = Number(params.get('level'));
  fixedReference =
    reference &&
    Number.isInteger(requestedLevel) &&
    requestedLevel > 0 &&
    requestedLevel <= 100000;
  analysisLevel = fixedReference
    ? requestedLevel
    : reference
      ? 1
      : record.level;
  renderEvolution($('lineage'), selected, catalog.creatures, evolutionData);
  quality();
  battle();
  progress();
  drops();
  if (params.has('embedded')) {
    document.body.classList.add('embedded');
    document.querySelector('.analyzer-header a').hidden = true;
    if (reference) document.querySelector('.analyzer-header').hidden = true;
  }
  renderHTML(
    $('source'),
    `Catálogo salvo em ${new Date(catalog.fetchedAt).toLocaleString('pt-BR')}. ${record && !reference ? `Leitura em ${new Date(record.capturedAt).toLocaleString('pt-BR')}.` : ''} <a href="https://poke.idleworld.online/pokepedia/systems/combat" target="_blank" rel="noopener">Fonte: combate oficial ↗</a><br>IVs estimados pela fórmula fornecida, com stats sem bônus. HP/Vel: expoente 0,95; demais: 0,80. Dados de qualidade, tipos e drops têm papéis distintos.`,
  );
  document.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.tab) {
      document
        .querySelectorAll('.tab')
        .forEach((t) => t.classList.toggle('active', t.id === b.dataset.tab));
      document
        .querySelectorAll('[data-tab]')
        .forEach((t) => t.classList.toggle('active', t === b));
    }
    if (b.dataset.region) {
      region = b.dataset.region;
      document
        .querySelectorAll('[data-region]')
        .forEach((t) => t.classList.toggle('active', t === b));
      huntList();
    }
  });
  if (['quality', 'battle', 'progress', 'drops'].includes(params.get('tab')))
    document.querySelector(`[data-tab=${params.get('tab')}]`).click();
  $('save').addEventListener('click', async () => {
    try {
      await send({ type: 'selection-save', key: selectionKey });
      toast('Exemplar salvo na conta de origem.');
    } catch (e) {
      toast(e.message);
    }
  });
}
requireAccess()
  .then((allowed) => (allowed ? init() : undefined))
  .catch((e) => {
    document.querySelector('main').textContent = e.message;
  });
