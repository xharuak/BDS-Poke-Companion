import { STATS, baseStats, stat } from './core.js';
import { availableMoves, multiplier, pokemonTypes } from './battle.js';
import {
  ACCESS_REGIONS,
  captureRegionIndex,
  captureRegionsFor,
  acquisitionRoutesFor,
  validAccessRegions,
  isCaptureExcluded,
} from './availability.js';

export const META_GOALS = {
  balanced: { label: 'Visão geral', axis: null },
  leveling: { label: 'Hunts / up', axis: 'farm' },
  damage: { label: 'Dano por golpe', axis: 'damage' },
  bulk: { label: 'Resistência', axis: 'bulk' },
};
// Species strength is lexicographic: a weaker main attack can never be
// compensated by a weighted average, defenses, or a second attack.
export function offenseKey(c) {
  const b = baseStats(c);
  return [Math.max(b.atk, b.spa), b.def, b.spd, b.hp, Math.min(b.atk, b.spa)];
}
export function compareOffense(a, b) {
  const x = offenseKey(a),
    y = offenseKey(b);
  for (let i = 0; i < x.length; i++) {
    if (x[i] !== y[i]) return y[i] - x[i];
  }
  return a.pokeId - b.pokeId;
}
export function referenceStats(c, level) {
  const b = baseStats(c);
  return Object.fromEntries(STATS.map((k) => [k, stat(b[k], 16, level, 1, k)]));
}
const avg = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const validStats = (c) =>
  STATS.every((k) => Number.isFinite(baseStats(c)[k]) && baseStats(c)[k] > 0);
const effectType = { POISON: 'POISON', BURN: 'FIRE' };

// Elemental typing is only a research lead, never proof that a move applies a status.
// A verified mapping must cite its game source. No guessed proc chance or DoT bonus.
export function statusEvidence(c, effect, level, evidence) {
  if (!effect) return { verified: [], candidates: [] };
  const rules = (evidence?.effects?.[effect]?.verifiedMoves || []).filter(
    (r) => r.source && r.name,
  );
  const moves = (c.attacks || []).filter(
    (m) => !m.tm && m.power < 600 && m.learnLevel <= level,
  );
  return {
    verified: moves.flatMap((move) => {
      const rule = rules.find(
        (r) =>
          r.name === move.name &&
          (!r.speciesIds || r.speciesIds.includes(c.pokeId)),
      );
      return rule ? [{ move, rule }] : [];
    }),
    candidates: moves.filter((m) => m.type === effectType[effect]),
  };
}

function moveIndices(chart, c, stats, target, targetStats, moves) {
  return moves
    .map((move) => {
      const mult = multiplier(chart, move.type, pokemonTypes(target));
      if (mult === null) return null;
      const special = move.category === 'SPECIAL',
        stab = pokemonTypes(c).includes(move.type) ? 1.5 : 1;
      const hit =
        (move.power * stab * mult * stats[special ? 'spa' : 'atk']) /
        Math.max(1, targetStats[special ? 'spd' : 'def']);
      return {
        move,
        multiplier: mult,
        stab,
        hit,
        rate:
          Number.isFinite(move.cooldownMs) && move.cooldownMs > 0
            ? hit / (move.cooldownMs / 1000)
            : null,
      };
    })
    .filter(Boolean);
}

export function rankMeta({
  creatures,
  hunts,
  chart,
  evidence = {},
  type = '',
  effect = '',
  includeCandidates = false,
  level = 100,
  region = 'kanto',
  minHunt = 1,
  maxHunt = 100,
  goal = 'balanced',
  includeLegendary = false,
  accessibleRegions = ACCESS_REGIONS,
}) {
  if (
    !Number.isSafeInteger(level) ||
    level < 1 ||
    level > 100000 ||
    !Number.isSafeInteger(minHunt) ||
    minHunt < 1 ||
    !Number.isSafeInteger(maxHunt) ||
    maxHunt < minHunt
  )
    return {
      error:
        'Informe níveis inteiros positivos e uma faixa de hunts válida. O comparador aceita Pokémon do nível 1 ao 100.000.',
      rows: [],
      total: 0,
    };
  if (!META_GOALS[goal])
    return { error: 'Objetivo inválido.', rows: [], total: 0 };
  if (!validAccessRegions(accessibleRegions) || !accessibleRegions.length)
    return {
      error: 'Marque pelo menos uma região acessível.',
      rows: [],
      total: 0,
    };
  if (region && !accessibleRegions.includes(region))
    return {
      error:
        'O mapa da hunt não está entre as regiões acessíveis. Ajuste o mapa ou seu acesso.',
      rows: [],
      total: 0,
    };
  const origins = captureRegionIndex(creatures, hunts);
  const byId = new Map(creatures.map((c) => [c.pokeId, c]));
  const targets = hunts
    .filter(
      (h) =>
        accessibleRegions.includes(h.region) &&
        (!region || h.region === region) &&
        h.level >= minHunt &&
        h.level <= maxHunt,
    )
    .map((h) => {
      const cs = h.speciesIds.map((id) => byId.get(id));
      if (
        !cs.length ||
        cs.some(
          (c) =>
            !c ||
            !validStats(c) ||
            !pokemonTypes(c).length ||
            pokemonTypes(c).some((t) => !chart[t]),
        )
      )
        return null;
      return {
        ...h,
        targets: cs.map((c) => ({
          c,
          stats: referenceStats(c, h.level),
          attackTypes: [
            ...new Set(availableMoves(c, h.level).map((m) => m.type)),
          ],
        })),
      };
    })
    .filter(Boolean);
  if (!targets.length)
    return {
      error:
        'Nenhuma hunt oficial nesta faixa e região. Ajuste os níveis ou o mapa.',
      rows: [],
      total: 0,
    };
  let skipped = 0;
  const rows = creatures
    .filter(
      (c) =>
        c.pokeId < 10000 &&
        !isCaptureExcluded(c) &&
        acquisitionRoutesFor(c, origins, accessibleRegions).length &&
        (!type || pokemonTypes(c).includes(type)) &&
        (includeLegendary || c.rarity !== 'LEGENDARY'),
    )
    .map((c) => {
      if (!validStats(c)) {
        skipped++;
        return null;
      }
      const status = statusEvidence(c, effect, level, evidence);
      if (
        effect &&
        !status.verified.length &&
        !(includeCandidates && status.candidates.length)
      )
        return null;
      const stats = referenceStats(c, level),
        moves = availableMoves(c, level);
      if (!moves.length) {
        skipped++;
        return null;
      }
      const evaluated = targets
        .map((h) => {
          const results = h.targets.map((t) => {
            const options = moveIndices(chart, c, stats, t.c, t.stats, moves),
              burst = [...options].sort((a, b) => b.hit - a.hit)[0];
            // Cap relative impact at the target HP so excess power cannot imply unlimited kills.
            // This saturation is a ranking heuristic, not the server damage/kill formula.
            // Requested idle model: keep the strongest single hit for this opponent,
            // even if a weaker move has a shorter cooldown. No rotation average.
            const sustained =
              burst?.rate != null
                ? {
                    ...burst,
                    pace:
                      Math.min(1, burst.hit / Math.max(1, t.stats.hp * 5)) /
                      (burst.move.cooldownMs / 1000),
                  }
                : null;
            const danger = Math.max(
              0,
              ...t.attackTypes.map(
                (type) => multiplier(chart, type, pokemonTypes(c)) ?? 1,
              ),
            );
            const farm =
              sustained && Number.isFinite(t.c.experience) && t.c.experience > 0
                ? sustained.pace * t.c.experience
                : null;
            return { target: t.c, burst, sustained, farm, danger };
          });
          if (results.some((t) => !t.burst)) return null;
          const damage = Math.min(...results.map((t) => t.burst.hit)),
            farm = results.every((t) => t.farm !== null)
              ? Math.min(...results.map((t) => t.farm))
              : null;
          // Mixed spawns use their least favorable result, not an invented spawn probability.
          const limiting = results
            .filter((t) => t.farm !== null)
            .sort((a, b) => a.farm - b.farm)[0];
          return {
            ...h,
            results,
            damage,
            farm,
            limiting,
            danger: Math.max(...results.map((t) => t.danger)),
          };
        })
        .filter(Boolean);
      if (!evaluated.length) {
        skipped++;
        return null;
      }
      const opportunities = evaluated
        .filter((h) => h.farm !== null)
        .sort(
          (a, b) =>
            b.farm - a.farm ||
            a.level - b.level ||
            a.slug.localeCompare(b.slug),
        );
      const farm = avg(opportunities.slice(0, 3).map((h) => h.farm)),
        damage = avg(evaluated.map((h) => h.damage));
      // A transparent defensive index, not seconds alive. Immunity cannot cause infinity.
      const danger = avg(evaluated.map((h) => h.danger)),
        bulk = (stats.hp * Math.sqrt(stats.def * stats.spd)) / (1 + danger);
      const raw = { farm, damage, bulk };
      return {
        c,
        stats,
        status,
        raw,
        captureRegions: captureRegionsFor(c, origins, accessibleRegions),
        acquisitionRoutes: acquisitionRoutesFor(c, origins, accessibleRegions),
        offense: offenseKey(c),
        opportunities: opportunities.slice(0, 3),
        power: STATS.reduce((n, k) => n + stats[k], 0),
        moves,
        coverage: evaluated.filter((h) =>
          h.results.every((t) => t.burst.multiplier > 1),
        ).length,
        targetCount: evaluated.length,
        missingCooldown: moves.filter(
          (m) => !Number.isFinite(m.cooldownMs) || m.cooldownMs <= 0,
        ).length,
      };
    })
    .filter(Boolean);
  // The best candidate in the current comparison is 100 on each axis. Not a win chance.
  const maxima = Object.fromEntries(
    ['farm', 'damage', 'bulk'].map((k) => [
      k,
      Math.max(0, ...rows.map((r) => r.raw[k])),
    ]),
  );
  for (const r of rows) {
    r.axes = Object.fromEntries(
      Object.keys(maxima).map((k) => [
        k,
        maxima[k] > 0 ? (r.raw[k] / maxima[k]) * 100 : 0,
      ]),
    );
    r.score = r.offense[0];
  }
  rows.sort((a, b) => compareOffense(a.c, b.c));
  return {
    rows: rows.slice(0, 6),
    total: rows.length,
    targetCount: targets.length,
    skipped,
    level,
    goal,
  };
}
