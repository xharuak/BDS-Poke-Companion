const api = globalThis.browser?.runtime?.id
  ? browser
  : globalThis.chrome?.runtime?.id
    ? chrome
    : null;
export async function requireAccess() {
  let status;
  try {
    const r = api
      ? await api.runtime.sendMessage({ type: 'access-status' })
      : null;
    status = r?.ok ? r.data : null;
  } catch {}
  if (status?.allowed) {
    document.documentElement.removeAttribute('data-access-loading');
    const link = document.createElement('a');
    link.className = 'access-account-link';
    link.href = api.runtime.getURL('access.html');
    link.target = '_blank';
    link.rel = 'noopener';
    link.textContent = status.owner
      ? 'Conta proprietária · Gerenciar usuários'
      : 'Minha conta BDS';
    document.body.prepend(link);
    let checking = false;
    const timer = setInterval(async () => {
      if (checking) return;
      checking = true;
      try {
        const r = await api.runtime.sendMessage({ type: 'access-status' });
        if (!r?.ok || !r.data?.allowed) {
          clearInterval(timer);
          location.reload();
        }
      } catch {
        clearInterval(timer);
        location.reload();
      } finally {
        checking = false;
      }
    }, 15000);
    window.addEventListener('pagehide', () => clearInterval(timer), {
      once: true,
    });
    return true;
  }
  const section = document.createElement('section');
  section.className = 'access-gate';
  const h = document.createElement('h1');
  h.textContent = 'Sua conta BDS';
  section.append(h);
  const p = document.createElement('p');
  p.textContent =
    status?.phase === 'configuration'
      ? 'O proprietário ainda precisa configurar o serviço de acesso. Consulte CONFIGURAR-ACESSO.txt.'
      : 'Entre na sua conta, confirme o e-mail e aguarde a liberação para usar a extensão.';
  section.append(p);
  if (api) {
    const a = document.createElement('a');
    a.href = api.runtime.getURL('access.html');
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = 'Entrar / Minha conta';
    section.append(a);
  }
  const b = document.createElement('button');
  b.textContent = 'Já entrei · Atualizar';
  b.onclick = () => location.reload();
  section.append(b);
  document.body.replaceChildren(section);
  document.documentElement.removeAttribute('data-access-loading');
  return false;
}
