// Genealogy is independent of acquisition eligibility in Meta/Gym.
// A reference relationship must never unlock a game capture/evolution route.
export function evolutionFamily(selected, creatures, reference) {
  const catalog = new Map(
    creatures
      .filter((c) => c.pokeId > 0 && c.pokeId < 10000)
      .map((c) => [c.pokeId, c]),
  );
  const nodes = new Map(
    (reference.species || []).map((c) => [
      c.id,
      {
        id: c.id,
        name: c.name.replace(/\b\w/g, (s) => s.toUpperCase()),
        catalog: catalog.get(c.id) || null,
      },
    ]),
  );
  for (const [id, c] of catalog)
    nodes.set(id, { id, name: c.name, catalog: c });
  const edges = new Map(),
    put = (e) => edges.set(`${e.from}:${e.to}`, e);
  for (const c of reference.species || [])
    if (c.from && nodes.has(c.from))
      put({ from: c.from, to: c.id, kind: 'reference', level: null });
  for (const [id, c] of catalog)
    if (c.evolvesToId && nodes.has(c.evolvesToId))
      put({
        from: id,
        to: c.evolvesToId,
        kind: 'game',
        level: c.evolveLevel || null,
      });
  // Eevee's branching family was explicitly confirmed by the player; its
  // individual stone/level requirements are not inferred from Vaporeon's entry.
  for (const id of [134, 135, 136, 196, 197, 470, 471, 700])
    if (catalog.has(id)) put({ from: 133, to: id, kind: 'eevee', level: null });
  const id = catalog.has(selected.pokeId)
    ? selected.pokeId
    : catalog.has(selected.captureBase)
      ? selected.captureBase
      : null;
  if (!id)
    return {
      id: null,
      nodes: [],
      edges: [],
      stages: [],
      before: [],
      after: [],
      known: false,
    };
  const found = new Set([id]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const e of edges.values())
      if (found.has(e.from) || found.has(e.to)) {
        if (!found.has(e.from) || !found.has(e.to)) changed = true;
        found.add(e.from);
        found.add(e.to);
      }
  }
  const familyEdges = [...edges.values()].filter(
    (e) => found.has(e.from) && found.has(e.to),
  );
  let roots = [...found].filter((n) => !familyEdges.some((e) => e.to === n));
  if (!roots.length) roots = [id];
  const stages = [],
    seen = new Set();
  let current = roots;
  while (current.length) {
    const stage = current.filter((n) => !seen.has(n));
    if (!stage.length) break;
    stage.forEach((n) => seen.add(n));
    stages.push(stage.map((n) => nodes.get(n)));
    current = familyEdges
      .filter((e) => stage.includes(e.from))
      .map((e) => e.to);
  }
  return {
    id,
    nodes: [...found].map((n) => nodes.get(n)),
    edges: familyEdges,
    stages,
    before: familyEdges.filter((e) => e.to === id),
    after: familyEdges.filter((e) => e.from === id),
    known: (reference.species || []).some((c) => c.id === id),
    base: catalog.get(id),
  };
}
