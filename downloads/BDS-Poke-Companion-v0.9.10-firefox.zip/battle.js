import { baseStats } from './core.js';
export const TYPES = {
  NORMAL: 'Normal',
  FIRE: 'Fogo',
  WATER: 'Água',
  GRASS: 'Planta',
  ELECTRIC: 'Elétrico',
  ICE: 'Gelo',
  FIGHTING: 'Lutador',
  POISON: 'Veneno',
  GROUND: 'Terra',
  FLYING: 'Voador',
  PSYCHIC: 'Psíquico',
  BUG: 'Inseto',
  ROCK: 'Pedra',
  GHOST: 'Fantasma',
  DRAGON: 'Dragão',
  DARK: 'Sombrio',
  STEEL: 'Aço',
  FAIRY: 'Fada',
};
export const REGIONS = {
  kanto: 'Kanto',
  outland: 'Outland',
  orre: 'Orre',
  nightmare: 'Nightmare',
  catalog: 'Outros / Catálogo',
};
export function multiplier(chart, attack, defenders, hunt = true) {
  if (!chart[attack] || !defenders.length || defenders.some((t) => !chart[t]))
    return null;
  const raw = [...new Set(defenders)].reduce(
    (n, t) => n * (chart[attack][t] ?? 1),
    1,
  );
  return !hunt || raw === 0 || raw === 1
    ? raw
    : raw > 1
      ? 1 + (raw - 1) * 1.5
      : raw / 1.5;
}
export const pokemonTypes = (c) => [c.type1, c.type2].filter(Boolean);
export function availableMoves(c, level) {
  return (c.attacks || []).filter(
    (a) =>
      !a.tm &&
      a.power > 0 &&
      a.power < 600 &&
      a.category !== 'STATUS' &&
      a.learnLevel <= level,
  );
}
export function bestMove(
  chart,
  attacker,
  target,
  level,
  current = null,
  attackType = '',
) {
  const base = baseStats(attacker),
    targetBase = baseStats(target),
    types = pokemonTypes(attacker);
  return (
    availableMoves(attacker, level)
      .filter((move) => !attackType || move.type === attackType)
      .map((move) => {
        const mult = multiplier(chart, move.type, pokemonTypes(target));
        const special = move.category === 'SPECIAL',
          attackKey = special ? 'spa' : 'atk',
          defenseKey = special ? 'spd' : 'def';
        const attack = Number.isFinite(current?.[attackKey])
          ? current[attackKey]
          : base[attackKey];
        const stab = types.includes(move.type) ? 1.5 : 1;
        // Relative single-hit index only: no timing, density, hidden bonus, wild IV or quality assumptions.
        const score =
          mult === null
            ? -1
            : (move.power * stab * mult * attack) /
              Math.max(1, targetBase[defenseKey]);
        return { move, multiplier: mult, stab, score };
      })
      .sort((a, b) => b.score - a.score || b.multiplier - a.multiplier)[0] ||
    null
  );
}
export function rankHunts({
  chart,
  attacker,
  creatures,
  hunts,
  level,
  current,
  currentLevel = level,
  levelMode = 'fixed',
  region = 'kanto',
  maxLevel = 0,
  minMultiplier = 0,
  query = '',
  attackType = '',
  exactMultiplier = null,
}) {
  const byId = new Map(creatures.map((c) => [c.pokeId, c]));
  return hunts
    .filter(
      (h) =>
        h.region === region &&
        (!maxLevel || h.level <= maxLevel) &&
        h.name.toLowerCase().includes(query.toLowerCase()),
    )
    .map((h) => {
      // Stage mode is a deliberate simulation: Pokémon level follows this hunt tier.
      // Fixed mode keeps the actual/chosen Pokémon level even in low-level hunts.
      const attackerLevel = levelMode === 'stage' ? h.level : level;
      if (!Number.isInteger(attackerLevel) || attackerLevel < 1)
        return { ...h, valid: false };
      const stats = currentLevel === attackerLevel ? current : null;
      const targets = h.speciesIds
        .map((id) => byId.get(id))
        .filter(Boolean)
        .map((c) => ({
          c,
          best: bestMove(chart, attacker, c, attackerLevel, stats, attackType),
        }));
      const valid =
        targets.length === h.speciesIds.length &&
        targets.length > 0 &&
        targets.every((t) => t.best && t.best.multiplier !== null);
      return {
        ...h,
        attackerLevel,
        targets,
        valid,
        minMultiplier: valid
          ? Math.min(...targets.map((t) => t.best.multiplier))
          : null,
        score: valid ? Math.min(...targets.map((t) => t.best.score)) : -1,
      };
    })
    .filter(
      (h) =>
        h.valid &&
        h.minMultiplier >= minMultiplier &&
        (exactMultiplier === null ||
          Math.abs(h.minMultiplier - exactMultiplier) < 0.005),
    )
    .sort(
      (a, b) =>
        a.level - b.level || b.score - a.score || a.name.localeCompare(b.name),
    );
}
