import { bestMove, availableMoves } from "./battle.js";

const TYPES = new Set(
  "NORMAL FIRE WATER GRASS ELECTRIC ICE FIGHTING POISON GROUND FLYING PSYCHIC BUG ROCK GHOST DRAGON DARK STEEL FAIRY AOE".split(
    " ",
  ),
);
const finite = (n, max = 1e9) => Number.isFinite(n) && n >= 0 && n <= max;
export const TELEMETRY_SUMS = [
  "distanceTiles",
  "movementMs",
  "trainerTiles",
  "trainerMovementMs",
  "respawnMs",
  "respawnSamples",
  "waveMs",
  "waveSamples",
];

export function cleanHuntParty(payload) {
  if (!Array.isArray(payload?.members) || payload.members.length > 6)
    return null;
  const members = payload.members.map((p) => {
    if (
      typeof p?.id !== "string" ||
      p.id.length > 100 ||
      !Number.isSafeInteger(p.level) ||
      p.level < 1
    )
      return null;
    const current = Object.fromEntries(
      ["atk", "def", "spa", "spd", "vel"].map((k) => [
        k,
        finite(p.current?.[k]) ? p.current[k] : null,
      ]),
    );
    const tms =
      Array.isArray(p.tms) &&
      p.tms.length <= 2 &&
      p.tms.every((t) => TYPES.has(t))
        ? [...new Set(p.tms)].sort()
        : null;
    const modifiers =
      typeof p.modifiers === "string" && p.modifiers.length <= 2000
        ? p.modifiers
        : "";
    const modifierUntil = Array.isArray(p.modifierUntil)
      ? p.modifierUntil.filter((n) => finite(n, 1e15)).slice(0, 12)
      : [];
    return {
      id: p.id,
      speciesId: Number.isSafeInteger(p.speciesId) ? p.speciesId : null,
      level: p.level,
      current,
      tms,
      modifiers,
      modifierUntil,
    };
  });
  return members.some((p) => !p) ||
    new Set(members.map((p) => p.id)).size !== members.length
    ? null
    : members;
}
export function cleanHuntGear(payload) {
  if (
    !payload ||
    !["bicycle", "lure"].every(
      (k) =>
        typeof payload[k]?.present === "boolean" &&
        (payload[k].until === null || finite(payload[k].until, 1e15)),
    )
  )
    return null;
  return Object.fromEntries(
    ["bicycle", "lure"].map((k) => [
      k,
      { present: payload[k].present, until: payload[k].until },
    ]),
  );
}
export function cleanHuntEnvironment(payload, key) {
  if (payload?.key !== key) return null;
  return {
    key,
    heroStepMs:
      finite(payload.heroStepMs, 60000) && payload.heroStepMs > 0
        ? payload.heroStepMs
        : null,
    trainerStepMs:
      finite(payload.trainerStepMs, 60000) && payload.trainerStepMs > 0
        ? payload.trainerStepMs
        : null,
    bike: typeof payload.bike === "boolean" ? payload.bike : null,
    apricorn: typeof payload.apricorn === "boolean" ? payload.apricorn : null,
  };
}
export function personalSetup(state, now = Date.now()) {
  const p = state?.party?.find((p) => p.id === state.active?.capId);
  const valid = !!p && p.level === state.active.level;
  const gear = {};
  for (const [name, flag] of [
    ["bicycle", "bike"],
    ["lure", "apricorn"],
  ]) {
    const item = state?.gear?.[name];
    const expired = !!item?.present && item.until !== null && item.until <= now;
    // An expired inventory timestamp cannot remain active just because a field
    // packet received before expiry said so. Unknown inventory stays unknown.
    const native = state?.environment?.[flag];
    gear[name] = {
      known: !!item,
      present: !!item?.present,
      until: item?.until ?? null,
      active: expired
        ? false
        : typeof native === "boolean"
          ? native
          : item
            ? item.present && item.until !== null && item.until > now
            : null,
      expired,
      confirmed: typeof native === "boolean",
    };
  }
  const loadout = valid ? p : null;
  const key = JSON.stringify([
    loadout,
    loadout?.modifierUntil.map((t) => t > now),
    gear.bicycle.active,
    gear.lure.active,
    state?.environment?.heroStepMs ?? null,
    state?.environment?.trainerStepMs ?? null,
  ]);
  return {
    loadout,
    gear,
    key,
    ready:
      !!loadout &&
      loadout.tms !== null &&
      Object.values(loadout.current).every((n) => n !== null) &&
      gear.bicycle.known &&
      gear.lure.known,
  };
}

// A relative combat-work model, calibrated to this specimen's measured XP.
// TMs have a separate cadence; a disk in the bag is never treated as learned.
export function personalWork(
  geometry,
  targets,
  hunt,
  attacker,
  loadout,
  chart,
) {
  const elemental = loadout.tms.find((t) => t !== "AOE");
  const tm = (attacker.attacks || []).find(
    (m) => m.tm === elemental && elemental,
  );
  if (elemental && !tm) return null;
  const natural = availableMoves(attacker, loadout.level);
  if (!natural.length) return null;
  const rows = targets.map((c) => ({
    hp: c.baseHp * Math.max(1, hunt.level) ** 2,
    normal: bestMove(chart, attacker, c, loadout.level, loadout.current),
    normals: Object.fromEntries(
      natural.map((move) => [
        move.name,
        bestMove(
          chart,
          { ...attacker, attacks: [move] },
          c,
          loadout.level,
          loadout.current,
        )?.score || 0,
      ]),
    ),
    tm: tm
      ? bestMove(
          chart,
          {
            ...attacker,
            attacks: [{ ...tm, power: 300, tm: undefined, learnLevel: 1 }],
          },
          c,
          loadout.level,
          loadout.current,
        )
      : null,
  }));
  if (
    rows.some((r) => !r.normal || (!(r.normal.score > 0) && !(r.tm?.score > 0)))
  )
    return null;
  return {
    rows,
    groups: geometry.groups,
    count: geometry.count,
    aoe: loadout.tms.includes("AOE"),
    tmName: tm?.name || null,
    normalNames: natural.map((m) => m.name),
  };
}
export function attackRates(measurement, work) {
  const m = measurement?.steady || measurement;
  const combat = m?.combat;
  const rows = Object.values(combat?.moves || {});
  const normal = rows.filter((m) => work.normalNames.includes(m.name));
  const samples = normal.reduce((n, m) => n + m.batches, 0);
  const seconds = (combat?.combatMs || 0) / 1000;
  if (!(seconds >= 30) || samples < 5) return null;
  const tm = rows.find((m) => m.name === work.tmName);
  return {
    normal: samples / seconds,
    byMove: Object.fromEntries(
      normal.map((m) => [m.name, m.batches / seconds]),
    ),
    // Published elemental cooldown is 10s. Observed batches have delayed hits
    // coalesced in the bridge, and include time when its min-2 condition fails.
    tm: tm?.batches >= 3 ? Math.min(0.1, tm.batches / seconds) : 0,
    tmObserved: !work.tmName || (tm?.batches || 0) >= 3,
    normalTargets: samples
      ? normal.reduce((n, m) => n + m.targets, 0) / samples
      : 1,
  };
}
export function personalCost(work, rates, serial = false, secondsScale = null) {
  let total = 0;
  for (const group of work.groups) {
    const n = group.indices.length;
    let seconds = 0;
    for (const i of group.indices) {
      const row = work.rows[i];
      const normalTargets =
        work.aoe && !serial
          ? Math.max(
              1,
              Math.min(n, group.normalCapacity ?? n, rates.normalTargets ?? 1),
            )
          : 1;
      const tmTargets =
        n >= 2 && !serial && (group.tmCapacity ?? n) >= 2
          ? Math.min(n, group.tmCapacity ?? n)
          : 0;
      const normalRate = rates.byMove
        ? Object.entries(rates.byMove).reduce(
            (sum, [name, rate]) =>
              sum + Math.max(0, row.normals[name] || 0) * rate,
            0,
          )
        : Math.max(0, row.normal?.score || 0) * rates.normal;
      const throughput =
        normalRate * normalTargets +
        Math.max(0, row.tm?.score || 0) * rates.tm * tmTargets;
      if (!(throughput > 0)) return Infinity;
      const cost = (row.hp * n) / throughput;
      // The HP/damage index is relative, not elapsed seconds. Calibrate first,
      // then enforce at least one useful hit per monster. A weaker target can
      // never be killed in a fraction of a hit, or grant an unobserved AoE bonus.
      const normalCadence = rates.byMove
        ? Object.entries(rates.byMove).reduce(
            (sum, [name, rate]) => sum + (row.normals[name] > 0 ? rate : 0),
            0,
          )
        : row.normal?.score > 0
          ? rates.normal
          : 0;
      const hitCapacity =
        normalCadence * normalTargets +
        (row.tm?.score > 0 ? rates.tm * tmTargets : 0);
      const timed =
        secondsScale === null
          ? cost
          : Math.max(cost * secondsScale, n / hitCapacity);
      seconds = Math.max(seconds, timed);
    }
    total += seconds;
  }
  return total / work.count;
}

export function respawnObservation(measurement) {
  const c = (measurement?.steady || measurement)?.combat;
  return {
    seconds:
      c?.respawnSamples >= 4 ? c.respawnMs / c.respawnSamples / 1000 : null,
    samples: c?.respawnSamples || 0,
    waveSeconds: c?.waveSamples >= 2 ? c.waveMs / c.waveSamples / 1000 : null,
    waveSamples: c?.waveSamples || 0,
    speed:
      c?.movementMs >= 5000 ? c.distanceTiles / (c.movementMs / 1000) : null,
    trainerSpeed:
      c?.trainerMovementMs >= 5000
        ? c.trainerTiles / (c.trainerMovementMs / 1000)
        : null,
  };
}
