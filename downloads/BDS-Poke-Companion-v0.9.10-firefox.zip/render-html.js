import DOMPurify from './vendor/purify.es.mjs';

// Sanitize at the DOM boundary as well as escaping interpolated text in views.
// Table fragments need their parsing context to preserve rows and cells.
export function renderHTML(host, markup, append = false) {
  const contexts = {
    TBODY: ['<table><tbody>', '</tbody></table>', 'tbody'],
    THEAD: ['<table><thead>', '</thead></table>', 'thead'],
    TFOOT: ['<table><tfoot>', '</tfoot></table>', 'tfoot'],
    TR: ['<table><tbody><tr>', '</tr></tbody></table>', 'tr'],
  };
  const context = contexts[host.tagName];
  const html = String(markup ?? '');
  const fragment = DOMPurify.sanitize(
    context ? context[0] + html + context[1] : html,
    {
      RETURN_DOM_FRAGMENT: true,
      USE_PROFILES: { html: true, svg: true },
      ADD_ATTR: ['target'],
      FORBID_TAGS: ['style'],
    },
  );
  for (const link of fragment.querySelectorAll('a[target="_blank"]')) {
    link.setAttribute('rel', 'noopener noreferrer');
  }
  const content = context ? fragment.querySelector(context[2]) : fragment;
  const nodes = content ? [...content.childNodes] : [];
  if (append) host.append(...nodes);
  else host.replaceChildren(...nodes);
}
