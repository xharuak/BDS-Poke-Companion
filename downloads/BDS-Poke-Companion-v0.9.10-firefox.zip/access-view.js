import { renderHTML } from './render-html.js';
import {
  ACCESS_REGIONS,
  DEFAULT_ACCESS_REGIONS,
  validAccessRegions,
} from './availability.js';
import { REGIONS } from './battle.js';
const key = 'bds-accessible-regions-v1',
  listeners = new Set();
function clean(value) {
  return validAccessRegions(value)
    ? ACCESS_REGIONS.filter((r) => value.includes(r))
    : [...DEFAULT_ACCESS_REGIONS];
}
function read() {
  try {
    const saved = localStorage.getItem(key);
    return saved === null
      ? [...DEFAULT_ACCESS_REGIONS]
      : clean(JSON.parse(saved));
  } catch {
    return [...DEFAULT_ACCESS_REGIONS];
  }
}
let regions = read();
export const getAccessibleRegions = () => [...regions];
export const acquisitionSummary = (routes) =>
  routes
    .map((route) =>
      route.kind === 'npc'
        ? 'NPC · família de ' + route.family
        : REGIONS[route.region] +
          (route.kind === 'evolution'
            ? ' (via evolução de ' + route.names.slice(0, -1).join(' → ') + ')'
            : ' (captura)'),
    )
    .join(' · ');
function publish(next, save = true) {
  regions = clean(next);
  if (save)
    try {
      localStorage.setItem(key, JSON.stringify(regions));
    } catch {}
  for (const listener of listeners) listener();
}
export function setupAccessRegions(id, onChange) {
  const host = document.getElementById(id);
  renderHTML(
    host,
    `<legend>Regiões que você pode acessar</legend><div class="access-options">${ACCESS_REGIONS.map((r) => `<label><input type="checkbox" value="${r}" aria-label="Acesso a ${REGIONS[r]}">${REGIONS[r]}</label>`).join('')}</div><p>Seleção compartilhada entre Meta Pokemon, Gym Meta e Hunt Analyzer. Inclui capturas nos mapas marcados e suas evoluções confirmadas. Eevee, Porygon e suas evoluções catalogadas também entram por obtenção via NPC, independentemente destes mapas.</p>`,
  );
  function sync() {
    host
      .querySelectorAll('input')
      .forEach((el) => (el.checked = regions.includes(el.value)));
  }
  sync();
  listeners.add(() => {
    sync();
    onChange();
  });
  host.addEventListener('change', () =>
    publish([...host.querySelectorAll('input:checked')].map((el) => el.value)),
  );
}
window.addEventListener('storage', (event) => {
  if (event.key === key || event.key === null) publish(read(), false);
});
