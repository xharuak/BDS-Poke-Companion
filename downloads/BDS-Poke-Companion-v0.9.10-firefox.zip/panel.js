import { renderHTML } from './render-html.js';
import { requireAccess } from './access-gate.js';
import { loadItemSprites, itemSprite } from './item-sprites.js';
import { loadSprites, sprite } from './sprites.js';
import {
  STATS,
  LABELS,
  normalize,
  num,
  estimate,
  parseTooltip,
  findSpecies,
  baseStats,
  huntRates,
  addProfile,
  validBackup,
  qualityLabel,
  stat,
} from './core.js';
const $ = (id) => document.getElementById(id);
const api = globalThis.browser?.runtime?.id
  ? browser
  : globalThis.chrome?.runtime?.id
    ? chrome
    : null;
const e = (v) =>
  String(v ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
const f = (n, d = 0) =>
  Number.isFinite(n)
    ? n.toLocaleString('pt-BR', { maximumFractionDigits: d })
    : '—';
const range = (lo, hi, d = 0) =>
  Math.abs(lo - hi) < 10 ** -d ? f(lo, d) : `${f(lo, d)}–${f(hi, d)}`;
const date = (s) => {
  const d = new Date(s);
  return Number.isNaN(+d) ? 'Data indisponível' : d.toLocaleString('pt-BR');
};
const types = {
  NORMAL: 'Normal',
  FIRE: 'Fogo',
  WATER: 'Água',
  GRASS: 'Planta',
  ELECTRIC: 'Elétrico',
  ICE: 'Gelo',
  FIGHTING: 'Lutador',
  POISON: 'Veneno',
  GROUND: 'Terra',
  FLYING: 'Voador',
  PSYCHIC: 'Psíquico',
  BUG: 'Inseto',
  ROCK: 'Pedra',
  GHOST: 'Fantasma',
  DRAGON: 'Dragão',
  DARK: 'Sombrio',
  STEEL: 'Aço',
  FAIRY: 'Fada',
};
const official = 'https://poke.idleworld.online';
const links = [
  ['Pokémon', '/pokepedia/pokemon'],
  ['Itens', '/pokepedia/items'],
  ['Golpes', '/pokepedia/moves'],
  ['TM · Disks', '/pokepedia/tms'],
  ['Held Items', '/pokepedia/helds'],
  ['Tipos e resistências', '/pokepedia/types'],
  ['Power', '/pokepedia/systems/power'],
  ['Qualidade e IVs', '/pokepedia/systems/quality'],
  ['Shinies', '/pokepedia/systems/shiny'],
  ['Shiny Cards', '/pokepedia/systems/shinycards'],
  ['Evolução', '/pokepedia/systems/evolution'],
  ['XP', '/pokepedia/systems/xp'],
  ['Streak', '/pokepedia/systems/streak'],
  ['Clãs', '/pokepedia/systems/clans'],
  ['VIP', '/pokepedia/systems/vip'],
  ['Boost', '/pokepedia/systems/boost'],
  ['Quests', '/pokepedia/systems/quests'],
  ['Combate na hunt', '/pokepedia/systems/combat'],
  ['Modo soneca', '/pokepedia/systems/offline'],
  ['Addons', '/pokepedia/systems/addons'],
];
let workspace,
  creatures = [],
  items = [],
  moves = [],
  provenance;
let kind = 'pokemon',
  limit = 24,
  favoriteOnly = false,
  analyzed = null,
  source = 'entrada manual',
  incoming = null;
const compared = new Set();
let toastTimer;
let accountLinks = [],
  preferences = {
    dock: false,
    compact: false,
    highlight: true,
    minIV: 160,
    clickMode: 'ctrl',
  },
  settingsTab = 'menus';
function toast(message) {
  $('toast').textContent = message;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($('toast').hidden = true), 6000);
}
async function getWorkspace() {
  return api
    ? (await api.storage.local.get('workspace')).workspace
    : JSON.parse(localStorage.getItem('bds-preview') || 'null');
}
async function putWorkspace(value) {
  if (api) await api.storage.local.set({ workspace: value });
  else localStorage.setItem('bds-preview', JSON.stringify(value));
}
async function updateState(mutate) {
  const work = async () => {
    workspace = (await getWorkspace()) || workspace;
    mutate(workspace);
    await putWorkspace(workspace);
    renderProfiles();
  };
  if (navigator.locks) await navigator.locks.request('bds-workspace', work);
  else await work();
}
function profile() {
  return (
    workspace.profiles.find((p) => p.id === workspace.active) ||
    workspace.profiles[0]
  );
}
function go(page) {
  if (!$(page)?.classList.contains('page')) return;
  if (page !== 'settings')
    document
      .querySelectorAll('[data-settings]')
      .forEach((b) => b.classList.remove('active'));
  document
    .querySelectorAll('.page')
    .forEach((x) => x.classList.toggle('active', x.id === page));
  document
    .querySelectorAll('[data-page]')
    .forEach((x) => x.classList.toggle('active', x.dataset.page === page));
  history.replaceState(null, '', '#' + page);
  if (page === 'collection') renderCollection();
  if (page === 'hunts') renderHunts();
  if (page === 'accounts') renderAccounts();
}
function external(url, label) {
  return `<a href="${e(url)}" target="_blank" rel="noopener noreferrer">${e(label)} ↗</a>`;
}
function pokemonUrl(c) {
  return `${official}/pokepedia/pokemon/${c.name.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
}
function chips(c) {
  return [c.type1, c.type2]
    .filter(Boolean)
    .map(
      (t) =>
        `<span class="chip" data-type="${e(t)}">${e(types[t] || t)}</span>`,
    )
    .join('');
}
function star(key) {
  const selected = workspace.favorites.includes(key);
  return `<button class="star ${selected ? 'selected' : ''}" data-favorite="${e(key)}" aria-label="${selected ? 'Remover dos' : 'Adicionar aos'} favoritos" aria-pressed="${selected}">${selected ? '★' : '☆'}</button>`;
}
function empty(title, text) {
  return `<div class="empty"><strong>${e(title)}</strong>${e(text)}</div>`;
}
function buildMoves() {
  const map = new Map();
  for (const c of creatures)
    for (const a of c.attacks || []) {
      if (a.tm) continue; // Public Pokepedia applies extra TM rules; do not invent them.
      const key = normalize(a.name),
        entry = map.get(key) || {
          name: a.name,
          type1: a.type,
          category: a.category,
          variants: [],
          learners: [],
        };
      entry.variants.push(a);
      entry.learners.push({ c, a });
      map.set(key, entry);
    }
  moves = [...map.values()];
}
function renderCatalog() {
  const query = normalize($('search').value),
    type = $('type-filter').value,
    maxLevel = num($('hunt-level').value),
    sort = $('sort').value;
  $('hunt-level').disabled = kind !== 'pokemon';
  $('type-filter').disabled = kind === 'item';
  let list = kind === 'pokemon' ? creatures : kind === 'item' ? items : moves;
  const keyOf = (c) =>
    `${kind}:${kind === 'pokemon' ? c.pokeId : kind === 'item' ? c.id : c.name}`;
  list = list
    .filter((c) => {
      const key = keyOf(c);
      if (favoriteOnly && !workspace.favorites.includes(key)) return false;
      if (type && kind !== 'item' && c.type1 !== type && c.type2 !== type)
        return false;
      if (
        kind === 'pokemon' &&
        maxLevel &&
        (!c.huntLevel || c.huntLevel > maxLevel)
      )
        return false;
      const text = [
        c.name,
        c.pokeId,
        c.category,
        c.rarity,
        c.type1,
        c.type2,
        types[c.type1],
        types[c.type2],
        ...(c.loot || []).map((x) => x.name),
      ].join(' ');
      return !query || normalize(text).includes(query);
    })
    .sort((a, b) => {
      if (sort === 'xp' && kind === 'pokemon')
        return (b.experience || 0) - (a.experience || 0);
      if (sort === 'base' && kind === 'pokemon')
        return (
          Object.values(baseStats(b)).reduce((a, b) => a + b, 0) -
          Object.values(baseStats(a)).reduce((a, b) => a + b, 0)
        );
      if (sort === 'id' && kind === 'pokemon') return a.pokeId - b.pokeId;
      return a.name.localeCompare(b.name);
    });
  $('result-count').textContent = `${f(list.length)} resultados`;
  $('results-title').textContent = query
    ? `Resultados para “${$('search').value}”`
    : favoriteOnly
      ? 'Seus favoritos'
      : kind === 'pokemon'
        ? 'Explore o catálogo'
        : kind === 'item'
          ? 'Encontre seus próximos drops'
          : 'Conheça os golpes';
  renderHTML(
    $('results'),
    list
      .slice(0, limit)
      .map((c) => {
        const key = keyOf(c),
          id =
            kind === 'pokemon'
              ? `#${String(c.pokeId).padStart(3, '0')}`
              : kind === 'item'
                ? 'ITEM'
                : 'GOLPE';
        let meta = '';
        if (kind === 'pokemon')
          meta = `<span>Hunt <b>Nv. ${f(c.huntLevel)}</b></span><span>XP / derrota <b>${f(c.experience)}</b></span>`;
        if (kind === 'item')
          meta = `<span>Valor NPC <b>${f(c.npcPrice)} gold</b></span><span>Fontes de drop <b>${creatures.filter((p) => p.loot?.some((l) => normalize(l.name) === normalize(c.name) && l.chance > 0)).length}</b></span>`;
        if (kind === 'move')
          meta = `<span>Poder <b>${range(Math.min(...c.variants.map((a) => a.power)), Math.max(...c.variants.map((a) => a.power)))}</b></span><span>Aprendem <b>${new Set(c.learners.map((x) => x.c.pokeId)).size} espécies</b></span>`;
        return `<article class="card"><div class="card-top"><span>${e(id)}</span>${star(key)}</div><div class="monogram">${
          kind === 'pokemon'
            ? sprite(c)
            : kind === 'item'
              ? itemSprite(c)
              : e(
                  c.name
                    .replace(/[^A-Za-z]/g, '')
                    .slice(0, 2)
                    .toUpperCase(),
                )
        }</div><h3><button class="open-card" data-detail="${e(key)}">${e(c.name)}</button></h3><div class="chips">${kind === 'item' ? `<span class="chip">${e(c.category)}</span>` : chips(c)}</div><div class="card-meta">${meta}</div></article>`;
      })
      .join('') ||
      empty('Nenhum resultado', 'Tente outro nome ou remova os filtros.'),
  );
  $('more').hidden = list.length <= limit;
}
function table(headers, rows) {
  return `<div class="table-scroll"><table><thead><tr>${headers.map((h) => `<th>${e(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function detail(key) {
  const [what, ...parts] = key.split(':'),
    id = parts.join(':');
  let html = '';
  if (what === 'pokemon') {
    const c = creatures.find((c) => c.pokeId === Number(id));
    if (!c) return;
    const next = creatures.find((p) => p.pokeId === c.evolvesToId);
    html = `<div class="detail-identity">${sprite(c, { eager: true })}<div><span class="eyebrow accent">POKÉMON #${c.pokeId}</span><h1>${e(c.name)}</h1><div class="chips">${chips(c)}</div></div></div><p class="footnote">Raridade do catálogo: ${e(c.rarity)} · Não é a qualidade de um exemplar.</p><div class="detail-stats">${STATS.map((k) => `<div><small>${LABELS[k]}</small><b>${f(baseStats(c)[k])}</b></div>`).join('')}</div><div class="metric-grid"><div class="metric"><b>${f(c.huntLevel)}</b><small>Nível da hunt</small></div><div class="metric"><b>${f(c.experience)}</b><small>XP base por derrota</small></div><div class="metric"><b>${f(c.sellValue)}</b><small>Venda NPC · gold</small></div></div><p>${next ? `Evolui para <button data-detail="pokemon:${next.pokeId}">${e(next.name)}</button> · nível ${f(c.evolveLevel)} no catálogo. Confirme pedras e condições na Pokepedia.` : 'Sem próxima evolução indicada neste catálogo.'}</p><div class="actions"><button class="primary" data-analyze="${c.pokeId}">Analisar um exemplar</button>${external(pokemonUrl(c), 'Abrir Pokepedia')}</div><h2>Golpes naturais</h2>${table(
      ['Golpe', 'Tipo', 'Poder', 'Nível', 'Cooldown'],
      (c.attacks || [])
        .filter((a) => !a.tm)
        .map((a) => [
          `<button data-detail="move:${e(a.name)}">${e(a.name)}</button>`,
          e(types[a.type] || a.type),
          f(a.power),
          f(a.learnLevel),
          `${f(a.cooldownMs / 1000, 1)} s`,
        ]),
    )}<p class="footnote">Golpes de TM e compatibilidade: ${external(official + '/pokepedia/tms', 'consultar fonte oficial')}.</p><h2>Drops desta espécie</h2>${table(
      ['Item', 'Chance base', 'Quantidade', 'Valor NPC/un.'],
      (c.loot || []).map((l) => {
        const item = items.find((x) => normalize(x.name) === normalize(l.name));
        return [
          item
            ? `<button class="item-label" data-detail="item:${item.id}">${itemSprite(item)}<span>${e(l.name)}</span></button>`
            : `<span class="item-label">${itemSprite(l)}<span>${e(l.name)}</span></span>`,
          `${f(l.chance / 1000, 5)}%`,
          `${l.minCount}–${l.maxCount}`,
          item ? f(item.npcPrice) : 'Desconhecido',
        ];
      }),
    )}<p class="footnote">Chances base do catálogo; bônus podem alterá-las. Valor NPC não é preço do mercado. 0% não indica uma fonte ativa.</p>${external(official + '/pokepedia/types', 'Fraquezas e resistências oficiais')}`;
  } else if (what === 'item') {
    const item = items.find((x) => x.id === Number(id));
    if (!item) return;
    const drops = creatures
      .flatMap((c) =>
        (c.loot || [])
          .filter(
            (l) => normalize(l.name) === normalize(item.name) && l.chance > 0,
          )
          .map((l) => ({ c, l })),
      )
      .sort((a, b) => b.l.chance - a.l.chance);
    html = `<div class="detail-identity">${itemSprite(item, { eager: true })}<div><span class="eyebrow accent">ITEM · ${e(item.category)}</span><h1>${e(item.name)}</h1></div></div><p>Valor NPC: <strong>${f(item.npcPrice)} gold</strong> por unidade.</p><h2>Quem dropa?</h2>${
      drops.length
        ? table(
            ['Pokémon', 'Hunt', 'Chance base', 'Quantidade'],
            drops.map(({ c, l }) => [
              `<button data-detail="pokemon:${c.pokeId}">${e(c.name)}</button>`,
              f(c.huntLevel),
              `${f(l.chance / 1000, 5)}%`,
              `${l.minCount}–${l.maxCount}`,
            ]),
          )
        : empty(
            'Sem drop comum conhecido',
            'Consulte fontes especiais, lojas, eventos e shinies na Pokepedia.',
          )
    }<p class="footnote">A lista considera drops comuns com chance maior que zero no catálogo. Não estima preços de jogadores nem garante obtenção.</p>${external(official + '/pokepedia/items', 'Ver itens na Pokepedia')}`;
  } else {
    const move = moves.find((m) => m.name === id);
    if (!move) return;
    html = `<span class="eyebrow accent">GOLPE · ${e(move.category)}</span><h1>${e(move.name)}</h1><div class="chips">${chips(move)}</div><p class="footnote">Dados por espécie. O poder do golpe não equivale ao dano efetivo.</p>${table(
      ['Aprende', 'Nível', 'Poder', 'Cooldown'],
      move.learners.map(({ c, a }) => [
        `<button data-detail="pokemon:${c.pokeId}">${e(c.name)}</button>`,
        f(a.learnLevel),
        f(a.power),
        `${f(a.cooldownMs / 1000, 1)} s`,
      ]),
    )}${external(official + '/pokepedia/moves', 'Ver golpes oficiais')}`;
  }
  if (what === 'pokemon')
    html =
      `<button class="primary full-analysis" data-open-species="${Number(id)}">Qualidade · Batalha · Progressão · Drops →</button>` +
      html;
  renderHTML($('detail-content'), html);
  if (!$('detail').open) $('detail').showModal();
  $('detail').scrollTop = 0;
}
function renderProfiles() {
  renderHTML(
    $('profile'),
    workspace.profiles
      .map((p) => `<option value="${e(p.id)}">${e(p.name)}</option>`)
      .join(''),
  );
  $('profile').value = workspace.active;
  renderHTML(
    $('account-strip'),
    workspace.profiles
      .map((p, i) => {
        const a = accountLinks.find((a) => a.id === p.id),
          s = p.sessions.at(-1),
          r = s ? huntRates(s) : null;
        return `<button class="account-switch ${p.id === workspace.active ? 'active' : ''}" data-focus-account="${e(p.id)}"><span class="account-number">${i + 1} <i class="${a?.tabId ? 'connected' : ''}"></i></span><strong>${e(p.name)}</strong><small>${a?.tabId ? 'Exibir conta · aba vinculada' : 'Configurar vínculo com uma aba'}</small><div>${r ? `<b>${f(r.xpH)} XP/h</b> <span>última sessão manual</span>` : `<b>${p.records.length} exemplares</b> <span>${p.sessions.length} caçadas registradas</span>`}</div></button>`;
      })
      .join('') +
      (workspace.profiles.length < 4
        ? '<button class="account-add" data-page="accounts">＋<small>Adicionar conta</small></button>'
        : ''),
  );
}
async function refreshAccountLinks() {
  if (api) {
    accountLinks = await message({ type: 'accounts-status' }).catch(() => []);
    renderProfiles();
  }
}
async function openAnalyzer(record = null, speciesId = null) {
  let url = 'analyzer.html';
  if (record) {
    let key;
    if (api)
      ({ key } = await message({
        type: 'selection-create',
        record,
        profileId: workspace.active,
      }));
    else {
      key = crypto.randomUUID();
      sessionStorage.setItem(
        'bds-selection-' + key,
        JSON.stringify({ record, profileName: profile().name }),
      );
    }
    url += '?selection=' + encodeURIComponent(key);
  } else url += '?species=' + Number(speciesId);
  if ($('detail').open) $('detail').close();
  $('analyzer-frame').src = url;
  $('analyzer-dialog').showModal();
}
function renderSettings(tab = settingsTab) {
  settingsTab = tab;
  go('settings');
  document
    .querySelectorAll('[data-settings]')
    .forEach((b) => b.classList.toggle('active', b.dataset.settings === tab));
  const content = {
    menus: `<h2>Consulta em poucos cliques</h2><div class="quick-menu"><button data-page="dex">◈ Pokepedia, golpes e drops</button><button data-page="ivs">◎ IVs e vínculo com o jogo</button><button data-page="collection">▤ Exemplares e comparação</button><button data-page="hunts">↗ Histórico de caçadas</button><button data-page="accounts">⊞ Quatro contas e backup</button></div><p>Nos detalhes de qualquer Pokémon, abra “Qualidade · Batalha · Progressão · Drops” para a análise completa.</p>`,
    filters: `<h2>Filtros de consulta</h2><p>A Pokepedia permite filtrar por nome, tipo, nível de hunt e favoritos. Na Progressão, escolha a região, o nível da conta, o tipo do golpe e a efetividade.</p><div class="actions"><button data-page="dex">Filtrar catálogo</button><button data-open-species="91">Exemplo: progressão de Cloyster</button></div><label>IV mínimo para destacar na seleção<input id="pref-minIV" type="number" min="6" max="192" value="${preferences.minIV}"></label><button id="save-preferences">Salvar filtro</button>`,
    tools: `<h2>Ferramentas</h2><div class="quick-menu"><button id="open-overlay">Abrir painel sobre o jogo</button><button data-page="ivs">Colar ou digitar um tooltip</button><button data-page="collection">Comparar dois exemplares</button><button data-page="accounts">Exportar / importar backup</button><button id="reset-overlay">Restaurar posição do painel flutuante</button></div><p>O Ctrl + clique fixa o exemplar: novos hovers não substituem a análise que você está lendo.</p>`,
    notifications: `<h2>Avisos durante a consulta</h2><label class="check-setting"><input id="pref-highlight" type="checkbox" ${preferences.highlight ? 'checked' : ''}> Destacar exemplares selecionados com IV acima do meu filtro</label><p>O aviso aparece na barra do painel ao analisar um exemplar. O limite atual é ${preferences.minIV}/192. Não monitora capturas, shinies, desconexões ou suprimentos.</p><button id="save-preferences">Salvar avisos</button>`,
    interface: `<h2>Interface sobre o jogo</h2><p>Pesquisas disponíveis na barra BDS dentro do jogo. Cartões de contas não são exibidos sobre a tela.</p><label class="check-setting"><input id="pref-compact" type="checkbox" ${preferences.compact ? 'checked' : ''}> Preferir painel estreito (560 px)</label><label>Abrir análise de links do chat<select id="pref-clickMode"><option value="ctrl" ${preferences.clickMode === 'ctrl' ? 'selected' : ''}>Ctrl + clique · recomendado</option><option value="click" ${preferences.clickMode === 'click' ? 'selected' : ''}>Clique simples no link com tooltip visível</option></select></label><p>Arraste a barra para mover, use − para recolher e arraste o canto inferior para redimensionar. Ctrl + clique continua disponível no time e na mochila.</p><button id="save-preferences">Salvar interface</button>`,
  };
  renderHTML($('settings-content'), content[tab] || content.menus);
}
function clearAnalysis() {
  analyzed = null;
  renderHTML($('analysis'), '');
}
function fillBase() {
  const c = creatures.find((c) => c.pokeId === Number($('species').value));
  if (!c) return;
  for (const k of STATS) $('base-' + k).textContent = f(baseStats(c)[k]);
  clearAnalysis();
}
function inputRecord() {
  const c = creatures.find((c) => c.pokeId === Number($('species').value));
  if (!c) throw new Error('Escolha uma espécie do catálogo.');
  return {
    id: crypto.randomUUID(),
    speciesId: c.pokeId,
    name: c.name,
    level: num($('level').value),
    quality: num($('quality').value),
    precision:
      $('precision').value === 'exact' ? null : Number($('precision').value),
    total: $('iv-total').value.trim() ? num($('iv-total').value) : null,
    current: Object.fromEntries(
      STATS.map((k) => [k, num($('stat-' + k).value)]),
    ),
    capturedAt: new Date().toISOString(),
    source,
  };
}
function runAnalysis(record) {
  const c = creatures.find((c) => c.pokeId === record.speciesId);
  if (!c) throw new Error('Espécie ausente do catálogo.');
  return estimate({ ...record, bases: baseStats(c) });
}
function showAnalysis(record) {
  const result = runAnalysis(record);
  analyzed = result.valid ? { record, result } : null;
  if (!result.valid) {
    renderHTML(
      $('analysis'),
      `<div class="panel error"><h2>Dados incompatíveis</h2><p>${e(result.reason)}</p></div>`,
    );
    return;
  }
  renderHTML(
    $('analysis'),
    `<div class="panel"><div class="analysis-top"><div><span class="eyebrow accent">${result.unique ? 'SOLUÇÃO ÚNICA NO MODELO' : 'ESTIMATIVA COM INTERVALO'}</span><h2>${e(record.name)} · Nv. ${record.level}</h2></div><div class="actions"><button id="save-record" class="primary">Salvar exemplar</button><button id="open-full-analysis">Batalha · Progressão · Drops →</button></div></div><div class="metric-grid"><div class="metric"><b>${range(result.total.min, result.total.max)}</b><small>IV total /192 · ${range((result.total.min / 192) * 100, (result.total.max / 192) * 100, 1)}%</small></div><div class="metric"><b>×${f(record.quality, 4)}</b><small>${e(qualityLabel(record.quality))} · qualidade</small></div><div class="metric"><b>${f(result.power, 1)}</b><small>Power calculado · nível atual</small></div></div>${STATS.map((k) => `<div class="iv-row"><span>${LABELS[k]}</span><meter min="0" max="32" value="${result.ivs[k].min}" aria-label="${LABELS[k]}: ${result.ivs[k].values.join(', ')}"></meter><b>${range(result.ivs[k].min, result.ivs[k].max)} /32</b></div>`).join('')}<p class="footnote">As barras mostram o mínimo possível. Valores candidatos: ${STATS.map((k) => `${LABELS[k]} [${result.ivs[k].values.join(', ')}]`).join(' · ')}.</p><div class="notice">Power no nível 100, mesma qualidade: <strong>${range(result.power100.min, result.power100.max, 1)}</strong>. Faixa conservadora; não é previsão de dano. ${result.unique ? 'Unívoco sob as hipóteses do modelo, não um dado lido do servidor.' : 'Não há informação suficiente para fixar todos os IVs individuais.'}</div><p class="footnote">Origem: ${e(record.source)} · ${date(record.capturedAt)}. Qualidade considerada entre ${f(result.qualityRange[0], 5)} e ${f(result.qualityRange[1], 5)}.</p></div>`,
  );
}
function fillRecord(record) {
  const c = record.speciesId
    ? creatures.find((c) => c.pokeId === record.speciesId)
    : findSpecies(creatures, record.name);
  if (!c) {
    toast(
      'Espécie não identificada com segurança. Selecione a forma exata manualmente.',
    );
    return;
  }
  $('species').value = c.pokeId;
  fillBase();
  $('level').value = record.level ?? '';
  $('quality').value = record.quality ?? '';
  $('precision').value =
    record.precision === null ? 'exact' : String(record.precision ?? 3);
  $('iv-total').value = record.total ?? '';
  for (const k of STATS) $('stat-' + k).value = record.current?.[k] ?? '';
  source = record.source || 'entrada manual';
  go('ivs');
  toast('Dados preenchidos. Confira HP máximo e bônus antes de analisar.');
}
async function refreshTabs() {
  if (!api) {
    renderHTML(
      $('game-tabs'),
      '<option>Disponível na extensão instalada</option>',
    );
    return;
  }
  const tabs = await api.tabs
    .query({ url: official + '/play*' })
    .catch(() => []);
  renderHTML(
    $('game-tabs'),
    '<option value="">Escolha a aba do jogo</option>' +
      tabs
        .filter((t) => new URL(t.url).pathname === '/play')
        .map(
          (t) =>
            `<option value="${t.id}">${e(t.title || 'Poke Idle World')} · aba ${t.id}</option>`,
        )
        .join(''),
  );
  if (tabs.length === 1) $('game-tabs').value = tabs[0].id;
}
async function refreshReader() {
  if (!api) return;
  const { latest = {}, bindings = {} } = await api.storage.session.get([
    'latest',
    'bindings',
  ]);
  incoming = latest[workspace.active] || null;
  let active = false;
  for (const [id, p] of Object.entries(bindings))
    if (p === workspace.active) {
      const status = await api.tabs
        .sendMessage(Number(id), { type: 'reader-status' })
        .catch(() => null);
      active ||= !!status?.active;
    }
  $('reader-state').textContent = active ? 'LEITURA ATIVA' : 'MANUAL';
  renderHTML(
    $('incoming'),
    incoming
      ? `<div class="incoming"><strong>${e(incoming.name)} · Nv. ${incoming.level}</strong><p>Último tooltip: ${date(incoming.capturedAt)} · aba ${incoming.tabId}. ${active ? '' : 'Leitura parada; este é um dado anterior.'}</p><button id="use-incoming">Usar esta leitura</button> <button id="analyze-incoming">Abrir análise completa</button></div>`
      : '',
  );
}
async function message(m) {
  const r = await api.runtime.sendMessage(m);
  if (!r?.ok) throw new Error(r?.error || 'A extensão não respondeu.');
  return r.data;
}
function renderCollection() {
  const records = profile().records;
  for (const id of compared)
    if (!records.some((r) => r.id === id)) compared.delete(id);
  renderHTML(
    $('saved-records'),
    records.length
      ? [...records]
          .reverse()
          .map(
            (r) =>
              `<div class="record"><div><h3>${e(r.name)}</h3><p>Nv. ${r.level} · qualidade ×${f(r.quality, 4)} · ${date(r.capturedAt)}</p></div><div class="actions"><label><input type="checkbox" data-compare="${e(r.id)}" ${compared.has(r.id) ? 'checked' : ''}>Comparar</label><button data-load-record="${e(r.id)}">Abrir</button><button data-remove-record="${e(r.id)}" title="Excluir este exemplar salvo">×</button></div></div>`,
          )
          .join('')
      : empty(
          'Sua coleção começa com uma análise',
          'Abra Analisador de IVs, preencha um exemplar e clique em Salvar exemplar.',
        ),
  );
  const selected = records.filter((r) => compared.has(r.id));
  if (!selected.length) {
    renderHTML($('comparison'), '');
    return;
  }
  const results = selected.map((r) => runAnalysis(r));
  if (results.some((r) => !r.valid)) {
    renderHTML(
      $('comparison'),
      '<div class="notice">Um dos exemplares é incompatível com o catálogo/modelo atual. Abra e confira os dados antes de comparar.</div>',
    );
    return;
  }
  renderHTML(
    $('comparison'),
    `<div class="panel"><h2>Comparação no mesmo nível</h2>${table(['Medida', ...selected.map((r) => r.name)], [['Qualidade', ...selected.map((r) => `×${f(r.quality, 4)}`)], ['IV total', ...results.map((r) => range(r.total.min, r.total.max) + ' /192')], ['Power no Nv. 100', ...results.map((r) => range(r.power100.min, r.power100.max, 1))], ...STATS.map((k) => [LABELS[k] + ' · IV', ...results.map((r) => range(r.ivs[k].min, r.ivs[k].max) + ' /32')])])}<p class="footnote">Comparação teórica no nível 100. Faixas podem se sobrepor; Power não determina sozinho o melhor Pokémon para uma luta. Golpes, tipos e função da equipe também contam.</p></div>`,
  );
}
function renderHunts() {
  const sessions = profile().sessions;
  renderHTML(
    $('hunt-history'),
    sessions.length
      ? `<div class="panel"><h2>Sessões da ficha ativa</h2>${table(
          ['Caçada / data', 'Tempo', 'XP/h', 'Saldo/h', 'Saldo', ''],
          [...sessions].reverse().map((s) => {
            const r = huntRates(s);
            return [
              `${e(s.target)}<br><small class="muted">${date(s.date)}</small>`,
              `${f(s.minutes, 1)} min`,
              f(r.xpH),
              f(r.goldH),
              f(r.net),
              `<button data-remove-session="${e(s.id)}" aria-label="Excluir sessão">×</button>`,
            ];
          }),
        )}</div>`
      : empty(
          'Ainda não há caçadas registradas',
          'Anote uma sessão acima para construir seu histórico.',
        ),
  );
}
function renderAccounts() {
  const containers = !!api?.contextualIdentities;
  $('account-platform').textContent = containers
    ? 'Edição Firefox: cada ficha pode abrir o jogo em um contêiner separado. O login é manual no site oficial. Até quatro contêineres criados por este projeto.'
    : 'Chrome/Edge: estas são fichas de organização, não sessões isoladas. Abas do mesmo perfil compartilham o login. Continue usando os perfis existentes ou use a edição Firefox para quatro contêineres no mesmo navegador.';
  renderHTML(
    $('account-cards'),
    workspace.profiles
      .map(
        (p, i) =>
          `<article class="account-card ${p.id === workspace.active ? 'active' : ''}"><span class="account-number">FICHA 0${i + 1}${p.id === workspace.active ? ' · ATIVA' : ''}</span><h2>${e(p.name)}</h2><p>${p.records.length} exemplares · ${p.sessions.length} caçadas</p><label>Nome da ficha<input data-profile-name="${e(p.id)}" value="${e(p.name)}" maxlength="40"></label><div class="actions"><button data-select-profile="${e(p.id)}">Selecionar</button><button data-rename="${e(p.id)}">Renomear</button>${containers ? `<button data-container="${e(p.id)}">Abrir conta isolada ↗</button>` : ''}</div></article>`,
      )
      .join(''),
  );
  $('add-profile').disabled = workspace.profiles.length >= 4;
  $('notes').value = profile().notes;
}
async function switchProfile(id) {
  await updateState((s) => (s.active = id));
  compared.clear();
  clearAnalysis();
  renderHTML($('hunt-results'), '');
  renderAccounts();
  renderCollection();
  renderHunts();
  await refreshReader();
}
async function handleClick(event) {
  const b = event.target.closest('button');
  if (!b) return;
  if (b.dataset.settings) {
    renderSettings(b.dataset.settings);
    return;
  }
  if (b.dataset.openSpecies) {
    await openAnalyzer(null, b.dataset.openSpecies);
    return;
  }
  if (b.dataset.focusAccount) {
    await switchProfile(b.dataset.focusAccount);
    const a = accountLinks.find((a) => a.id === b.dataset.focusAccount);
    if (a?.tabId)
      await message({
        type: 'focus-account',
        profileId: b.dataset.focusAccount,
      });
    else {
      go('ivs');
      await refreshTabs();
      toast('Selecione a aba desta conta e clique em Ativar leitura.');
    }
    return;
  }
  if (b.dataset.page) {
    go(b.dataset.page);
    return;
  }
  if (b.dataset.kind) {
    kind = b.dataset.kind;
    limit = 24;
    document
      .querySelectorAll('[data-kind]')
      .forEach((x) => x.classList.toggle('active', x === b));
    renderCatalog();
    return;
  }
  if (b.dataset.favorite) {
    const key = b.dataset.favorite;
    await updateState(
      (s) =>
        (s.favorites = s.favorites.includes(key)
          ? s.favorites.filter((x) => x !== key)
          : [...s.favorites, key]),
    );
    renderCatalog();
    return;
  }
  if (b.dataset.detail) {
    detail(b.dataset.detail);
    return;
  }
  if (b.dataset.analyze) {
    $('detail').close();
    $('species').value = b.dataset.analyze;
    fillBase();
    go('ivs');
    return;
  }
  if (b.dataset.selectProfile) {
    await switchProfile(b.dataset.selectProfile);
    return;
  }
  if (b.dataset.rename) {
    const id = b.dataset.rename,
      input = [...document.querySelectorAll('[data-profile-name]')].find(
        (x) => x.dataset.profileName === id,
      );
    await updateState(
      (s) =>
        (s.profiles.find((p) => p.id === id).name =
          input.value.trim().slice(0, 40) || 'Conta'),
    );
    renderAccounts();
    return;
  }
  if (b.dataset.container) {
    await message({ type: 'container-open', profileId: b.dataset.container });
    return;
  }
  if (b.dataset.loadRecord) {
    fillRecord(profile().records.find((r) => r.id === b.dataset.loadRecord));
    return;
  }
  if (b.dataset.removeRecord) {
    const id = b.dataset.removeRecord;
    if (!confirm('Excluir este exemplar da coleção local?')) return;
    await updateState(
      (s) =>
        (s.profiles.find((p) => p.id === s.active).records = s.profiles
          .find((p) => p.id === s.active)
          .records.filter((r) => r.id !== id)),
    );
    renderCollection();
    return;
  }
  if (b.dataset.removeSession) {
    const id = b.dataset.removeSession;
    if (!confirm('Excluir esta sessão do diário local?')) return;
    await updateState(
      (s) =>
        (s.profiles.find((p) => p.id === s.active).sessions = s.profiles
          .find((p) => p.id === s.active)
          .sessions.filter((r) => r.id !== id)),
    );
    renderHunts();
    return;
  }
  switch (b.id) {
    case 'close-analyzer':
      $('analyzer-dialog').close();
      $('analyzer-frame').src = 'about:blank';
      break;
    case 'open-full-analysis':
      await openAnalyzer(inputRecord());
      break;
    case 'analyze-incoming':
      if (incoming) await openAnalyzer(incoming);
      break;
    case 'open-overlay':
      if (!api) throw new Error('Disponível na extensão instalada.');
      await message({ type: 'overlay-open', profileId: workspace.active });
      break;
    case 'reset-overlay':
      if (api) {
        await api.storage.local.remove('overlayPosition');
        await api.storage.local.set({ overlayReset: Date.now() });
      }
      toast('Posição do painel restaurada.');
      break;
    case 'save-preferences': {
      for (const key of ['dock', 'compact', 'highlight']) {
        const el = $('pref-' + key);
        if (el) preferences[key] = el.checked;
      }
      if ($('pref-clickMode'))
        preferences.clickMode = $('pref-clickMode').value;
      if ($('pref-minIV')) {
        const value = Number($('pref-minIV').value);
        if (!Number.isInteger(value) || value < 6 || value > 192)
          throw new Error('Use IV de 6 a 192.');
        preferences.minIV = value;
      }
      if (api) await api.storage.local.set({ preferences });
      else localStorage.setItem('bds-preferences', JSON.stringify(preferences));
      toast('Preferências salvas.');
      break;
    }
    case 'favorite-filter':
      favoriteOnly = !favoriteOnly;
      b.setAttribute('aria-pressed', String(favoriteOnly));
      b.textContent = favoriteOnly ? '★ Favoritos' : '☆ Favoritos';
      limit = 24;
      renderCatalog();
      break;
    case 'more':
      limit += 24;
      renderCatalog();
      break;
    case 'close-detail':
      $('detail').close();
      break;
    case 'fullpage':
      if (api) await api.tabs.create({ url: api.runtime.getURL('panel.html') });
      else toast('Você já está na prévia do painel completo.');
      break;
    case 'refresh-tabs':
      await refreshTabs();
      await refreshReader();
      break;
    case 'reader-start': {
      if (!api)
        throw new Error('Instale a extensão para ler tooltips do jogo.');
      if (!(await api.permissions.request({ origins: [official + '/*'] })))
        throw new Error(
          'Acesso não concedido. O modo manual continua disponível.',
        );
      if (!$('game-tabs').value) {
        await refreshTabs();
        toast('Escolha uma aba e clique novamente em Ativar leitura.');
        break;
      }
      await message({
        type: 'bind',
        tabId: Number($('game-tabs').value),
        profileId: workspace.active,
      });
      await refreshReader();
      await refreshAccountLinks();
      toast(
        'Leitura ligada. Passe o mouse sobre um Pokémon e use Ctrl + clique.',
      );
      break;
    }
    case 'reader-stop':
      if (api) {
        await message({ type: 'unbind', profileId: workspace.active });
        await refreshReader();
        await refreshAccountLinks();
      }
      break;
    case 'use-incoming':
      if (incoming) fillRecord(incoming);
      break;
    case 'parse-tooltip': {
      const parsed = parseTooltip($('tooltip-text').value);
      if (!parsed)
        throw new Error(
          'Não encontrei nome, nível e qualidade no texto. Use o formulário manual.',
        );
      fillRecord({ ...parsed, source: 'texto colado pelo usuário' });
      break;
    }
    case 'example': {
      const c = creatures.find((c) => c.pokeId === 6),
        ivs = [29, 21, 24, 31, 26, 28];
      fillRecord({
        speciesId: c.pokeId,
        level: 100,
        quality: 1.5,
        precision: 3,
        total: 159,
        current: Object.fromEntries(
          STATS.map((k, i) => [k, stat(baseStats(c)[k], ivs[i], 100, 1.5, k)]),
        ),
        source: 'exemplo fictício · dados gerados pelo modelo',
      });
      break;
    }
    case 'save-record': {
      if (!analyzed) return;
      const r = structuredClone(analyzed.record);
      await updateState((s) => {
        const p = s.profiles.find((p) => p.id === s.active);
        if (!p.records.some((x) => x.id === r.id))
          p.records = [...p.records, r].slice(-100);
      });
      toast('Exemplar salvo na ficha ativa.');
      break;
    }
    case 'add-profile':
      await updateState(
        (s) =>
          (s.profiles = addProfile(
            s.profiles,
            `Conta ${s.profiles.length + 1}`,
          )),
      );
      renderAccounts();
      break;
    case 'save-notes': {
      const notes = $('notes').value.slice(0, 2000);
      await updateState(
        (s) => (s.profiles.find((p) => p.id === s.active).notes = notes),
      );
      toast('Notas salvas.');
      break;
    }
    case 'export': {
      workspace = await getWorkspace();
      const blob = new Blob([JSON.stringify(workspace, null, 2)], {
          type: 'application/json',
        }),
        url = URL.createObjectURL(blob),
        a = document.createElement('a');
      a.href = url;
      a.download = `bds-poke-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      break;
    }
  }
}
async function init() {
  await Promise.all([loadSprites(), loadItemSprites()]);
  const data = await Promise.all(
    ['creatures', 'items', 'provenance'].map(async (name) => {
      const r = await fetch(`data/${name}.json`);
      if (!r.ok)
        throw new Error('Catálogo local ausente. Execute npm run catalog.');
      return r.json();
    }),
  );
  creatures = data[0].creatures;
  items = data[1].items;
  provenance = data[2];
  buildMoves();
  workspace = await getWorkspace();
  if (!workspace) {
    const profiles = addProfile([], 'Conta 1');
    workspace = {
      schema: 'bds-poke-v1',
      profiles,
      active: profiles[0].id,
      favorites: [],
    };
    await putWorkspace(workspace);
  }
  preferences = {
    ...preferences,
    ...(api
      ? (await api.storage.local.get('preferences')).preferences
      : JSON.parse(localStorage.getItem('bds-preferences') || 'null')),
  };
  renderProfiles();
  await refreshAccountLinks();
  renderHTML(
    $('catalog-summary'),
    [
      [creatures.length, 'espécies para explorar', '◈'],
      [items.length, 'itens no catálogo', '◇'],
      [moves.length, 'golpes naturais', 'ϟ'],
    ]
      .map(
        ([n, s, icon]) =>
          `<div class="summary"><span>${icon}</span><strong>${f(n)}</strong><small>${s}</small></div>`,
      )
      .join(''),
  );
  renderHTML(
    $('type-filter'),
    Object.entries(types)
      .map(([k, v]) => `<option value="${k}">${v}</option>`)
      .join(''),
    true,
  );
  renderHTML(
    $('species'),
    [...creatures]
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(
        (c) =>
          `<option value="${c.pokeId}">${e(c.name)} · #${c.pokeId}</option>`,
      )
      .join(''),
  );
  $('species').value = 1;
  renderHTML(
    $('stat-inputs'),
    STATS.map(
      (k) =>
        `<tr><td><label for="stat-${k}">${LABELS[k]}</label></td><td id="base-${k}"></td><td><input id="stat-${k}" type="number" min="0" step="1" required placeholder="${k === 'hp' ? 'HP máximo' : 'Atual'}"></td></tr>`,
    ).join(''),
  );
  $('catalog-date').textContent =
    `Catálogo oficial salvo em ${date(provenance.fetchedAt)} · consulta local · sem bônus de conta.`;
  renderHTML(
    $('official-links'),
    links.map(([label, url]) => external(official + url, label)).join(''),
  );
  renderHTML(
    $('source-details'),
    `<p>Snapshot: ${date(provenance.fetchedAt)}.</p>${provenance.sources.map((s) => `<p>${external(s.url, s.url.split('/').at(-1))} · ${s.count} registros</p>`).join('')}<p>Inspiração funcional: interfaces locais do BSV 4.1.0 (consulta, análise e organização). Código e interface desta extensão são próprios.</p>`,
  );
  fillBase();
  renderCatalog();
  renderAccounts();
  renderCollection();
  renderHunts();
  document.addEventListener('click', (event) =>
    handleClick(event).catch((error) => toast(error.message)),
  );
  $('profile').addEventListener('change', () =>
    switchProfile($('profile').value).catch((error) => toast(error.message)),
  );
  $('species').addEventListener('change', fillBase);
  for (const id of ['search', 'type-filter', 'hunt-level', 'sort'])
    $(id).addEventListener('input', () => {
      limit = 24;
      renderCatalog();
    });
  $('iv-form').addEventListener('input', () => {
    source = 'entrada manual / revisada';
    clearAnalysis();
  });
  $('iv-form').addEventListener('change', clearAnalysis);
  $('iv-form').addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      showAnalysis(inputRecord());
    } catch (error) {
      toast(error.message);
    }
  });
  $('hunt-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
      const s = {
        id: crypto.randomUUID(),
        target: $('hunt-target').value.trim(),
        date: new Date().toISOString(),
        ...Object.fromEntries(
          ['minutes', 'xp', 'gold', 'costs', 'kills', 'remaining'].map((k) => [
            k,
            num($('hunt-' + k).value),
          ]),
        ),
      };
      const r = huntRates(s);
      await updateState((w) => {
        const p = w.profiles.find((p) => p.id === w.active);
        p.sessions = [...p.sessions, s].slice(-100);
      });
      renderHTML(
        $('hunt-results'),
        `<div class="metric-grid"><div class="metric"><b>${f(r.xpH)}</b><small>XP/h nesta sessão</small></div><div class="metric"><b>${f(r.goldH)}</b><small>Saldo líquido/h</small></div><div class="metric"><b>${r.etaMinutes === null ? '—' : f(r.etaMinutes, 1) + ' min'}</b><small>ETA no mesmo ritmo</small></div></div>`,
      );
      renderHunts();
      toast('Caçada registrada.');
    } catch (error) {
      toast(error.message);
    }
  });
  document.addEventListener('change', (event) => {
    const id = event.target.dataset.compare;
    if (!id) return;
    if (event.target.checked && compared.size >= 2) {
      event.target.checked = false;
      toast('Escolha no máximo dois exemplares.');
      return;
    }
    if (event.target.checked) compared.add(id);
    else compared.delete(id);
    renderCollection();
  });
  $('import').addEventListener('change', async () => {
    try {
      const file = $('import').files[0];
      if (!file) return;
      if (file.size > 2000000) throw new Error('Backup maior que 2 MB.');
      const next = validBackup(JSON.parse(await file.text()));
      if (
        !confirm(
          `Substituir as fichas locais por ${next.profiles.length} ficha(s) do backup? Exporte as atuais antes se quiser preservá-las.`,
        )
      )
        return;
      if (api) {
        for (const p of workspace.profiles)
          await message({ type: 'unbind', profileId: p.id });
      }
      await updateState((s) => {
        for (const key of Object.keys(s)) delete s[key];
        Object.assign(s, next);
      });
      compared.clear();
      clearAnalysis();
      renderProfiles();
      renderAccounts();
      renderCollection();
      renderHunts();
      renderCatalog();
      await refreshReader();
      toast('Backup importado.');
    } catch (error) {
      toast(error.message);
    } finally {
      $('import').value = '';
    }
  });
  document.addEventListener('keydown', (event) => {
    if (
      event.key === '/' &&
      !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) &&
      !$('detail').open
    ) {
      event.preventDefault();
      go('dex');
      $('search').focus();
    }
  });
  if (api)
    api.storage.onChanged.addListener((changes, area) => {
      if (area === 'session' && (changes.latest || changes.bindings)) {
        refreshReader().catch(() => {});
        refreshAccountLinks().catch(() => {});
      }
      if (area === 'local' && changes.workspace?.newValue) {
        const old = workspace.active;
        workspace = changes.workspace.newValue;
        renderProfiles();
        renderCollection();
        renderHunts();
        if (old !== workspace.active) {
          clearAnalysis();
          renderAccounts();
          refreshReader().catch(() => {});
        }
      }
    });
  await refreshTabs();
  await refreshReader();
  go(location.hash.slice(1) || 'dex');
}
requireAccess()
  .then((allowed) => (allowed ? init() : undefined))
  .catch((error) => {
    renderHTML(
      $('main'),
      `<div class="panel error"><h1>Não foi possível abrir o painel.</h1><p>${e(error.message)}</p></div>`,
    );
  });
