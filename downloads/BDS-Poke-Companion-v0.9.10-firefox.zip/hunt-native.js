// Only aggregate fields from the game's analyzer response. No commands or polling.
export function cleanNativeAnalyzer(p, key) {
  if (p?.key !== key) return null;
  const limits = {
    seconds: 31536000,
    kills: 1e9,
    xpGained: 1e15,
    xpPerHour: 1e15,
    killsPerHour: 1e9,
  };
  if (
    Object.entries(limits).some(
      ([k, max]) => !Number.isFinite(p[k]) || p[k] < 0 || p[k] > max,
    )
  )
    return null;
  if (!Number.isSafeInteger(p.kills)) return null;
  // Server rates are rounded; allow rounding, not contradictory totals.
  if (
    p.seconds > 0 &&
    (Math.abs(p.xpPerHour - (p.xpGained * 3600) / p.seconds) >
      Math.max(2, p.xpPerHour * 0.01) ||
      Math.abs(p.killsPerHour - (p.kills * 3600) / p.seconds) >
        Math.max(2, p.killsPerHour * 0.01))
  )
    return null;
  return Object.fromEntries(Object.keys(limits).map((k) => [k, p[k]]));
}

export function observeNativeAnalyzer(run, payload, at) {
  const native = cleanNativeAnalyzer(
    payload,
    JSON.stringify([run.capId, run.slug]),
  );
  if (!native) return null;
  const current = {
    ...native,
    at,
    localKills: run.steady?.kills || 0,
    localPokeXp: run.steady?.pokeXp || 0,
    localTrainerXp: run.steady?.trainerXp || 0,
  };
  const old = run.native;
  const last = old?.last;
  const reset =
    !last ||
    old.base.at < (run.steady?.start || Infinity) ||
    at - last.at > 15000 ||
    current.seconds < last.seconds ||
    current.kills < last.kills ||
    current.xpGained < last.xpGained ||
    run.penaltyFrozen ||
    at < (run.steady?.start || Infinity);
  const base = reset ? current : old.base;
  const seconds = current.seconds - base.seconds;
  const elapsed = (at - base.at) / 1000;
  const kills = current.kills - base.kills;
  const localKills = current.localKills - base.localKills;
  // Compare only a common interval, never the native full session against a new
  // extension sample. A map/reset/reconnect establishes a fresh baseline.
  const aligned =
    seconds >= 30 &&
    kills >= 5 &&
    Math.abs(seconds - elapsed) <= Math.max(5, elapsed * 0.1);
  return {
    base,
    last: current,
    check: aligned
      ? {
          seconds,
          kills,
          localKills,
          consistent: Math.abs(kills - localKills) <= 1,
          xpHour: ((current.xpGained - base.xpGained) * 3600) / seconds,
          pokeHour: ((current.localPokeXp - base.localPokeXp) * 3600) / seconds,
          trainerHour:
            ((current.localTrainerXp - base.localTrainerXp) * 3600) / seconds,
        }
      : null,
  };
}
