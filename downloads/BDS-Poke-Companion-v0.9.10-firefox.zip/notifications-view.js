import { notificationSettings } from './notifications.js';
import { renderHTML } from './render-html.js';
export function setupNotifications(getContext, send, toast) {
  const root = document.getElementById('notifications');
  renderHTML(
    root,
    `<span class="eyebrow">ALERTAS DESTA CONTA</span><h1>Notificações</h1>
    <p>Uma voz feminina avisa durante a hunt, mesmo com o menu recolhido. As falas são curtas e já vêm na extensão. As preferências ficam salvas para esta conta do jogo.</p>
    <p id="notifications-state" class="hint"></p>
    <form id="notifications-form">
      <fieldset class="notification-card"><legend>Captura de Pokémon</legend>
        <label class="notification-toggle"><input id="notify-capture" type="checkbox"> Avisar com som ao capturar</label>
        <label for="notify-iv">Notificar capturas a partir de</label>
        <div class="notification-limit"><input id="notify-iv" type="number" min="0" max="192" step="1" required value="160"><strong>IV /192</strong></div>
        <p>O limite inclui o valor escolhido: 160 avisa para 160 IV ou mais. Usa o IV total informado pelo jogo.</p>
        <button type="button" data-notification-test="capture">Ouvir “Pokémon”</button>
      </fieldset>
      <fieldset class="notification-card"><legend>Drops de itens</legend>
        <div class="notification-item"><label class="notification-toggle"><input id="notify-bronze" type="checkbox"> Bronze Boss Token</label><button type="button" data-notification-test="bronze">Ouvir “Token”</button></div>
        <div class="notification-item"><label class="notification-toggle"><input id="notify-pheromone" type="checkbox"> Strange Pheromone</label><button type="button" data-notification-test="pheromone">Ouvir “Pheromone”</button></div>
        <p>Avisa somente por drops de abates recebidos ao vivo. Compras, trocas e o carregamento do inventário não disparam alertas.</p>
      </fieldset>
      <label for="notify-volume">Volume dos alertas</label><input id="notify-volume" type="range" min="1" max="100" value="50">
      <button class="primary" type="submit">Salvar notificações</button>
    </form>
    <p id="notifications-feedback" role="status"></p><p id="notifications-last"></p>
    <p class="hint">Abra o inventário do jogo uma vez após ligar o leitor. Depois pode fechá-lo: Ultra Ball, Ultimate Potion e novas capturas acompanham os eventos ao vivo. Após reconectar, abra novamente para conferir a leitura. Não são tocados alertas do histórico.</p>`,
  );
  const $ = (id) => document.getElementById(id);
  let signature;
  function render() {
    const c = getContext(),
      p = notificationSettings(c.notifications);
    const sig = JSON.stringify([c.profileId, p]);
    if (sig !== signature) {
      signature = sig;
      for (const kind of ['capture', 'bronze', 'pheromone'])
        $('notify-' + kind).checked = p[kind];
      $('notify-iv').value = p.minIV;
      $('notify-volume').value = p.volume;
    }
    for (const el of root.querySelectorAll('input,button'))
      el.disabled = !c.profileId;
    const live =
      c.live?.connected &&
      c.live?.online &&
      Date.now() - c.live.lastSeen < 15000;
    $('notifications-state').textContent = !c.profileId
      ? 'Abra esta aba pelo menu BDS dentro do jogo para configurar uma conta.'
      : !live
        ? 'Aguardando conexão com o jogo. Os alertas não serão recuperados do histórico.'
        : (c.captureReady
            ? 'Leitura de capturas pronta. '
            : 'Abra o inventário do jogo uma vez para iniciar a leitura dos IVs. ') +
          (!(p.capture || p.bronze || p.pheromone)
            ? 'Alertas desativados.'
            : c.audioState === 'ready'
              ? 'Sons ativos nesta aba.'
              : 'Para liberar o áudio, clique no jogo ou no botão ♪ da barra e teste um som.');
    $('notifications-last').textContent = c.lastNotification
      ? 'Último alerta: ' +
        c.lastNotification.text +
        ' · ' +
        new Date(c.lastNotification.at).toLocaleTimeString('pt-BR')
      : '';
  }
  $('notifications-form').onsubmit = async (e) => {
    e.preventDefault();
    try {
      const settings = {
        minIV: Number($('notify-iv').value),
        volume: Number($('notify-volume').value),
      };
      for (const kind of ['capture', 'bronze', 'pheromone'])
        settings[kind] = $('notify-' + kind).checked;
      await send({ type: 'notification-save', settings });
      $('notifications-feedback').textContent =
        'Notificações salvas para esta conta.';
    } catch (error) {
      toast(error.message);
    }
  };
  root.addEventListener('click', async (e) => {
    const button = e.target.closest('[data-notification-test]');
    if (!button) return;
    try {
      const result = await send({
        type: 'notification-test',
        kind: button.dataset.notificationTest,
      });
      $('notifications-feedback').textContent = result?.played
        ? 'Som de teste reproduzido.'
        : result?.error ||
          'O navegador bloqueou o áudio. Clique no jogo ou no botão ♪ da barra e teste novamente.';
    } catch (error) {
      toast(error.message);
    }
  });
  render();
  return render;
}
