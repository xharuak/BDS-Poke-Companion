// Isolated-world player. Its lifetime is the game tab, not the research iframe.
// Speech is pre-generated: only three short, local PCM files are decoded once.
(() => {
  globalThis.__bdsAudio?.stop();
  const api = globalThis.browser ?? globalThis.chrome;
  const voices = {
    capture: 'assets/notifications/capture.wav',
    bronze: 'assets/notifications/bronze.wav',
    pheromone: 'assets/notifications/pheromone.wav',
  };
  const buffers = new Map(),
    playing = new Set();
  let context,
    loading,
    abort,
    loadError = '',
    enabled = false,
    volume = 50,
    nextAt = 0;
  const state = () =>
    !enabled
      ? 'off'
      : context?.state === 'running' && buffers.size === 3
        ? 'ready'
        : 'blocked';
  function release() {
    abort?.abort();
    abort = null;
    for (const node of playing) {
      node.source.onended = null;
      try {
        node.source.stop();
      } catch {}
      node.source.disconnect();
      node.gain.disconnect();
    }
    playing.clear();
    context?.close().catch(() => {});
    context = null;
    loading = null;
    buffers.clear();
    nextAt = 0;
  }
  function prepare() {
    if (loading) return loading;
    try {
      context ||= new AudioContext();
      const current = context,
        controller = new AbortController();
      abort = controller;
      loadError = '';
      const timeout = setTimeout(() => controller.abort(), 5000);
      loading = Promise.all(
        Object.entries(voices).map(async ([kind, file]) => {
          const response = await fetch(api.runtime.getURL(file), {
            signal: controller.signal,
          });
          if (!response.ok) throw Error('Áudio indisponível.');
          const buffer = await current.decodeAudioData(
            await response.arrayBuffer(),
          );
          if (!(buffer.duration > 0 && buffer.duration <= 2))
            throw Error('Áudio inválido.');
          return [kind, buffer];
        }),
      )
        .then((entries) => {
          if (current !== context) return false;
          for (const [kind, buffer] of entries) buffers.set(kind, buffer);
          return true;
        })
        .catch(() => {
          if (current === context) {
            loadError =
              'Não foi possível carregar as vozes. Recarregue a extensão e a página do jogo.';
            loading = null;
          }
          return false;
        })
        .finally(() => clearTimeout(timeout));
      return loading;
    } catch {
      return Promise.resolve(false);
    }
  }
  function resume(preview = false) {
    if (!enabled && !preview) return;
    prepare();
    context?.resume().catch(() => {});
  }
  function unlock(e) {
    if (e.isTrusted) resume();
  }
  document.addEventListener('pointerdown', unlock, true);
  document.addEventListener('keydown', unlock, true);
  function play(kind, preview = false) {
    const buffer = buffers.get(kind);
    if ((!enabled && !preview) || !buffer || context?.state !== 'running')
      return false;
    // Serialize overlapping words, with a short bounded queue even during bursts.
    const start = Math.max(context.currentTime + 0.01, nextAt);
    if (start - context.currentTime > 3 || playing.size >= 4) return false;
    const source = context.createBufferSource(),
      gain = context.createGain();
    source.buffer = buffer;
    gain.gain.value = volume / 100;
    source.connect(gain);
    gain.connect(context.destination);
    const node = { source, gain };
    playing.add(node);
    source.onended = () => {
      source.disconnect();
      gain.disconnect();
      playing.delete(node);
      if (!enabled && !playing.size) release();
    };
    source.start(start);
    nextAt = start + buffer.duration + 0.1;
    return true;
  }
  globalThis.__bdsAudio = {
    configure(settings) {
      enabled = !!(settings.capture || settings.bronze || settings.pheromone);
      volume = Number.isFinite(settings.volume)
        ? Math.max(1, Math.min(100, settings.volume))
        : 50;
      if (enabled) prepare();
      else release();
    },
    state,
    resume,
    play: (kind) => play(kind),
    async test(kind, settings) {
      if (!Object.hasOwn(voices, kind))
        return { played: false, audioState: state() };
      volume = settings.volume;
      resume(true);
      const current = context;
      await prepare();
      if (current !== context) return { played: false, audioState: state() };
      if (context?.state !== 'running')
        await new Promise((resolve) => setTimeout(resolve, 180));
      const played = play(kind, true);
      const result = { played, audioState: state(), error: loadError };
      if (!played && !enabled) release();
      return result;
    },
    stop() {
      enabled = false;
      document.removeEventListener('pointerdown', unlock, true);
      document.removeEventListener('keydown', unlock, true);
      release();
    },
  };
})();
