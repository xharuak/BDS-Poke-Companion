const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
let catalog = { species: {}, outfits: {} },
  pending;
export function loadSprites() {
  if (!pending)
    pending = fetch('data/sprites.json')
      .then((r) => {
        if (!r.ok) throw Error('Sprites indisponíveis');
        return r.json();
      })
      .then((data) => {
        catalog = data;
      })
      .catch(() => {});
  return pending;
}
// Only display the published frame within the original atlas; no pixel recoloring.
export function sprite(c, { shiny = false, eager = false } = {}) {
  const forms = catalog.species[c?.pokeId],
    look = shiny ? forms?.shiny : forms?.normal,
    asset = catalog.outfits[look];
  const label = (shiny ? 'Shiny ' : '') + (c?.name || 'Pokémon');
  if (!asset)
    return `<span class="pokemon-sprite sprite-missing" role="img" aria-label="Imagem indisponível: ${esc(label)}" title="Sprite desta forma indisponível"><span class="sprite-fallback">?</span></span>`;
  return `<span class="pokemon-sprite" title="${esc(label)} · sprite do jogo" data-looktype="${look}"><span class="sprite-crop"><img src="${esc(asset.file)}" alt="${esc(label)}" loading="${eager ? 'eager' : 'lazy'}" decoding="async" draggable="false"></span><span class="sprite-fallback" hidden>?</span></span>`;
}
if (typeof document !== 'undefined')
  document.addEventListener(
    'error',
    (e) => {
      const wrap = e.target.closest?.('.pokemon-sprite');
      if (!wrap) return;
      e.target.hidden = true;
      wrap.classList.add('sprite-missing');
      wrap.querySelector('.sprite-fallback').hidden = false;
      wrap.setAttribute('aria-label', 'Imagem indisponível');
      wrap.setAttribute('role', 'img');
    },
    true,
  );
